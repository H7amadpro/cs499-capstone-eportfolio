//
//  InventoryViewModelTests.swift
//  InventoryAppTests
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//
//  Unit tests for InventoryViewModel and AddItemViewModel
//  Tests CRUD operations, search functionality, validation, and state management
//  Demonstrates test-driven development practices with mock repositories
//

import XCTest
import Combine
@testable import InventoryApp

final class InventoryViewModelTests: XCTestCase {
    
    // MARK: - Properties
    
    /// System under test
    var sut: InventoryViewModel!
    
    /// Mock repository for isolated testing
    var mockRepository: MockItemRepository!

    /// Combine subscriptions owned by the test case
    private var cancellables = Set<AnyCancellable>()
    
    // MARK: - Setup & Teardown
    
    override func setUp() {
        super.setUp()
        mockRepository = MockItemRepository()
        sut = InventoryViewModel(repository: mockRepository)
    }
    
    override func tearDown() {
        sut = nil
        mockRepository = nil
        cancellables.removeAll()
        super.tearDown()
    }

    // MARK: - Helpers

    private func waitForItemsCount(_ expectedCount: Int, timeout: TimeInterval = 1.0) {
        if sut.items.count == expectedCount {
            return
        }

        let expectation = expectation(description: "Items count becomes \(expectedCount)")
        sut.$items
            .map(\.count)
            .filter { $0 == expectedCount }
            .first()
            .sink { _ in expectation.fulfill() }
            .store(in: &cancellables)

        wait(for: [expectation], timeout: timeout)
    }

    private func waitForDebouncedFilteredCount(_ expectedCount: Int, timeout: TimeInterval = 1.0) {
        if sut.debouncedFilteredItems.count == expectedCount {
            return
        }

        let expectation = expectation(description: "Debounced filtered count becomes \(expectedCount)")
        sut.$debouncedFilteredItems
            .map(\.count)
            .filter { $0 == expectedCount }
            .first()
            .sink { _ in expectation.fulfill() }
            .store(in: &cancellables)

        wait(for: [expectation], timeout: timeout)
    }
    
    // MARK: - Load Items Tests
    
    func testLoadItems_ShouldPopulateItemsArray() {
        // Given
        mockRepository.reset()
        
        // When
        sut.loadItems()
        waitForItemsCount(Item.sampleItems.count)
        
        // Then
        XCTAssertFalse(sut.items.isEmpty, "Items array should not be empty after loading")
        XCTAssertEqual(sut.items.count, Item.sampleItems.count, "Should load all sample items")
    }
    
    func testLoadItems_ShouldSetIsLoadingToFalse() {
        // When
        sut.loadItems()
        waitForItemsCount(Item.sampleItems.count)
        
        // Then
        XCTAssertFalse(sut.isLoading, "isLoading should be false after load completes")
    }
    
    // MARK: - Delete Item Tests
    
    func testDeleteItem_ShouldRemoveItemFromList() {
        // Given
        mockRepository.reset()
        sut.loadItems()
        waitForItemsCount(Item.sampleItems.count)
        let initialCount = sut.items.count
        let itemToDelete = sut.items.first!
        
        // When
        sut.deleteItem(itemToDelete)
        waitForItemsCount(initialCount - 1)
        
        // Then
        XCTAssertEqual(sut.items.count, initialCount - 1, "Item count should decrease by 1")
        XCTAssertFalse(sut.items.contains(where: { $0.id == itemToDelete.id }), "Deleted item should not exist")
    }
    
    func testDeleteItemAtOffsets_ShouldRemoveCorrectItem() {
        // Given
        mockRepository.reset()
        sut.loadItems()
        waitForItemsCount(Item.sampleItems.count)
        let initialCount = sut.items.count
        let indexToDelete = IndexSet(integer: 0)
        let itemToDelete = sut.filteredItems[0]
        
        // When
        sut.deleteItem(at: indexToDelete)
        waitForItemsCount(initialCount - 1)
        
        // Then
        XCTAssertEqual(sut.items.count, initialCount - 1, "Item count should decrease by 1")
        XCTAssertFalse(sut.items.contains(where: { $0.id == itemToDelete.id }), "Deleted item should not exist")
    }
    
    // MARK: - Search/Filter Tests
    
    func testFilteredItems_WithEmptySearch_ShouldReturnAllItems() {
        // Given
        mockRepository.reset()
        sut.loadItems()
        waitForItemsCount(Item.sampleItems.count)
        sut.searchText = ""
        
        // Then
        XCTAssertEqual(sut.filteredItems.count, sut.items.count, "Should return all items when search is empty")
    }
    
    func testFilteredItems_WithSearchText_ShouldFilterByName() {
        // Given
        mockRepository.reset()
        sut.loadItems()
        waitForItemsCount(Item.sampleItems.count)
        
        // When
        sut.searchText = "MacBook"
        waitForDebouncedFilteredCount(1, timeout: 2.0)
        
        // Then
        XCTAssertTrue(sut.filteredItems.allSatisfy { 
            $0.name.lowercased().contains("macbook") || 
            $0.category.lowercased().contains("macbook")
        }, "Filtered items should match search query")
    }
    
    func testFilteredItems_WithNonMatchingSearch_ShouldReturnEmpty() {
        // Given
        mockRepository.reset()
        sut.loadItems()
        waitForItemsCount(Item.sampleItems.count)
        
        // When
        sut.searchText = "NonExistentItem12345"
        waitForDebouncedFilteredCount(0, timeout: 2.0)
        
        // Then
        XCTAssertTrue(sut.filteredItems.isEmpty, "Should return empty array for non-matching search")
    }

    func testLoadItems_WithActiveSearch_ShouldKeepResultsFiltered() {
        // Given
        mockRepository.reset()
        sut.loadItems()
        waitForItemsCount(Item.sampleItems.count)

        sut.searchText = "MacBook"
        waitForDebouncedFilteredCount(1, timeout: 2.0)
        XCTAssertEqual(sut.filteredItems.count, 1, "Precondition: should be filtered")

        // When - underlying data changes and we reload
        mockRepository.addItem(Item(name: "Desk", quantity: 1, price: 99.99, category: "Furniture"))
        sut.loadItems()
        waitForItemsCount(Item.sampleItems.count + 1)

        // Then - results stay filtered for the active query
        waitForDebouncedFilteredCount(1, timeout: 2.0)
        XCTAssertTrue(
            sut.filteredItems.allSatisfy { $0.name.lowercased().contains("macbook") },
            "Reload should not reset active search filtering"
        )
    }
    
    // MARK: - Computed Properties Tests
    
    func testTotalItemCount_ShouldReturnCorrectCount() {
        // Given
        mockRepository.reset()
        sut.loadItems()
        waitForItemsCount(Item.sampleItems.count)
        
        // Then
        XCTAssertEqual(sut.totalItemCount, Item.sampleItems.count, "Total count should match sample items count")
    }
    
    func testTotalInventoryValue_ShouldCalculateCorrectly() {
        // Given
        mockRepository.reset()
        sut.loadItems()
        waitForItemsCount(Item.sampleItems.count)
        let expectedValue = Item.sampleItems.reduce(0) { $0 + $1.totalValue }
        
        // Then
        XCTAssertEqual(sut.totalInventoryValue, expectedValue, accuracy: 0.01, "Total value should be sum of all item values")
    }
    
    // MARK: - Error Handling Tests
    
    func testClearError_ShouldSetErrorMessageToNil() {
        // Given
        sut.errorMessage = "Test error"
        
        // When
        sut.clearError()
        
        // Then
        XCTAssertNil(sut.errorMessage, "Error message should be nil after clearing")
    }
}

// MARK: - AddItemViewModel Tests

final class AddItemViewModelTests: XCTestCase {
    
    var sut: AddItemViewModel!
    var mockRepository: MockItemRepository!
    
    override func setUp() {
        super.setUp()
        mockRepository = MockItemRepository()
        sut = AddItemViewModel(repository: mockRepository)
    }
    
    override func tearDown() {
        sut = nil
        mockRepository = nil
        super.tearDown()
    }
    
    // MARK: - Validation Tests
    
    func testValidate_WithEmptyName_ShouldReturnFalse() {
        // Given
        sut.name = ""
        sut.quantity = "10"
        sut.price = "99.99"
        sut.category = "Electronics"
        
        // When
        let result = sut.validate()
        
        // Then
        XCTAssertFalse(result, "Validation should fail with empty name")
        XCTAssertNotNil(sut.validationError, "Should set validation error message")
    }
    
    func testValidate_WithNameTooLong_ShouldReturnFalse() {
        // Given
        sut.name = String(repeating: "a", count: 201)
        sut.quantity = "10"
        sut.price = "99.99"
        sut.category = "Electronics"
        
        // When
        let result = sut.validate()
        
        // Then
        XCTAssertFalse(result, "Validation should fail when name exceeds max length")
        XCTAssertNotNil(sut.validationError, "Should set validation error message")
    }
    
    func testValidate_WithInvalidQuantity_ShouldReturnFalse() {
        // Given
        sut.name = "Test Item"
        sut.quantity = "abc"
        sut.price = "99.99"
        sut.category = "Electronics"
        
        // When
        let result = sut.validate()
        
        // Then
        XCTAssertFalse(result, "Validation should fail with non-numeric quantity")
        XCTAssertNotNil(sut.validationError, "Should set validation error message")
    }
    
    func testValidate_WithNegativeQuantity_ShouldReturnFalse() {
        // Given
        sut.name = "Test Item"
        sut.quantity = "-5"
        sut.price = "99.99"
        sut.category = "Electronics"
        
        // When
        let result = sut.validate()
        
        // Then
        XCTAssertFalse(result, "Validation should fail with negative quantity")
        XCTAssertNotNil(sut.validationError, "Should set validation error message")
    }
    
    func testValidate_WithInvalidPrice_ShouldReturnFalse() {
        // Given
        sut.name = "Test Item"
        sut.quantity = "10"
        sut.price = "invalid"
        sut.category = "Electronics"
        
        // When
        let result = sut.validate()
        
        // Then
        XCTAssertFalse(result, "Validation should fail with non-numeric price")
        XCTAssertNotNil(sut.validationError, "Should set validation error message")
    }
    
    func testValidate_WithNegativePrice_ShouldReturnFalse() {
        // Given
        sut.name = "Test Item"
        sut.quantity = "10"
        sut.price = "-50.00"
        sut.category = "Electronics"
        
        // When
        let result = sut.validate()
        
        // Then
        XCTAssertFalse(result, "Validation should fail with negative price")
        XCTAssertNotNil(sut.validationError, "Should set validation error message")
    }
    
    func testValidate_WithEmptyCategory_ShouldReturnFalse() {
        // Given
        sut.name = "Test Item"
        sut.quantity = "10"
        sut.price = "99.99"
        sut.category = ""
        
        // When
        let result = sut.validate()
        
        // Then
        XCTAssertFalse(result, "Validation should fail with empty category")
        XCTAssertNotNil(sut.validationError, "Should set validation error message")
    }
    
    func testValidate_WithValidData_ShouldReturnTrue() {
        // Given
        sut.name = "Test Item"
        sut.quantity = "10"
        sut.price = "99.99"
        sut.category = "Electronics"
        
        // When
        let result = sut.validate()
        
        // Then
        XCTAssertTrue(result, "Validation should pass with valid data")
        XCTAssertNil(sut.validationError, "Should not set validation error")
    }
    
    // MARK: - Save Tests
    
    func testSave_WithValidData_ShouldReturnTrue() {
        // Given
        sut.name = "New Test Item"
        sut.quantity = "10"
        sut.price = "99.99"
        sut.category = "Electronics"
        
        // When
        let result = sut.save()
        
        // Then
        XCTAssertTrue(result, "Save should succeed with valid data")
        XCTAssertTrue(sut.didSaveSuccessfully, "didSaveSuccessfully should be true")
    }
    
    func testSave_WithInvalidData_ShouldReturnFalse() {
        // Given
        sut.name = ""
        sut.quantity = "10"
        sut.price = "99.99"
        sut.category = "Electronics"
        
        // When
        let result = sut.save()
        
        // Then
        XCTAssertFalse(result, "Save should fail with invalid data")
        XCTAssertFalse(sut.didSaveSuccessfully, "didSaveSuccessfully should be false")
    }
    
    // MARK: - Edit Mode Tests
    
    func testIsEditing_WithNoItem_ShouldBeFalse() {
        // Then
        XCTAssertFalse(sut.isEditing, "isEditing should be false when no item provided")
    }
    
    func testIsEditing_WithItem_ShouldBeTrue() {
        // Given
        let item = Item.sampleItem
        sut = AddItemViewModel(repository: mockRepository, item: item)
        
        // Then
        XCTAssertTrue(sut.isEditing, "isEditing should be true when item is provided")
    }
    
    func testInit_WithItem_ShouldPopulateFields() {
        // Given
        let item = Item.sampleItem
        
        // When
        sut = AddItemViewModel(repository: mockRepository, item: item)
        
        // Then
        XCTAssertEqual(sut.name, item.name, "Name should be populated from item")
        XCTAssertEqual(sut.quantity, String(item.quantity), "Quantity should be populated from item")
        XCTAssertEqual(sut.price, String(item.price), "Price should be populated from item")
        XCTAssertEqual(sut.category, item.category, "Category should be populated from item")
    }
}
