//
//  AlgorithmTests.swift
//  InventoryAppTests
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//
//  MILESTONE THREE: Algorithms and Data Structures Enhancement
//
//  Unit tests for algorithm optimizations:
//  - Timsort correctness
//  - Dictionary O(1) lookup
//  - Binary search
//  - Low stock algorithm
//  - Analytics calculations
//  - Data integrity verification
//

import XCTest
@testable import InventoryApp

final class AlgorithmTests: XCTestCase {
    
    // MARK: - Properties
    
    var mockRepository: MockItemRepository!
    var viewModel: InventoryViewModel!
    
    // MARK: - Test Data
    
    /// Creates test items for algorithm testing
    private func createTestItems(count: Int) -> [Item] {
        return (0..<count).map { i in
            Item(
                name: "Item \(String(format: "%03d", i))",
                quantity: i % 10,  // Some will be low stock
                price: Double(i) * 10.0,
                category: ["Electronics", "Furniture", "Supplies"][i % 3]
            )
        }
    }
    
    // MARK: - Setup & Teardown
    
    override func setUp() {
        super.setUp()
        mockRepository = MockItemRepository()
        viewModel = InventoryViewModel(repository: mockRepository)
    }
    
    override func tearDown() {
        viewModel = nil
        mockRepository = nil
        super.tearDown()
    }
    
    // MARK: - Sorting Tests
    
    func testGetAllItems_ShouldReturnSortedItems() {
        // Given
        mockRepository.reset()
        
        // When
        let items = mockRepository.getAllItems()
        
        // Then
        for i in 0..<(items.count - 1) {
            XCTAssertLessThanOrEqual(
                items[i].name.lowercased(),
                items[i + 1].name.lowercased(),
                "Items should be sorted alphabetically"
            )
        }
    }
    
    func testSorting_WithUnsortedInput_ShouldReturnSortedOutput() {
        // Given
        let unsortedNames = ["Zebra", "Apple", "Mango", "Banana"]
        for name in unsortedNames {
            mockRepository.addItem(Item(name: name, quantity: 10, price: 100, category: "Test"))
        }
        
        // When
        let items = mockRepository.getAllItems()
        let names = items.map { $0.name }
        
        // Then
        let sortedNames = names.sorted { $0.lowercased() < $1.lowercased() }
        XCTAssertEqual(names, sortedNames, "Items should be sorted alphabetically")
    }
    
    func testSorting_WithEmptyArray_ShouldReturnEmptyArray() {
        // Given
        mockRepository.clearAll()
        
        // When
        let items = mockRepository.getAllItems()
        
        // Then
        XCTAssertTrue(items.isEmpty, "Empty input should return empty output")
    }
    
    func testSorting_WithSingleItem_ShouldReturnSameItem() {
        // Given
        mockRepository.clearAll()
        let item = Item(name: "Single", quantity: 1, price: 10, category: "Test")
        mockRepository.addItem(item)
        
        // When
        let items = mockRepository.getAllItems()
        
        // Then
        XCTAssertEqual(items.count, 1, "Should return single item")
        XCTAssertEqual(items[0].name, "Single", "Should be the same item")
    }
    
    // MARK: - Dictionary Lookup Tests
    
    func testDictionaryLookup_WithExistingId_ShouldReturnItem() {
        // Given
        mockRepository.reset()
        let items = mockRepository.getAllItems()
        guard let firstItem = items.first else {
            XCTFail("Should have at least one item")
            return
        }
        
        // When
        let foundItem = mockRepository.getItem(byId: firstItem.id)
        
        // Then
        XCTAssertNotNil(foundItem, "Should find item by ID")
        XCTAssertEqual(foundItem?.id, firstItem.id, "Should return correct item")
        XCTAssertEqual(foundItem?.name, firstItem.name, "Item data should match")
    }
    
    func testDictionaryLookup_WithNonExistentId_ShouldReturnNil() {
        // Given
        mockRepository.reset()
        let nonExistentId = "non-existent-id-12345"
        
        // When
        let foundItem = mockRepository.getItem(byId: nonExistentId)
        
        // Then
        XCTAssertNil(foundItem, "Should return nil for non-existent ID")
    }
    
    func testDictionaryLookup_AfterDelete_ShouldReturnNil() {
        // Given
        mockRepository.reset()
        let items = mockRepository.getAllItems()
        guard let itemToDelete = items.first else {
            XCTFail("Should have at least one item")
            return
        }
        let deletedId = itemToDelete.id
        
        // When
        mockRepository.deleteItem(id: deletedId)
        let foundItem = mockRepository.getItem(byId: deletedId)
        
        // Then
        XCTAssertNil(foundItem, "Deleted item should not be found")
    }
    
    func testDictionaryLookup_AfterUpdate_ShouldReturnUpdatedItem() {
        // Given
        mockRepository.reset()
        let items = mockRepository.getAllItems()
        guard let originalItem = items.first else {
            XCTFail("Should have at least one item")
            return
        }
        
        // When
        var updatedItem = originalItem
        updatedItem.name = "Updated Name"
        updatedItem.quantity = 999
        mockRepository.updateItem(updatedItem)
        let foundItem = mockRepository.getItem(byId: originalItem.id)
        
        // Then
        XCTAssertNotNil(foundItem, "Should find updated item")
        XCTAssertEqual(foundItem?.name, "Updated Name", "Name should be updated")
        XCTAssertEqual(foundItem?.quantity, 999, "Quantity should be updated")
    }
    
    // MARK: - Binary Search Tests
    
    func testBinarySearch_WithExistingItem_ShouldReturnItem() {
        // Given
        let sortedItems = [
            Item(name: "Apple", quantity: 10, price: 1.0, category: "Food"),
            Item(name: "Banana", quantity: 20, price: 2.0, category: "Food"),
            Item(name: "Cherry", quantity: 30, price: 3.0, category: "Food"),
            Item(name: "Date", quantity: 40, price: 4.0, category: "Food"),
            Item(name: "Elderberry", quantity: 50, price: 5.0, category: "Food")
        ]
        
        // When
        let found = DataManager.shared.binarySearch(for: "Cherry", in: sortedItems)
        
        // Then
        XCTAssertNotNil(found, "Should find existing item")
        XCTAssertEqual(found?.name, "Cherry", "Should return correct item")
    }
    
    func testBinarySearch_WithNonExistentItem_ShouldReturnNil() {
        // Given
        let sortedItems = [
            Item(name: "Apple", quantity: 10, price: 1.0, category: "Food"),
            Item(name: "Banana", quantity: 20, price: 2.0, category: "Food"),
            Item(name: "Cherry", quantity: 30, price: 3.0, category: "Food")
        ]
        
        // When
        let found = DataManager.shared.binarySearch(for: "Mango", in: sortedItems)
        
        // Then
        XCTAssertNil(found, "Should return nil for non-existent item")
    }
    
    func testBinarySearch_WithEmptyArray_ShouldReturnNil() {
        // Given
        let emptyItems: [Item] = []
        
        // When
        let found = DataManager.shared.binarySearch(for: "Anything", in: emptyItems)
        
        // Then
        XCTAssertNil(found, "Should return nil for empty array")
    }
    
    func testBinarySearch_WithSingleItem_ShouldFindItem() {
        // Given
        let singleItem = [Item(name: "Only", quantity: 1, price: 1.0, category: "Test")]
        
        // When
        let found = DataManager.shared.binarySearch(for: "Only", in: singleItem)
        
        // Then
        XCTAssertNotNil(found, "Should find single item")
        XCTAssertEqual(found?.name, "Only", "Should return correct item")
    }
    
    func testBinarySearch_CaseInsensitive_ShouldFindItem() {
        // Given
        let sortedItems = [
            Item(name: "Apple", quantity: 10, price: 1.0, category: "Food"),
            Item(name: "Banana", quantity: 20, price: 2.0, category: "Food")
        ]
        
        // When
        let foundLower = DataManager.shared.binarySearch(for: "apple", in: sortedItems)
        let foundUpper = DataManager.shared.binarySearch(for: "APPLE", in: sortedItems)
        
        // Then
        XCTAssertNotNil(foundLower, "Should find with lowercase")
        XCTAssertNotNil(foundUpper, "Should find with uppercase")
    }
    
    // MARK: - Generic Binary Search Tests
    
    func testGenericBinarySearch_WithIntegers_ShouldFindIndex() {
        // Given
        let numbers = [1, 3, 5, 7, 9, 11, 13, 15]
        
        // When
        let index = AlgorithmUtilities.binarySearch(in: numbers, key: { $0 }, target: 7)
        
        // Then
        XCTAssertEqual(index, 3, "Should find correct index")
    }
    
    func testGenericBinarySearch_WithStrings_ShouldFindIndex() {
        // Given
        let words = ["apple", "banana", "cherry", "date"]
        
        // When
        let index = AlgorithmUtilities.binarySearch(in: words, key: { $0 }, target: "cherry")
        
        // Then
        XCTAssertEqual(index, 2, "Should find correct index")
    }
    
    // MARK: - Delete Operation Tests
    
    func testDelete_ShouldRemoveFromBothArrayAndDictionary() {
        // Given
        mockRepository.reset()
        let items = mockRepository.getAllItems()
        let initialCount = items.count
        guard let itemToDelete = items.first else {
            XCTFail("Should have at least one item")
            return
        }
        
        // When
        mockRepository.deleteItem(id: itemToDelete.id)
        
        // Then
        let remainingItems = mockRepository.getAllItems()
        XCTAssertEqual(remainingItems.count, initialCount - 1, "Count should decrease by 1")
        XCTAssertNil(mockRepository.getItem(byId: itemToDelete.id), "Should not find deleted item")
    }
    
    // MARK: - Low Stock Algorithm Tests
    
    func testLowStockItems_ShouldReturnItemsBelowThreshold() {
        // Given
        mockRepository.clearAll()
        mockRepository.addItem(Item(name: "Low1", quantity: 2, price: 10, category: "Test"))
        mockRepository.addItem(Item(name: "Low2", quantity: 5, price: 10, category: "Test"))
        mockRepository.addItem(Item(name: "Normal", quantity: 10, price: 10, category: "Test"))
        mockRepository.addItem(Item(name: "High", quantity: 100, price: 10, category: "Test"))
        
        viewModel = InventoryViewModel(repository: mockRepository)
        
        // Allow async load to complete
        let expectation = XCTestExpectation(description: "Load items")
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
            expectation.fulfill()
        }
        wait(for: [expectation], timeout: 1.0)
        
        // Then
        XCTAssertEqual(viewModel.lowStockCount, 2, "Should have 2 low stock items")
        XCTAssertTrue(viewModel.hasLowStockItems, "Should indicate low stock exists")
    }
    
    func testLowStockItems_WithNoLowStock_ShouldReturnEmpty() {
        // Given
        mockRepository.clearAll()
        mockRepository.addItem(Item(name: "Normal", quantity: 10, price: 10, category: "Test"))
        mockRepository.addItem(Item(name: "High", quantity: 100, price: 10, category: "Test"))
        
        viewModel = InventoryViewModel(repository: mockRepository)
        
        // Allow async load to complete
        let expectation = XCTestExpectation(description: "Load items")
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
            expectation.fulfill()
        }
        wait(for: [expectation], timeout: 1.0)
        
        // Then
        XCTAssertEqual(viewModel.lowStockCount, 0, "Should have no low stock items")
        XCTAssertFalse(viewModel.hasLowStockItems, "Should indicate no low stock")
    }
    
    // MARK: - Analytics Algorithm Tests
    
    func testTotalInventoryValue_ShouldCalculateCorrectly() {
        // Given
        mockRepository.clearAll()
        mockRepository.addItem(Item(name: "Item1", quantity: 10, price: 5.0, category: "Test"))  // 50
        mockRepository.addItem(Item(name: "Item2", quantity: 5, price: 20.0, category: "Test"))  // 100
        mockRepository.addItem(Item(name: "Item3", quantity: 2, price: 50.0, category: "Test"))  // 100
        
        viewModel = InventoryViewModel(repository: mockRepository)
        
        // Allow async load to complete
        let expectation = XCTestExpectation(description: "Load items")
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
            expectation.fulfill()
        }
        wait(for: [expectation], timeout: 1.0)
        
        // Then
        XCTAssertEqual(viewModel.totalInventoryValue, 250.0, accuracy: 0.01, "Total value should be 250")
    }
    
    func testCategoryBreakdown_ShouldGroupCorrectly() {
        // Given
        mockRepository.clearAll()
        mockRepository.addItem(Item(name: "E1", quantity: 1, price: 10, category: "Electronics"))
        mockRepository.addItem(Item(name: "E2", quantity: 1, price: 10, category: "Electronics"))
        mockRepository.addItem(Item(name: "F1", quantity: 1, price: 10, category: "Furniture"))
        
        viewModel = InventoryViewModel(repository: mockRepository)
        
        // Allow async load to complete
        let expectation = XCTestExpectation(description: "Load items")
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
            expectation.fulfill()
        }
        wait(for: [expectation], timeout: 1.0)
        
        // Then
        let breakdown = viewModel.categoryBreakdown
        XCTAssertEqual(breakdown["Electronics"], 2, "Should have 2 electronics")
        XCTAssertEqual(breakdown["Furniture"], 1, "Should have 1 furniture")
    }
    
    func testTotalQuantity_ShouldSumCorrectly() {
        // Given
        mockRepository.clearAll()
        mockRepository.addItem(Item(name: "Item1", quantity: 10, price: 5.0, category: "Test"))
        mockRepository.addItem(Item(name: "Item2", quantity: 20, price: 5.0, category: "Test"))
        mockRepository.addItem(Item(name: "Item3", quantity: 30, price: 5.0, category: "Test"))
        
        viewModel = InventoryViewModel(repository: mockRepository)
        
        // Allow async load to complete
        let expectation = XCTestExpectation(description: "Load items")
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
            expectation.fulfill()
        }
        wait(for: [expectation], timeout: 1.0)
        
        // Then
        XCTAssertEqual(viewModel.totalQuantity, 60, "Total quantity should be 60")
    }
    
    func testAverageItemPrice_ShouldCalculateCorrectly() {
        // Given
        mockRepository.clearAll()
        mockRepository.addItem(Item(name: "Item1", quantity: 1, price: 10.0, category: "Test"))
        mockRepository.addItem(Item(name: "Item2", quantity: 1, price: 20.0, category: "Test"))
        mockRepository.addItem(Item(name: "Item3", quantity: 1, price: 30.0, category: "Test"))
        
        viewModel = InventoryViewModel(repository: mockRepository)
        
        // Allow async load to complete
        let expectation = XCTestExpectation(description: "Load items")
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
            expectation.fulfill()
        }
        wait(for: [expectation], timeout: 1.0)
        
        // Then
        XCTAssertEqual(viewModel.averageItemPrice, 20.0, accuracy: 0.01, "Average price should be 20")
    }
    
    // MARK: - Data Integrity Tests
    
    func testDataIntegrity_AfterMultipleOperations_ShouldRemainSynchronized() {
        // Given
        mockRepository.clearAll()
        
        // When - perform multiple operations
        for i in 0..<10 {
            mockRepository.addItem(Item(name: "Item \(i)", quantity: i, price: Double(i), category: "Test"))
        }
        
        // Delete some items
        let items = mockRepository.getAllItems()
        if items.count >= 3 {
            mockRepository.deleteItem(id: items[0].id)
            mockRepository.deleteItem(id: items[2].id)
        }
        
        // Update an item
        if let itemToUpdate = mockRepository.getAllItems().first {
            var updated = itemToUpdate
            updated.name = "Updated"
            mockRepository.updateItem(updated)
        }
        
        // Then - verify integrity
        let finalItems = mockRepository.getAllItems()
        for item in finalItems {
            let found = mockRepository.getItem(byId: item.id)
            XCTAssertNotNil(found, "Every item in array should be in dictionary")
            XCTAssertEqual(found?.id, item.id, "IDs should match")
        }
    }
    
    // MARK: - Edge Case Tests
    
    func testOperations_WithSpecialCharacters_ShouldWork() {
        // Given
        let specialName = "Item with 'quotes' & special <chars>"
        mockRepository.clearAll()
        mockRepository.addItem(Item(name: specialName, quantity: 1, price: 10, category: "Test"))
        
        // When
        let items = mockRepository.getAllItems()
        
        // Then
        XCTAssertEqual(items.count, 1, "Should have one item")
        XCTAssertEqual(items[0].name, specialName, "Name should match with special chars")
    }
    
    func testOperations_WithUnicodeCharacters_ShouldWork() {
        // Given
        let unicodeName = "商品 🎉 Ürün"
        mockRepository.clearAll()
        mockRepository.addItem(Item(name: unicodeName, quantity: 1, price: 10, category: "Test"))
        
        // When
        let items = mockRepository.getAllItems()
        
        // Then
        XCTAssertEqual(items.count, 1, "Should have one item")
        XCTAssertEqual(items[0].name, unicodeName, "Name should match with unicode")
    }
}
