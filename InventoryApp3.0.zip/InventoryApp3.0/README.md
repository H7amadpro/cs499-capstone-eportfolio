# Inventory App - Enhanced Version 3.0

**Author:** Hamad Alghaithi  
**Course:** CS 499 - Computer Science Capstone  
**Institution:** Southern New Hampshire University  
**Version:** 3.0 (Algorithms and Data Structures Enhancement)

## Overview

This iOS Inventory Management App demonstrates software engineering proficiency through three enhancement categories:

1. **Milestone Two (Completed):** Software Design - MVVM architecture, SwiftUI, dependency injection
2. **Milestone Three (Current):** Algorithms and Data Structures - Optimized sorting, searching, and data access
3. **Milestone Four (Planned):** Database - CoreData/SQLite migration

## Milestone Three: Algorithm Enhancements

This version focuses on algorithm optimization and efficient data structure selection.

### Complexity Improvements Summary

| Operation | Algorithm Before | Complexity Before | Algorithm After | Complexity After | Improvement |
|-----------|-----------------|-------------------|-----------------|------------------|-------------|
| **Sort** | Bubble Sort | O(n²) | Timsort | O(n log n) | ~100x faster |
| **Lookup by ID** | Linear Search | O(n) | Dictionary | O(1) | Constant time |
| **Find by Name** | Linear Search | O(n) | Binary Search | O(log n) | Much faster |
| **Search** | Per keystroke | O(n) × keystrokes | Debounced | O(n) × 1 | ~80% reduction |
| **Delete** | Array rebuild | O(n) | Dictionary + removeAll | O(1) + O(n) | Cleaner |
| **Low Stock Check** | N/A | N/A | Filter | O(n) | New feature |

### Enhancement Details

#### 1. Timsort Replacement (O(n²) → O(n log n))

**Before:** Manual bubble sort implementation
```swift
// O(n²) - 1,000,000 comparisons for 1,000 items
func bubbleSort(items: [Item]) -> [Item] {
    var arr = items
    for i in 0..<n {
        for j in 0..<(n - i - 1) {
            if arr[j].name > arr[j + 1].name {
                // swap
            }
        }
    }
    return arr
}
```

**After:** Swift's built-in Timsort
```swift
// O(n log n) - ~10,000 comparisons for 1,000 items
func getAllItems() -> [Item] {
    return items.sorted { $0.name.lowercased() < $1.name.lowercased() }
}
```

#### 2. Dictionary for O(1) Lookups

**Before:** Linear search through array
```swift
// O(n) - must check every item
func getItem(byId id: String) -> Item? {
    for item in items {
        if item.id == id { return item }
    }
    return nil
}
```

**After:** Hash-based Dictionary lookup
```swift
// O(1) - instant access via hash
private var itemsById: [String: Item] = [:]

func getItem(byId id: String) -> Item? {
    return itemsById[id]  // Constant time
}
```

#### 3. Binary Search Implementation

```swift
// O(log n) - halves search space each iteration
func binarySearch(for name: String, in sortedItems: [Item]) -> Item? {
    var low = 0
    var high = sortedItems.count - 1
    let target = name.lowercased()
    
    while low <= high {
        let mid = (low + high) / 2
        let midName = sortedItems[mid].name.lowercased()
        
        if midName == target {
            return sortedItems[mid]
        } else if midName < target {
            low = mid + 1
        } else {
            high = mid - 1
        }
    }
    return nil
}
```

#### 4. Search Debouncing with Combine

**Before:** Search on every keystroke
```swift
// Typing "laptop" = 6 searches (l, la, lap, lapt, lapto, laptop)
var filteredItems: [Item] {
    return items.filter { $0.name.contains(searchText) }
}
```

**After:** Debounced search with Combine
```swift
// Typing "laptop" = 1 search after 300ms pause
private func setupSearchDebounce() {
    $searchText
        .debounce(for: .seconds(0.3), scheduler: RunLoop.main)
        .removeDuplicates()
        .sink { [weak self] query in
            self?.performDebouncedSearch(query: query)
        }
        .store(in: &cancellables)
}
```

#### 5. Analytics Algorithms

New analytics capabilities:
- Total inventory value calculation
- Category breakdown with counts
- Low stock alerts
- Most valuable items ranking

```swift
func getLowStockItems(threshold: Int = 5) -> [Item] {
    return items
        .filter { $0.quantity <= threshold }
        .sorted { $0.quantity < $1.quantity }
}

func getCategoryBreakdown() -> [String: (count: Int, totalValue: Double)] {
    // O(n) grouping algorithm
}
```

## Project Structure

```
InventoryApp/
├── App/
│   └── InventoryApp.swift           # SwiftUI App entry point
├── Models/
│   ├── Item.swift                   # Item data model
│   └── Category.swift               # Category enum
├── ViewModels/
│   ├── InventoryViewModel.swift     # Enhanced with debouncing
│   └── AddItemViewModel.swift       # Form validation
├── Views/
│   ├── InventoryView.swift          # Main list screen
│   ├── AddItemView.swift            # Add/Edit form
│   └── ItemRowView.swift            # List row component
├── Repositories/
│   ├── ItemRepositoryProtocol.swift # Repository interface
│   └── ItemRepository.swift         # Implementation + Mock
├── Services/
│   └── DataManager.swift            # Enhanced with Dictionary
├── Utilities/
│   ├── AlgorithmUtilities.swift     # NEW: Binary search, benchmarks
│   ├── ValidationError.swift        # Error types
│   └── Constants.swift              # Configuration
└── Tests/
    ├── InventoryViewModelTests.swift
    └── AlgorithmTests.swift         # NEW: Algorithm tests
```

## New Files in Milestone Three

1. **AlgorithmUtilities.swift**
   - Generic binary search implementation
   - Performance measurement utilities
   - Sorting comparison functions
   - Complexity documentation

2. **AlgorithmTests.swift**
   - Sorting correctness tests
   - Dictionary lookup tests
   - Binary search tests
   - Low stock algorithm tests
   - Analytics calculation tests
   - Data integrity verification

## Technical Specifications

- **Language:** Swift 5.9+
- **Framework:** SwiftUI, Combine
- **Minimum iOS:** 16.0
- **Architecture:** MVVM
- **Storage:** UserDefaults with Dictionary index
- **Testing:** XCTest

## Setup Instructions

1. Unzip `InventoryApp3.0.zip`
2. Open `InventoryApp.xcodeproj` in Xcode 15+
3. Select iPhone simulator (iOS 16+)
4. Build and Run (⌘R)

## Running Tests

1. Open project in Xcode
2. Press ⌘U to run all tests
3. View results in Test Navigator

### Test Coverage

- **AlgorithmTests.swift:** 25+ test cases
  - Sorting correctness
  - Dictionary O(1) lookup
  - Binary search
  - Low stock detection
  - Analytics calculations
  - Edge cases (empty, single item, unicode)

## Performance Benchmarking

The app includes built-in performance comparison:

```swift
// Compare bubble sort vs Timsort
let result = DataManager.shared.compareSortingAlgorithms()
print(result.summary)
// Output:
// Sorting Comparison (1000 items):
// - Bubble Sort O(n²): 0.234567s
// - Timsort O(n log n): 0.002345s
// - Improvement: 100.0x faster
```

## Course Outcomes Addressed

### Outcome 3: Algorithmic Principles
- Replaced O(n²) bubble sort with O(n log n) Timsort
- Implemented O(1) Dictionary lookups
- Added O(log n) binary search
- Demonstrated Big O analysis skills

### Outcome 4: Innovative Techniques
- Used Combine framework for reactive debouncing
- Implemented dual data structure (Array + Dictionary)
- Created generic, reusable algorithm utilities

## Future Enhancements (Milestone Four)

- Replace UserDefaults with CoreData
- Add cloud synchronization
- Implement data encryption
- Add user authentication

---

**Hamad Alghaithi**  
CS 499 - Computer Science Capstone  
Southern New Hampshire University
