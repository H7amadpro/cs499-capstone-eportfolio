//
//  Item.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//
//  Data model representing an inventory item
//  Enhanced from original to conform to Identifiable for SwiftUI ForEach
//

import Foundation

struct Item: Identifiable, Codable, Equatable {
    let id: String
    var name: String
    var quantity: Int
    var price: Double
    var category: String
    let createdAt: Date
    
    // MARK: - Initializers
    
    /// Creates a new item with auto-generated UUID and current timestamp
    init(name: String, quantity: Int, price: Double, category: String) {
        self.id = UUID().uuidString
        self.name = name
        self.quantity = quantity
        self.price = price
        self.category = category
        self.createdAt = Date()
    }
    
    /// Creates an item with all properties specified (used when updating existing items)
    init(id: String, name: String, quantity: Int, price: Double, category: String, createdAt: Date) {
        self.id = id
        self.name = name
        self.quantity = quantity
        self.price = price
        self.category = category
        self.createdAt = createdAt
    }
    
    // MARK: - Computed Properties
    
    /// Returns price formatted as currency string (e.g., "$19.99")
    var formattedPrice: String {
        String(format: "$%.2f", price)
    }
    
    /// Calculates total value of this item (quantity * price)
    var totalValue: Double {
        Double(quantity) * price
    }
    
    /// Returns total value formatted as currency string
    var formattedTotalValue: String {
        String(format: "$%.2f", totalValue)
    }
    
    // MARK: - Equatable
    
    static func == (lhs: Item, rhs: Item) -> Bool {
        lhs.id == rhs.id
    }
}

// MARK: - Sample Data for SwiftUI Previews

extension Item {
    /// Sample items for testing and SwiftUI previews
    static let sampleItems: [Item] = [
        Item(name: "MacBook Pro", quantity: 5, price: 1999.99, category: "Electronics"),
        Item(name: "Office Chair", quantity: 10, price: 299.99, category: "Furniture"),
        Item(name: "Notebook Pack", quantity: 50, price: 12.99, category: "Supplies"),
        Item(name: "Monitor Stand", quantity: 15, price: 79.99, category: "Accessories")
    ]
    
    static let sampleItem = sampleItems[0]
}
