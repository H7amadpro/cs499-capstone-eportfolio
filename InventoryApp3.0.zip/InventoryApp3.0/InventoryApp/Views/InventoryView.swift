//
//  InventoryView.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//
//  Main inventory list screen built with SwiftUI
//  Demonstrates modern iOS UI patterns: NavigationStack, searchable, sheets
//  Connects to InventoryViewModel following MVVM architecture
//

import SwiftUI

/// Main view displaying the inventory list with search, add, edit, and delete functionality
struct InventoryView: View {
    
    // MARK: - Properties
    
    /// ViewModel managing the inventory state - created once and owned by this view
    @StateObject private var viewModel = InventoryViewModel()
    
    /// Controls presentation of the add item sheet
    @State private var showingAddItem = false
    
    /// Currently selected item for editing (nil if none selected)
    @State private var selectedItem: Item?
    
    // MARK: - Body
    
    var body: some View {
        NavigationStack {
            ZStack {
                // Show appropriate view based on current state
                if viewModel.isLoading {
                    loadingView
                } else if viewModel.filteredItems.isEmpty {
                    emptyStateView
                } else {
                    itemListView
                }
            }
            .navigationTitle("Inventory")
            .searchable(text: $viewModel.searchText, prompt: "Search items...")
            .toolbar {
                ToolbarItem(placement: .primaryAction) {
                    addButton
                }
                
                ToolbarItem(placement: .bottomBar) {
                    summaryView
                }
            }
            // Sheet for adding new items
            .sheet(isPresented: $showingAddItem) {
                AddItemView {
                    viewModel.refresh()
                }
            }
            // Sheet for editing existing items
            .sheet(item: $selectedItem) { item in
                AddItemView(item: item) {
                    viewModel.refresh()
                }
            }
            // Pull-to-refresh functionality
            .refreshable {
                viewModel.refresh()
            }
            // Error alert
            .alert("Error", isPresented: .constant(viewModel.errorMessage != nil)) {
                Button("OK") {
                    viewModel.clearError()
                }
            } message: {
                Text(viewModel.errorMessage ?? "")
            }
        }
    }
    
    // MARK: - Subviews
    
    /// Loading indicator shown while fetching data
    private var loadingView: some View {
        ProgressView("Loading inventory...")
            .progressViewStyle(CircularProgressViewStyle())
    }
    
    /// Empty state view when no items exist or search returns no results
    private var emptyStateView: some View {
        VStack(spacing: 16) {
            Image(systemName: "shippingbox")
                .font(.system(size: 60))
                .foregroundColor(.secondary)
            
            Text(viewModel.searchText.isEmpty ? "No Items Yet" : "No Results")
                .font(.title2)
                .fontWeight(.semibold)
            
            Text(viewModel.searchText.isEmpty
                 ? "Tap the + button to add your first inventory item."
                 : "Try a different search term.")
                .font(.subheadline)
                .foregroundColor(.secondary)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 40)
            
            if viewModel.searchText.isEmpty {
                Button(action: { showingAddItem = true }) {
                    Label("Add Item", systemImage: "plus")
                        .font(.headline)
                }
                .buttonStyle(.borderedProminent)
                .padding(.top, 8)
            }
        }
    }
    
    /// List view displaying all inventory items
    private var itemListView: some View {
        List {
            ForEach(viewModel.filteredItems) { item in
                ItemRowView(item: item)
                    .contentShape(Rectangle())
                    .onTapGesture {
                        selectedItem = item
                    }
            }
            .onDelete(perform: viewModel.deleteItem)
        }
        .listStyle(.insetGrouped)
    }
    
    /// Add button in navigation bar
    private var addButton: some View {
        Button(action: { showingAddItem = true }) {
            Image(systemName: "plus")
        }
    }
    
    /// Summary statistics shown in bottom toolbar
    private var summaryView: some View {
        HStack {
            VStack(alignment: .leading) {
                Text("\(viewModel.totalItemCount) items")
                    .font(.caption)
                    .foregroundColor(.secondary)

                if viewModel.hasLowStockItems {
                    Label("\(viewModel.lowStockCount) low stock", systemImage: "exclamationmark.triangle.fill")
                        .font(.caption2)
                        .foregroundColor(.red)
                }
            }
            
            Spacer()
            
            VStack(alignment: .trailing) {
                Text("Total Value")
                    .font(.caption)
                    .foregroundColor(.secondary)
                Text(viewModel.formattedTotalValue)
                    .font(.subheadline)
                    .fontWeight(.semibold)
            }
        }
    }
}

// MARK: - Preview

struct InventoryView_Previews: PreviewProvider {
    static var previews: some View {
        InventoryView()
    }
}
