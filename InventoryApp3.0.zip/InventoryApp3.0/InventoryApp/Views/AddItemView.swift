//
//  AddItemView.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//
//  SwiftUI form for adding and editing inventory items
//  Uses AddItemViewModel for state management and validation
//  Demonstrates SwiftUI Form, navigation, and sheet presentation
//

import SwiftUI

/// View presenting a form for adding or editing inventory items
struct AddItemView: View {
    
    // MARK: - Properties
    
    /// ViewModel managing form state and validation
    @StateObject private var viewModel: AddItemViewModel
    
    /// Environment value to dismiss this view
    @Environment(\.dismiss) private var dismiss
    
    /// Optional callback invoked when item is saved successfully
    var onSave: (() -> Void)?
    
    // MARK: - Initialization
    
    /// Creates view for adding a new item
    init(onSave: (() -> Void)? = nil) {
        _viewModel = StateObject(wrappedValue: AddItemViewModel())
        self.onSave = onSave
    }
    
    /// Creates view for editing an existing item
    init(item: Item, onSave: (() -> Void)? = nil) {
        _viewModel = StateObject(wrappedValue: AddItemViewModel(item: item))
        self.onSave = onSave
    }
    
    // MARK: - Body
    
    var body: some View {
        NavigationStack {
            Form {
                // Item details input section
                Section {
                    nameField
                    quantityField
                    priceField
                } header: {
                    Text("Item Details")
                }
                
                // Category selection section
                Section {
                    categoryPicker
                } header: {
                    Text("Category")
                }
                
                // Validation error display section
                if let error = viewModel.validationError {
                    Section {
                        errorView(message: error)
                    }
                }
            }
            .navigationTitle(viewModel.navigationTitle)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                // Cancel button - dismisses without saving
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") {
                        dismiss()
                    }
                }
                
                // Save button - validates and saves item
                ToolbarItem(placement: .confirmationAction) {
                    Button(viewModel.saveButtonTitle) {
                        saveItem()
                    }
                    .disabled(viewModel.isSaving)
                }
            }
            // Dismiss view when save is successful (iOS 16 compatible syntax)
            .onChange(of: viewModel.didSaveSuccessfully) { success in
                if success {
                    onSave?()
                    dismiss()
                }
            }
        }
    }
    
    // MARK: - Form Fields
    
    /// Text field for item name input
    private var nameField: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text("Name")
                .font(.caption)
                .foregroundColor(.secondary)
            
            TextField("Enter item name", text: $viewModel.name)
                .textContentType(.name)
                .autocorrectionDisabled()
        }
    }
    
    /// Text field for quantity input with numeric keyboard
    private var quantityField: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text("Quantity")
                .font(.caption)
                .foregroundColor(.secondary)
            
            TextField("Enter quantity", text: $viewModel.quantity)
                .keyboardType(.numberPad)
        }
    }
    
    /// Text field for price input with decimal keyboard
    private var priceField: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text("Price")
                .font(.caption)
                .foregroundColor(.secondary)
            
            HStack {
                Text("$")
                    .foregroundColor(.secondary)
                
                TextField("0.00", text: $viewModel.price)
                    .keyboardType(.decimalPad)
            }
        }
    }
    
    /// Picker for selecting item category
    private var categoryPicker: some View {
        Picker("Select Category", selection: $viewModel.category) {
            Text("Select a category")
                .tag("")
            
            ForEach(Category.allCases) { category in
                Label(category.displayName, systemImage: category.iconName)
                    .tag(category.rawValue)
            }
        }
        .pickerStyle(.navigationLink)
    }
    
    /// Displays validation error message with warning icon
    private func errorView(message: String) -> some View {
        HStack {
            Image(systemName: "exclamationmark.triangle.fill")
                .foregroundColor(.red)
            
            Text(message)
                .foregroundColor(.red)
                .font(.subheadline)
        }
    }
    
    // MARK: - Actions
    
    /// Triggers save operation through ViewModel
    private func saveItem() {
        viewModel.save()
    }
}

// MARK: - Preview

struct AddItemView_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            // Preview in add mode
            AddItemView()
            
            // Preview in edit mode
            AddItemView(item: Item.sampleItem)
        }
    }
}
