//
//  ItemRepository.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//
//  Concrete implementation of ItemRepositoryProtocol
//  Wraps DataManager and provides a clean interface for data operations
//  Can be easily swapped for CoreData implementation in future enhancement
//

import Foundation

/// Production implementation of ItemRepositoryProtocol
/// Uses DataManager singleton for actual data persistence
final class ItemRepository: ItemRepositoryProtocol {
    
    // MARK: - Properties
    
    /// Reference to the data manager for persistence operations
    private let dataManager: DataManager
    
    // MARK: - Initialization
    
    /// Creates a repository using the shared DataManager instance
    init() {
        self.dataManager = DataManager.shared
    }
    
    /// Creates a repository with a custom DataManager (useful for testing)
    init(dataManager: DataManager) {
        self.dataManager = dataManager
    }
    
    // MARK: - ItemRepositoryProtocol Implementation
    
    func getAllItems() -> [Item] {
        dataManager.getAllItems()
    }
    
    func addItem(_ item: Item) {
        dataManager.addItem(item)
    }
    
    func updateItem(_ item: Item) {
        dataManager.updateItem(item)
    }
    
    func deleteItem(id: String) {
        dataManager.deleteItem(id: id)
    }
    
    func searchItems(query: String) -> [Item] {
        dataManager.searchItems(query: query)
    }
    
    func getItem(byId id: String) -> Item? {
        dataManager.getItem(byId: id)
    }
}

// MARK: - Mock Repository for Testing

/// Mock implementation of ItemRepositoryProtocol for unit testing and SwiftUI previews
/// Uses in-memory storage with Dictionary for O(1) lookups (mirrors production implementation)
/// 
/// ENHANCEMENT: Added Dictionary for O(1) lookups to match DataManager implementation
final class MockItemRepository: ItemRepositoryProtocol {
    
    // MARK: - Properties
    
    /// Primary storage - Array for ordered access
    private var items: [Item] = Item.sampleItems
    
    /// ENHANCEMENT: Secondary storage - Dictionary for O(1) lookups by ID
    /// Mirrors the production DataManager implementation
    private var itemsById: [String: Item] = [:]
    
    // MARK: - Initialization
    
    init() {
        rebuildDictionary()
    }
    
    // MARK: - Private Methods
    
    /// Rebuilds the Dictionary index from the array
    /// Time Complexity: O(n)
    private func rebuildDictionary() {
        itemsById = Dictionary(uniqueKeysWithValues: items.map { ($0.id, $0) })
    }
    
    // MARK: - ItemRepositoryProtocol Implementation
    
    /// Returns all items sorted alphabetically by name
    /// Uses Timsort O(n log n)
    func getAllItems() -> [Item] {
        items.sorted { $0.name.lowercased() < $1.name.lowercased() }
    }
    
    /// Adds a new item
    /// Updates both array and dictionary - O(1) amortized
    func addItem(_ item: Item) {
        items.append(item)
        itemsById[item.id] = item  // O(1) dictionary insert
    }
    
    /// Updates an existing item
    /// Updates both array and dictionary
    func updateItem(_ item: Item) {
        // Update dictionary - O(1)
        itemsById[item.id] = item
        
        // Update array - O(n) to find index
        if let index = items.firstIndex(where: { $0.id == item.id }) {
            items[index] = item
        }
    }
    
    /// Deletes an item by ID
    /// Removes from both array and dictionary
    func deleteItem(id: String) {
        itemsById.removeValue(forKey: id)  // O(1)
        items.removeAll { $0.id == id }     // O(n)
    }
    
    /// Searches items by query string
    func searchItems(query: String) -> [Item] {
        guard !query.isEmpty else { return getAllItems() }
        let lowercaseQuery = query.lowercased()
        return items
            .filter { item in
                item.name.lowercased().contains(lowercaseQuery) ||
                item.category.lowercased().contains(lowercaseQuery)
            }
            .sorted { $0.name.lowercased() < $1.name.lowercased() }
    }
    
    /// ENHANCEMENT: Uses Dictionary for O(1) lookup instead of O(n) linear search
    /// Before: items.first { $0.id == id } - O(n)
    /// After: itemsById[id] - O(1)
    func getItem(byId id: String) -> Item? {
        return itemsById[id]  // O(1) hash-based lookup
    }
    
    // MARK: - Test Helpers
    
    /// Resets repository to initial sample data (useful between tests)
    func reset() {
        items = Item.sampleItems
        rebuildDictionary()
    }
    
    /// Clears all items (useful for testing empty state)
    func clearAll() {
        items = []
        itemsById = [:]
    }
    
    /// Verifies array and dictionary are synchronized
    func verifyDataIntegrity() -> Bool {
        guard items.count == itemsById.count else {
            return false
        }
        for item in items {
            guard itemsById[item.id] != nil else {
                return false
            }
        }
        return true
    }
}
