//
//  InventoryViewModel.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//
//  MILESTONE THREE: Algorithms and Data Structures Enhancement
//
//  This ViewModel demonstrates:
//  - Search debouncing using Combine framework (300ms delay)
//  - Efficient computed properties for analytics
//  - Proper cancellable management for memory safety
//  - Low stock alert functionality
//

import Foundation
import Combine

/// ViewModel responsible for managing inventory list state and business logic
/// 
/// Algorithm Improvements in this version:
/// - Search Debouncing: Reduces search operations by ~80%
///   Before: O(n) search on every keystroke (typing "laptop" = 6 searches)
///   After: O(n) search once after 300ms pause (typing "laptop" = 1 search)
final class InventoryViewModel: ObservableObject {
    
    // MARK: - Published Properties
    
    /// All inventory items loaded from the repository
    @Published private(set) var items: [Item] = []
    
    /// Current search query entered by the user
    @Published var searchText: String = ""
    
    /// ENHANCEMENT: Filtered items updated via debounced search
    /// This is updated 300ms after user stops typing
    @Published private(set) var debouncedFilteredItems: [Item] = []
    
    /// Indicates whether data is currently being loaded
    @Published private(set) var isLoading: Bool = false
    
    /// Error message to display to the user (nil if no error)
    @Published var errorMessage: String?
    
    /// ENHANCEMENT: Low stock items for alert display
    @Published private(set) var lowStockItems: [Item] = []
    
    // MARK: - Computed Properties
    
    /// Returns items filtered by the current search text
    /// Uses debounced results for better performance
    var filteredItems: [Item] {
        guard !searchText.isEmpty else {
            return items
        }
        return debouncedFilteredItems
    }
    
    /// Total number of items in inventory
    /// Time Complexity: O(1)
    var totalItemCount: Int {
        items.count
    }
    
    /// Calculates total value of all inventory items
    /// Time Complexity: O(n)
    var totalInventoryValue: Double {
        items.reduce(0) { $0 + $1.totalValue }
    }
    
    /// Returns formatted string of total inventory value
    var formattedTotalValue: String {
        String(format: "$%.2f", totalInventoryValue)
    }
    
    /// ENHANCEMENT: Category breakdown for analytics
    /// Returns dictionary with category name and item count
    /// Time Complexity: O(n)
    var categoryBreakdown: [String: Int] {
        Dictionary(grouping: items) { $0.category }
            .mapValues { $0.count }
    }
    
    /// ENHANCEMENT: Total quantity of all items
    /// Time Complexity: O(n)
    var totalQuantity: Int {
        items.reduce(0) { $0 + $1.quantity }
    }
    
    /// ENHANCEMENT: Average item price
    /// Time Complexity: O(n)
    var averageItemPrice: Double {
        guard !items.isEmpty else { return 0 }
        return items.reduce(0) { $0 + $1.price } / Double(items.count)
    }
    
    /// ENHANCEMENT: Check if there are low stock items
    var hasLowStockItems: Bool {
        !lowStockItems.isEmpty
    }
    
    /// ENHANCEMENT: Count of low stock items for badge display
    var lowStockCount: Int {
        lowStockItems.count
    }
    
    // MARK: - Private Properties
    
    /// Repository for data access - injected through initializer
    private let repository: ItemRepositoryProtocol
    
    /// ENHANCEMENT: Set to store Combine subscriptions
    /// Properly managed to prevent memory leaks
    private var cancellables = Set<AnyCancellable>()
    
    /// ENHANCEMENT: Debounce interval in seconds
    /// 300ms is optimal balance between responsiveness and efficiency
    private let debounceInterval: TimeInterval = Constants.UI.searchDebounceInterval
    
    /// ENHANCEMENT: Low stock threshold
    private let lowStockThreshold: Int = 5
    
    // MARK: - Initialization
    
    /// Creates ViewModel with dependency injection
    /// - Parameter repository: Data repository (defaults to production ItemRepository)
    init(repository: ItemRepositoryProtocol = ItemRepository()) {
        self.repository = repository
        setupSearchDebounce()
        loadItems()
    }
    
    // MARK: - Private Methods
    
    /// ENHANCEMENT: Configures debounced search using Combine
    /// 
    /// This is a key algorithm optimization:
    /// - Before: Search executed on every keystroke
    ///   Typing "laptop" = 6 searches (l, la, lap, lapt, lapto, laptop)
    /// - After: Search executed 300ms after user stops typing
    ///   Typing "laptop" = 1 search
    /// - Improvement: ~83% reduction in search operations
    private func setupSearchDebounce() {
        $searchText
            // Wait 300ms after user stops typing
            .debounce(for: .seconds(debounceInterval), scheduler: RunLoop.main)
            // Remove duplicate consecutive values
            .removeDuplicates()
            // Execute search when value changes
            .sink { [weak self] searchQuery in
                self?.performDebouncedSearch(query: searchQuery)
            }
            .store(in: &cancellables)
    }
    
    /// Performs the actual search after debounce delay
    /// Time Complexity: O(n) for filtering
    /// Note: `items` is already sorted, and `filter` preserves order, so no extra sort is needed.
    /// 
    /// - Parameter query: The search query string
    private func performDebouncedSearch(query: String) {
        guard !query.isEmpty else {
            debouncedFilteredItems = items
            return
        }
        
        let lowercaseQuery = query.lowercased()
        
        // O(n) filter operation - but only runs once per search
        debouncedFilteredItems = items.filter { item in
            item.name.lowercased().contains(lowercaseQuery) ||
            item.category.lowercased().contains(lowercaseQuery)
        }
    }
    
    /// Updates low stock items list
    /// Time Complexity: O(n)
    private func updateLowStockItems() {
        lowStockItems = items.filter { $0.quantity <= lowStockThreshold }
            .sorted { $0.quantity < $1.quantity }
    }
    
    // MARK: - Public Methods
    
    /// Loads all items from the repository
    /// Also updates analytics and low stock alerts
    func loadItems() {
        isLoading = true
        errorMessage = nil

        let loadedItems = repository.getAllItems()
        let applyLoadedItems = { [weak self] in
            guard let self else { return }
            self.items = loadedItems
            // Keep debounced results consistent with current query, even after refresh/add/delete.
            self.performDebouncedSearch(query: self.searchText)
            self.updateLowStockItems()
            self.isLoading = false
        }

        // Avoid an extra run-loop hop (and UI flicker) when we're already on the main thread.
        if Thread.isMainThread {
            applyLoadedItems()
        } else {
            DispatchQueue.main.async(execute: applyLoadedItems)
        }
    }
    
    /// Deletes a specific item from inventory
    /// - Parameter item: The item to delete
    func deleteItem(_ item: Item) {
        repository.deleteItem(id: item.id)
        loadItems()
    }
    
    /// Deletes items at specified index positions (used by SwiftUI onDelete modifier)
    /// - Parameter offsets: IndexSet of items to delete
    func deleteItem(at offsets: IndexSet) {
        for index in offsets {
            let item = filteredItems[index]
            repository.deleteItem(id: item.id)
        }
        loadItems()
    }
    
    /// Clears any displayed error message
    func clearError() {
        errorMessage = nil
    }
    
    /// Refreshes the item list from repository
    func refresh() {
        loadItems()
    }
    
    // MARK: - Analytics Methods
    
    /// ENHANCEMENT: Gets items by category
    /// Time Complexity: O(n)
    /// 
    /// - Parameter category: The category to filter by
    /// - Returns: Array of items in the specified category
    func getItems(inCategory category: String) -> [Item] {
        items.filter { $0.category == category }
    }
    
    /// ENHANCEMENT: Gets total value for a specific category
    /// Time Complexity: O(n)
    /// 
    /// - Parameter category: The category to calculate value for
    /// - Returns: Total value of items in the category
    func getTotalValue(forCategory category: String) -> Double {
        getItems(inCategory: category).reduce(0) { $0 + $1.totalValue }
    }
    
    /// ENHANCEMENT: Gets most valuable items
    /// Time Complexity: O(n log n) for sorting
    /// 
    /// - Parameter count: Number of items to return
    /// - Returns: Top items by total value
    func getMostValuableItems(count: Int = 5) -> [Item] {
        Array(items.sorted { $0.totalValue > $1.totalValue }.prefix(count))
    }
    
    /// ENHANCEMENT: Binary search for exact item name match
    /// Uses the optimized binary search from DataManager
    /// Time Complexity: O(log n)
    /// 
    /// - Parameter name: Exact name to search for
    /// - Returns: The item if found, nil otherwise
    func findItem(byExactName name: String) -> Item? {
        // Items are already sorted, use binary search
        return DataManager.shared.binarySearch(for: name, in: items)
    }
    
    // MARK: - Cleanup
    
    /// Cancels all subscriptions when ViewModel is deallocated
    deinit {
        cancellables.forEach { $0.cancel() }
    }
}
