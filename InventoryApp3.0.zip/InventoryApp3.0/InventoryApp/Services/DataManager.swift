//
//  DataManager.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//
//  MILESTONE THREE: Algorithms and Data Structures Enhancement
//
//  This file demonstrates:
//  - O(n log n) Timsort instead of O(n²) Bubble Sort
//  - O(1) Dictionary lookups instead of O(n) Linear Search
//  - O(log n) Binary Search for sorted data
//  - Proper data structure synchronization
//

import Foundation

/// Singleton class responsible for data persistence and optimized data access
/// 
/// Algorithm Improvements:
/// - Sorting: O(n²) bubble sort → O(n log n) Timsort
/// - Lookup by ID: O(n) linear → O(1) Dictionary
/// - Search by name: O(n) linear → O(log n) binary search
final class DataManager {
    
    // MARK: - Singleton
    
    static let shared = DataManager()
    
    // MARK: - Properties
    
    /// UserDefaults key for persistence
    private let userDefaultsKey = Constants.Storage.userDefaultsKey
    
    /// Primary storage - Array for ordered access and iteration
    /// Time Complexity: O(n) for search, O(1) for index access
    private var items: [Item] = []
    
    /// ENHANCEMENT: Secondary storage - Dictionary for O(1) lookups by ID
    /// Space Complexity: O(n) additional space
    /// Time Complexity: O(1) for lookup, insert, delete
    private var itemsById: [String: Item] = [:]
    
    // MARK: - Initialization
    
    private init() {
        loadItems()
    }
    
    // MARK: - Persistence
    
    /// Loads items from UserDefaults and builds the Dictionary index
    func loadItems() {
        if let data = UserDefaults.standard.data(forKey: userDefaultsKey) {
            let decoder = JSONDecoder()
            if let decoded = try? decoder.decode([Item].self, from: data) {
                items = decoded
                rebuildDictionary()
            }
        }
    }
    
    /// Saves items to UserDefaults
    private func saveItems() {
        let encoder = JSONEncoder()
        if let data = try? encoder.encode(items) {
            UserDefaults.standard.set(data, forKey: userDefaultsKey)
        }
    }
    
    /// Rebuilds the Dictionary index from the array
    /// Called after loading or when synchronization is needed
    /// Time Complexity: O(n)
    private func rebuildDictionary() {
        itemsById = Dictionary(uniqueKeysWithValues: items.map { ($0.id, $0) })
    }
    
    // MARK: - CRUD Operations
    
    /// Returns all items sorted alphabetically by name
    /// 
    /// ENHANCEMENT: Uses Swift's Timsort O(n log n) instead of Bubble Sort O(n²)
    /// For 1,000 items: ~10,000 operations vs ~1,000,000 operations
    /// 
    /// Time Complexity: O(n log n)
    func getAllItems() -> [Item] {
        return items.sorted { $0.name.lowercased() < $1.name.lowercased() }
    }
    
    /// Adds a new item to storage
    /// Updates both array and dictionary to maintain synchronization
    /// 
    /// Time Complexity: O(1) amortized
    func addItem(_ item: Item) {
        items.append(item)
        itemsById[item.id] = item  // O(1) dictionary insert
        saveItems()
    }
    
    /// Updates an existing item
    /// Updates both array and dictionary to maintain synchronization
    /// 
    /// Time Complexity: O(n) for array update, O(1) for dictionary
    func updateItem(_ item: Item) {
        // Update in dictionary - O(1)
        itemsById[item.id] = item
        
        // Update in array - O(n) to find index
        if let index = items.firstIndex(where: { $0.id == item.id }) {
            items[index] = item
        }
        
        saveItems()
    }
    
    /// Deletes an item by ID
    /// Removes from both array and dictionary
    /// 
    /// ENHANCEMENT: Dictionary removal is O(1)
    /// Time Complexity: O(1) for dictionary + O(n) for array
    func deleteItem(id: String) {
        itemsById.removeValue(forKey: id)  // O(1)
        items.removeAll { $0.id == id }     // O(n)
        saveItems()
    }
    
    // MARK: - Search Operations
    
    /// Retrieves an item by its unique ID
    /// 
    /// ENHANCEMENT: Uses Dictionary for O(1) lookup instead of O(n) linear search
    /// 
    /// Before (Linear Search):
    /// ```
    /// for item in items {
    ///     if item.id == id { return item }
    /// }
    /// ```
    /// Time Complexity: O(n)
    /// 
    /// After (Dictionary Lookup):
    /// Time Complexity: O(1) average case
    func getItem(byId id: String) -> Item? {
        return itemsById[id]  // O(1) hash-based lookup
    }
    
    /// Searches items by query string (name or category)
    /// 
    /// Time Complexity: O(n) for filtering + O(m log m) for sorting matches
    func searchItems(query: String) -> [Item] {
        guard !query.isEmpty else {
            return getAllItems()
        }
        
        let lowercaseQuery = query.lowercased()
        return items
            .filter { item in
                item.name.lowercased().contains(lowercaseQuery) ||
                item.category.lowercased().contains(lowercaseQuery)
            }
            .sorted { $0.name.lowercased() < $1.name.lowercased() }
    }
    
    // MARK: - Binary Search
    
    /// Binary search for exact name match in a sorted array
    /// 
    /// ENHANCEMENT: O(log n) instead of O(n) linear search
    /// For 1,000 items: ~10 comparisons vs ~1,000 comparisons
    /// 
    /// Prerequisites: Array must be sorted by name (ascending)
    /// 
    /// Time Complexity: O(log n)
    /// Space Complexity: O(1)
    /// 
    /// - Parameters:
    ///   - name: Exact name to search for (case-insensitive)
    ///   - sortedItems: Array sorted alphabetically by name
    /// - Returns: The item if found, nil otherwise
    func binarySearch(for name: String, in sortedItems: [Item]) -> Item? {
        var low = 0
        var high = sortedItems.count - 1
        let target = name.lowercased()
        
        while low <= high {
            let mid = (low + high) / 2
            let midName = sortedItems[mid].name.lowercased()
            
            if midName == target {
                return sortedItems[mid]
            } else if midName < target {
                low = mid + 1
            } else {
                high = mid - 1
            }
        }
        
        return nil
    }
    
    // MARK: - Analytics
    
    /// Returns items with quantity at or below threshold
    /// 
    /// Time Complexity: O(n) for filter + O(m log m) for sorting
    func getLowStockItems(threshold: Int = 5) -> [Item] {
        return items
            .filter { $0.quantity <= threshold }
            .sorted { $0.quantity < $1.quantity }
    }
    
    /// Calculates total inventory value
    /// 
    /// Time Complexity: O(n)
    func getTotalInventoryValue() -> Double {
        return items.reduce(0) { $0 + $1.totalValue }
    }
    
    /// Returns category breakdown with counts
    /// 
    /// Time Complexity: O(n)
    func getCategoryBreakdown() -> [String: Int] {
        return Dictionary(grouping: items) { $0.category }
            .mapValues { $0.count }
    }
    
    // MARK: - Performance Comparison (For Demonstration)
    
    /// Compares bubble sort vs Timsort performance
    /// Used for demonstrating algorithm improvements
    func compareSortingAlgorithms() -> SortingComparisonResult {
        return AlgorithmUtilities.compareSortingAlgorithms(
            items: items,
            by: { $0.name.lowercased() < $1.name.lowercased() }
        )
    }
    
    // MARK: - Data Integrity
    
    /// Verifies array and dictionary are synchronized
    /// Used for debugging and testing
    func verifyDataIntegrity() -> Bool {
        // Check counts match
        guard items.count == itemsById.count else {
            print("❌ Count mismatch: Array=\(items.count), Dict=\(itemsById.count)")
            return false
        }
        
        // Check every array item exists in dictionary
        for item in items {
            guard let dictItem = itemsById[item.id], dictItem.id == item.id else {
                print("❌ Item \(item.id) not found in dictionary")
                return false
            }
        }
        
        print("✅ Data integrity verified: \(items.count) items synchronized")
        return true
    }
}
