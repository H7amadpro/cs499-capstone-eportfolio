//
//  Constants.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//
//  App-wide constants and configuration values
//  Centralizes magic numbers and strings for maintainability
//  Makes it easy to adjust app behavior from a single location
//

import Foundation

/// Namespace for app-wide constant values
enum Constants {
    
    // MARK: - Validation Constants
    
    /// Constants related to input validation rules
    enum Validation {
        /// Maximum allowed length for item names
        static let maxNameLength = 200
        
        /// Minimum allowed quantity value
        static let minQuantity = 0
        
        /// Minimum allowed price value
        static let minPrice: Double = 0.0
    }
    
    // MARK: - Storage Constants
    
    /// Constants related to data persistence
    enum Storage {
        /// Key used to store items in UserDefaults
        static let userDefaultsKey = "inventory_items"
    }
    
    // MARK: - UI Constants
    
    /// Constants related to user interface behavior
    enum UI {
        /// Delay before search filter is applied (prevents excessive filtering)
        static let searchDebounceInterval: TimeInterval = 0.3
        
        /// Standard animation duration for UI transitions
        static let animationDuration: TimeInterval = 0.3
    }
}
