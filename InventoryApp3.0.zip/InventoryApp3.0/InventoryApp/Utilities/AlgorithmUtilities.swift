//
//  AlgorithmUtilities.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//
//  MILESTONE THREE: Algorithms and Data Structures Enhancement
//
//  This file contains:
//  - Generic binary search implementation
//  - Performance measurement utilities
//  - Algorithm complexity documentation
//  - Sorting comparison utilities
//

import Foundation

// MARK: - Algorithm Utilities

/// Namespace for algorithm utility functions
/// Provides generic, reusable algorithm implementations
enum AlgorithmUtilities {
    
    // MARK: - Binary Search
    
    /// Generic binary search implementation
    /// 
    /// Time Complexity: O(log n)
    /// Space Complexity: O(1)
    /// 
    /// Prerequisites:
    /// - Array must be sorted in ascending order by the key
    /// - Key must be Comparable
    /// 
    /// - Parameters:
    ///   - array: Sorted array to search
    ///   - key: Key extractor closure
    ///   - target: Target value to find
    /// - Returns: Index of the element if found, nil otherwise
    static func binarySearch<T, K: Comparable>(
        in array: [T],
        key: (T) -> K,
        target: K
    ) -> Int? {
        var low = 0
        var high = array.count - 1
        
        while low <= high {
            let mid = (low + high) / 2
            let midKey = key(array[mid])
            
            if midKey == target {
                return mid
            } else if midKey < target {
                low = mid + 1
            } else {
                high = mid - 1
            }
        }
        
        return nil
    }
    
    /// Binary search that returns the element instead of index
    /// 
    /// Time Complexity: O(log n)
    /// 
    /// - Parameters:
    ///   - array: Sorted array to search
    ///   - key: Key extractor closure
    ///   - target: Target value to find
    /// - Returns: The element if found, nil otherwise
    static func binarySearchElement<T, K: Comparable>(
        in array: [T],
        key: (T) -> K,
        target: K
    ) -> T? {
        guard let index = binarySearch(in: array, key: key, target: target) else {
            return nil
        }
        return array[index]
    }
    
    /// Binary search for finding insertion point (lower bound)
    /// Returns the index where target should be inserted to maintain sorted order
    /// 
    /// Time Complexity: O(log n)
    /// 
    /// - Parameters:
    ///   - array: Sorted array
    ///   - key: Key extractor closure
    ///   - target: Target value
    /// - Returns: Index where target should be inserted
    static func lowerBound<T, K: Comparable>(
        in array: [T],
        key: (T) -> K,
        target: K
    ) -> Int {
        var low = 0
        var high = array.count
        
        while low < high {
            let mid = (low + high) / 2
            if key(array[mid]) < target {
                low = mid + 1
            } else {
                high = mid
            }
        }
        
        return low
    }
    
    // MARK: - Performance Measurement
    
    /// Measures execution time of a code block
    /// 
    /// - Parameters:
    ///   - label: Description of the operation
    ///   - iterations: Number of times to run (for averaging)
    ///   - block: Code block to measure
    /// - Returns: Average execution time in seconds
    @discardableResult
    static func measureTime(
        label: String,
        iterations: Int = 1,
        block: () -> Void
    ) -> Double {
        var totalTime: Double = 0
        
        for _ in 0..<iterations {
            let start = CFAbsoluteTimeGetCurrent()
            block()
            let end = CFAbsoluteTimeGetCurrent()
            totalTime += (end - start)
        }
        
        let averageTime = totalTime / Double(iterations)
        print("⏱ \(label): \(String(format: "%.6f", averageTime)) seconds (avg of \(iterations) runs)")
        return averageTime
    }
    
    /// Measures and returns execution time with result
    /// 
    /// - Parameters:
    ///   - label: Description of the operation
    ///   - block: Code block to measure
    /// - Returns: Tuple of (result, executionTime)
    static func measureTimeWithResult<T>(
        label: String,
        block: () -> T
    ) -> (result: T, time: Double) {
        let start = CFAbsoluteTimeGetCurrent()
        let result = block()
        let end = CFAbsoluteTimeGetCurrent()
        let time = end - start
        print("⏱ \(label): \(String(format: "%.6f", time)) seconds")
        return (result, time)
    }
    
    // MARK: - Sorting Comparison
    
    /// Compares different sorting algorithms
    /// For educational demonstration of Big O complexity
    /// 
    /// - Parameter items: Array of items to sort
    /// - Returns: Comparison results
    static func compareSortingAlgorithms<T>(
        items: [T],
        by areInIncreasingOrder: @escaping (T, T) -> Bool
    ) -> SortingComparisonResult {
        
        // Measure bubble sort O(n²)
        var bubbleArray = items
        let bubbleTime = measureTime(label: "Bubble Sort O(n²)") {
            bubbleSort(&bubbleArray, by: areInIncreasingOrder)
        }
        
        // Measure Swift's Timsort O(n log n)
        let timsortTime = measureTime(label: "Timsort O(n log n)") {
            _ = items.sorted(by: areInIncreasingOrder)
        }
        
        let speedup = bubbleTime / max(timsortTime, 0.000001)
        
        print("📊 Sorting Comparison Summary:")
        print("   Items: \(items.count)")
        print("   Bubble Sort: \(String(format: "%.6f", bubbleTime))s")
        print("   Timsort: \(String(format: "%.6f", timsortTime))s")
        print("   Speedup: \(String(format: "%.1f", speedup))x faster")
        
        return SortingComparisonResult(
            itemCount: items.count,
            bubbleSortTime: bubbleTime,
            timsortTime: timsortTime,
            speedup: speedup
        )
    }
    
    /// Bubble sort implementation for comparison purposes
    /// DO NOT USE IN PRODUCTION - O(n²) complexity
    private static func bubbleSort<T>(
        _ array: inout [T],
        by areInIncreasingOrder: (T, T) -> Bool
    ) {
        let n = array.count
        for i in 0..<n {
            for j in 0..<(n - i - 1) {
                if !areInIncreasingOrder(array[j], array[j + 1]) {
                    let temp = array[j]
                    array[j] = array[j + 1]
                    array[j + 1] = temp
                }
            }
        }
    }
    
    // MARK: - Lookup Comparison
    
    /// Compares linear search vs Dictionary lookup
    /// 
    /// - Parameters:
    ///   - array: Array to search
    ///   - dictionary: Dictionary to search
    ///   - key: Key to search for
    /// - Returns: Comparison results
    static func compareLookupAlgorithms<K: Hashable, V>(
        array: [(key: K, value: V)],
        dictionary: [K: V],
        searchKey: K
    ) -> LookupComparisonResult {
        
        // Measure linear search O(n)
        let linearTime = measureTime(label: "Linear Search O(n)") {
            _ = array.first { $0.key == searchKey }
        }
        
        // Measure Dictionary lookup O(1)
        let dictionaryTime = measureTime(label: "Dictionary Lookup O(1)") {
            _ = dictionary[searchKey]
        }
        
        let speedup = linearTime / max(dictionaryTime, 0.000001)
        
        print("📊 Lookup Comparison Summary:")
        print("   Items: \(array.count)")
        print("   Linear Search: \(String(format: "%.6f", linearTime))s")
        print("   Dictionary: \(String(format: "%.6f", dictionaryTime))s")
        print("   Speedup: \(String(format: "%.1f", speedup))x faster")
        
        return LookupComparisonResult(
            itemCount: array.count,
            linearSearchTime: linearTime,
            dictionaryLookupTime: dictionaryTime,
            speedup: speedup
        )
    }
}

// MARK: - Result Types

/// Result of sorting algorithm comparison
struct SortingComparisonResult {
    let itemCount: Int
    let bubbleSortTime: Double
    let timsortTime: Double
    let speedup: Double
    
    var summary: String {
        """
        Sorting Comparison (\(itemCount) items):
        - Bubble Sort O(n²): \(String(format: "%.6f", bubbleSortTime))s
        - Timsort O(n log n): \(String(format: "%.6f", timsortTime))s
        - Improvement: \(String(format: "%.1f", speedup))x faster
        """
    }
}

/// Result of lookup algorithm comparison
struct LookupComparisonResult {
    let itemCount: Int
    let linearSearchTime: Double
    let dictionaryLookupTime: Double
    let speedup: Double
    
    var summary: String {
        """
        Lookup Comparison (\(itemCount) items):
        - Linear Search O(n): \(String(format: "%.6f", linearSearchTime))s
        - Dictionary O(1): \(String(format: "%.6f", dictionaryLookupTime))s
        - Improvement: \(String(format: "%.1f", speedup))x faster
        """
    }
}

// MARK: - Complexity Documentation

/// Documentation of algorithm complexities used in this app
///
/// | Operation          | Before          | After           | Improvement      |
/// |--------------------|-----------------|-----------------|------------------|
/// | Sort               | O(n²) bubble    | O(n log n) tim  | ~100x faster     |
/// | Lookup by ID       | O(n) linear     | O(1) dictionary | Constant time    |
/// | Find by Name       | O(n) linear     | O(log n) binary | Much faster      |
/// | Search             | O(n) × keystrokes| O(n) × 1       | ~80% reduction   |
/// | Delete             | O(n) rebuild    | O(1) + O(n)     | Cleaner          |
/// | Low Stock Check    | N/A             | O(n) filter     | New feature      |
///
/// Space Complexity:
/// - Array storage: O(n)
/// - Dictionary index: O(n) additional
/// - Total: O(2n) = O(n)
enum ComplexityDocumentation {
    // This enum serves as documentation only
}
