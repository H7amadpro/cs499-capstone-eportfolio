//
//  ValidationError.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//
//  Custom error types for validation and data operations
//  Provides user-friendly, localized error messages
//  Demonstrates proper error handling patterns in Swift
//

import Foundation

/// Errors that can occur during item form validation
enum ValidationError: LocalizedError {
    case emptyName
    case nameTooLong(maxLength: Int)
    case invalidQuantity
    case negativeQuantity
    case invalidPrice
    case negativePrice
    case emptyCategory
    
    /// User-friendly error description for display in UI
    var errorDescription: String? {
        switch self {
        case .emptyName:
            return "Item name cannot be empty"
        case .nameTooLong(let maxLength):
            return "Item name cannot exceed \(maxLength) characters"
        case .invalidQuantity:
            return "Please enter a valid quantity"
        case .negativeQuantity:
            return "Quantity cannot be negative"
        case .invalidPrice:
            return "Please enter a valid price"
        case .negativePrice:
            return "Price cannot be negative"
        case .emptyCategory:
            return "Please select a category"
        }
    }
}

/// Errors that can occur during data persistence operations
enum DataError: LocalizedError {
    case loadFailed
    case saveFailed
    case itemNotFound
    case encodingFailed
    case decodingFailed
    
    /// User-friendly error description for display in UI
    var errorDescription: String? {
        switch self {
        case .loadFailed:
            return "Failed to load inventory data"
        case .saveFailed:
            return "Failed to save inventory data"
        case .itemNotFound:
            return "Item not found"
        case .encodingFailed:
            return "Failed to encode data"
        case .decodingFailed:
            return "Failed to decode data"
        }
    }
}
