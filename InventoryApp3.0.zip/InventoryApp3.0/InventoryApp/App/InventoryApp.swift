//
//  InventoryApp.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//
//  SwiftUI App entry point - replaces UIKit AppDelegate with modern SwiftUI lifecycle
//

import SwiftUI

@main
struct InventoryApp: App {
    var body: some Scene {
        WindowGroup {
            InventoryView()
        }
    }
}
