//
//  SecurityUtilitiesTests.swift
//  InventoryAppTests
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//
//  MILESTONE FOUR: Database Enhancement
//
//  Unit tests for SecurityUtilities to ensure input sanitization
//  and security checks work correctly.
//

import XCTest
@testable import InventoryApp

final class SecurityUtilitiesTests: XCTestCase {
    
    // MARK: - Sanitization Tests
    
    func testSanitizeTrimsWhitespace() {
        // Given input with leading/trailing whitespace
        let input = "  Test Item  "
        
        // When sanitizing
        let result = SecurityUtilities.sanitize(input)
        
        // Then whitespace should be trimmed
        XCTAssertEqual(result, "Test Item")
    }
    
    func testSanitizeRemovesHTMLTags() {
        // Given input with HTML tags
        let input = "<script>alert('xss')</script>Test"
        
        // When sanitizing
        let result = SecurityUtilities.sanitize(input)
        
        // Then HTML tags should be removed
        XCTAssertFalse(result.contains("<script>"))
        XCTAssertFalse(result.contains("</script>"))
    }
    
    func testSanitizeNormalizesWhitespace() {
        // Given input with multiple spaces
        let input = "Test    Multiple   Spaces"
        
        // When sanitizing
        let result = SecurityUtilities.sanitize(input)
        
        // Then multiple spaces should be collapsed
        XCTAssertEqual(result, "Test Multiple Spaces")
    }
    
    func testSanitizeLimitsLength() {
        // Given very long input
        let input = String(repeating: "a", count: 2000)
        
        // When sanitizing
        let result = SecurityUtilities.sanitize(input)
        
        // Then length should be limited to 1000
        XCTAssertLessThanOrEqual(result.count, 1000)
    }
    
    // MARK: - HTML Stripping Tests
    
    func testStripHTMLTags() {
        // Given HTML content
        let input = "<p>Hello <b>World</b></p>"
        
        // When stripping tags
        let result = SecurityUtilities.stripHTMLTags(input)
        
        // Then tags should be removed
        XCTAssertEqual(result, "Hello World")
    }
    
    func testStripHTMLTagsPreservesText() {
        // Given plain text
        let input = "No HTML here"
        
        // When stripping tags
        let result = SecurityUtilities.stripHTMLTags(input)
        
        // Then text should be preserved
        XCTAssertEqual(result, "No HTML here")
    }
    
    // MARK: - Suspicious Content Detection Tests
    
    func testDetectsScriptTags() {
        // Given input with script tags
        let input = "<script>malicious code</script>"
        
        // When checking for suspicious content
        let isSuspicious = SecurityUtilities.containsSuspiciousContent(input)
        
        // Then it should be detected as suspicious
        XCTAssertTrue(isSuspicious, "Script tags should be detected")
    }
    
    func testDetectsSQLInjection() {
        // Given input with SQL injection attempt
        let input = "'; DROP TABLE items; --"
        
        // When checking for suspicious content
        let isSuspicious = SecurityUtilities.containsSuspiciousContent(input)
        
        // Then it should be detected as suspicious
        XCTAssertTrue(isSuspicious, "SQL injection should be detected")
    }
    
    func testDetectsJavaScriptProtocol() {
        // Given input with JavaScript protocol
        let input = "javascript:alert('xss')"
        
        // When checking for suspicious content
        let isSuspicious = SecurityUtilities.containsSuspiciousContent(input)
        
        // Then it should be detected as suspicious
        XCTAssertTrue(isSuspicious, "JavaScript protocol should be detected")
    }
    
    func testNormalInputNotSuspicious() {
        // Given normal input
        let input = "MacBook Pro 16-inch"
        
        // When checking for suspicious content
        let isSuspicious = SecurityUtilities.containsSuspiciousContent(input)
        
        // Then it should not be flagged
        XCTAssertFalse(isSuspicious, "Normal input should not be suspicious")
    }
    
    // MARK: - Input Safety Tests
    
    func testIsInputSafeWithNormalInput() {
        // Given normal input
        let input = "Normal item name"
        
        // When checking safety
        let isSafe = SecurityUtilities.isInputSafe(input)
        
        // Then it should be safe
        XCTAssertTrue(isSafe)
    }
    
    func testIsInputSafeWithSuspiciousInput() {
        // Given suspicious input
        let input = "<script>alert('xss')</script>"
        
        // When checking safety
        let isSafe = SecurityUtilities.isInputSafe(input)
        
        // Then it should not be safe
        XCTAssertFalse(isSafe)
    }
    
    func testIsInputSafeWithNullBytes() {
        // Given input with null bytes
        let input = "Test\0Item"
        
        // When checking safety
        let isSafe = SecurityUtilities.isInputSafe(input)
        
        // Then it should not be safe
        XCTAssertFalse(isSafe)
    }
    
    // MARK: - Checksum Tests
    
    func testGenerateChecksum() {
        // Given some data
        let data = "Test data for checksum"
        
        // When generating checksum
        let checksum = SecurityUtilities.generateChecksum(data)
        
        // Then checksum should be consistent
        let checksum2 = SecurityUtilities.generateChecksum(data)
        XCTAssertEqual(checksum, checksum2, "Checksum should be deterministic")
    }
    
    func testVerifyChecksum() {
        // Given data and its checksum
        let data = "Test data"
        let checksum = SecurityUtilities.generateChecksum(data)
        
        // When verifying
        let isValid = SecurityUtilities.verifyChecksum(data, checksum: checksum)
        
        // Then verification should pass
        XCTAssertTrue(isValid)
    }
    
    func testVerifyChecksumFailsForTamperedData() {
        // Given data and its checksum
        let data = "Original data"
        let checksum = SecurityUtilities.generateChecksum(data)
        
        // When verifying with tampered data
        let tamperedData = "Tampered data"
        let isValid = SecurityUtilities.verifyChecksum(tamperedData, checksum: checksum)
        
        // Then verification should fail
        XCTAssertFalse(isValid)
    }
    
    // MARK: - String Extension Tests
    
    func testStringSanitizedExtension() {
        // Given a string
        let input = "  Test  "
        
        // When using sanitized property
        let result = input.sanitized
        
        // Then it should be sanitized
        XCTAssertEqual(result, "Test")
    }
    
    func testStringIsSafeExtension() {
        // Given a safe string
        let safeInput = "Normal text"
        
        // When checking isSafe
        XCTAssertTrue(safeInput.isSafe)
        
        // Given an unsafe string
        let unsafeInput = "<script>bad</script>"
        
        // When checking isSafe
        XCTAssertFalse(unsafeInput.isSafe)
    }
}
