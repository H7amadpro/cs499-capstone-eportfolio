//
//  ValidationServiceTests.swift
//  InventoryAppTests
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//
//  MILESTONE FOUR: Database Enhancement
//
//  Unit tests for ValidationService to ensure data integrity
//  and security validation works correctly.
//

import XCTest
@testable import InventoryApp

final class ValidationServiceTests: XCTestCase {
    
    // MARK: - Name Validation Tests
    
    func testValidName() {
        // Given a valid name
        let name = "MacBook Pro"
        
        // When validating
        let error = ValidationService.validateName(name)
        
        // Then no error should be returned
        XCTAssertNil(error, "Valid name should not produce an error")
    }
    
    func testEmptyName() {
        // Given an empty name
        let name = ""
        
        // When validating
        let error = ValidationService.validateName(name)
        
        // Then emptyName error should be returned
        XCTAssertEqual(error, .emptyName, "Empty name should produce emptyName error")
    }
    
    func testWhitespaceOnlyName() {
        // Given a whitespace-only name
        let name = "   "
        
        // When validating
        let error = ValidationService.validateName(name)
        
        // Then emptyName error should be returned
        XCTAssertEqual(error, .emptyName, "Whitespace-only name should produce emptyName error")
    }
    
    func testNameTooLong() {
        // Given a name exceeding max length
        let name = String(repeating: "a", count: 101)
        
        // When validating
        let error = ValidationService.validateName(name)
        
        // Then nameTooLong error should be returned
        if case .nameTooLong(let maxLength) = error {
            XCTAssertEqual(maxLength, 100, "Max length should be 100")
        } else {
            XCTFail("Expected nameTooLong error")
        }
    }
    
    func testNameWithSpecialCharacters() {
        // Given a name with allowed special characters
        let name = "Item's Name - (Test)"
        
        // When validating
        let error = ValidationService.validateName(name)
        
        // Then no error should be returned
        XCTAssertNil(error, "Name with allowed special characters should be valid")
    }
    
    // MARK: - Quantity Validation Tests
    
    func testValidQuantity() {
        // Given a valid quantity
        let quantity = 100
        
        // When validating
        let error = ValidationService.validateQuantity(quantity)
        
        // Then no error should be returned
        XCTAssertNil(error, "Valid quantity should not produce an error")
    }
    
    func testZeroQuantity() {
        // Given zero quantity
        let quantity = 0
        
        // When validating
        let error = ValidationService.validateQuantity(quantity)
        
        // Then no error should be returned (zero is valid)
        XCTAssertNil(error, "Zero quantity should be valid")
    }
    
    func testNegativeQuantity() {
        // Given a negative quantity
        let quantity = -1
        
        // When validating
        let error = ValidationService.validateQuantity(quantity)
        
        // Then negativeQuantity error should be returned
        XCTAssertEqual(error, .negativeQuantity, "Negative quantity should produce error")
    }
    
    func testQuantityTooLarge() {
        // Given a quantity exceeding max
        let quantity = 1_000_000
        
        // When validating
        let error = ValidationService.validateQuantity(quantity)
        
        // Then quantityTooLarge error should be returned
        if case .quantityTooLarge(let maxQuantity) = error {
            XCTAssertEqual(maxQuantity, 999_999, "Max quantity should be 999,999")
        } else {
            XCTFail("Expected quantityTooLarge error")
        }
    }
    
    // MARK: - Price Validation Tests
    
    func testValidPrice() {
        // Given a valid price
        let price = 99.99
        
        // When validating
        let error = ValidationService.validatePrice(price)
        
        // Then no error should be returned
        XCTAssertNil(error, "Valid price should not produce an error")
    }
    
    func testZeroPrice() {
        // Given zero price
        let price = 0.0
        
        // When validating
        let error = ValidationService.validatePrice(price)
        
        // Then no error should be returned (zero is valid for free items)
        XCTAssertNil(error, "Zero price should be valid")
    }
    
    func testNegativePrice() {
        // Given a negative price
        let price = -10.0
        
        // When validating
        let error = ValidationService.validatePrice(price)
        
        // Then negativePrice error should be returned
        XCTAssertEqual(error, .negativePrice, "Negative price should produce error")
    }
    
    func testPriceTooLarge() {
        // Given a price exceeding max
        let price = 1_000_000.0
        
        // When validating
        let error = ValidationService.validatePrice(price)
        
        // Then priceTooLarge error should be returned
        if case .priceTooLarge(let maxPrice) = error {
            XCTAssertEqual(maxPrice, 999_999.99, "Max price should be 999,999.99")
        } else {
            XCTFail("Expected priceTooLarge error")
        }
    }
    
    // MARK: - Full Item Validation Tests
    
    func testValidItem() {
        // Given valid item data
        let name = "Test Item"
        let quantity = 10
        let price = 29.99
        
        // When validating
        XCTAssertNoThrow(
            try ValidationService.validateItem(
                name: name,
                quantity: quantity,
                price: price,
                category: nil
            ),
            "Valid item should not throw"
        )
    }
    
    func testInvalidItemThrows() {
        // Given invalid item data
        let name = ""
        let quantity = -1
        let price = -10.0
        
        // When validating
        XCTAssertThrowsError(
            try ValidationService.validateItem(
                name: name,
                quantity: quantity,
                price: price,
                category: nil
            ),
            "Invalid item should throw"
        )
    }
}

// MARK: - ValidationError Equatable

extension ValidationError: Equatable {
    public static func == (lhs: ValidationError, rhs: ValidationError) -> Bool {
        switch (lhs, rhs) {
        case (.emptyName, .emptyName):
            return true
        case (.negativeQuantity, .negativeQuantity):
            return true
        case (.negativePrice, .negativePrice):
            return true
        case (.nameTooLong(let l), .nameTooLong(let r)):
            return l == r
        case (.nameTooShort(let l), .nameTooShort(let r)):
            return l == r
        case (.quantityTooLarge(let l), .quantityTooLarge(let r)):
            return l == r
        case (.priceTooLarge(let l), .priceTooLarge(let r)):
            return l == r
        default:
            return false
        }
    }
}
