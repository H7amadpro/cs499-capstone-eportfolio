# Inventory Management App - Milestone Four

**Student:** Hamad Alghaithi  
**Course:** CS 499 - Computer Science Capstone  
**Institution:** Southern New Hampshire University  
**Version:** 4.0 (Database Enhancement)

---

## Overview

This milestone focuses on **Database Enhancement**, migrating from UserDefaults to SwiftData with proper entity relationships, comprehensive validation, security features, and migration support.

## Key Enhancements

### 1. SwiftData Implementation

**Before (UserDefaults):**
- Simple key-value storage
- No relationships between data
- Manual JSON encoding/decoding
- No query optimization
- All data loaded into memory

**After (SwiftData):**
- Relational database with SQLite backend
- Entity relationships (Item ↔ CategoryEntity)
- Type-safe queries with `@Query` and `FetchDescriptor`
- Efficient partial loading
- Automatic change tracking

### 2. Entity Relationships

```swift
// Item.swift - Many-to-One relationship
@Model
final class Item {
    @Relationship var category: CategoryEntity?
}

// CategoryEntity.swift - One-to-Many relationship
@Model
final class CategoryEntity {
    @Relationship(deleteRule: .nullify, inverse: \Item.category)
    var items: [Item]?
}
```

**Relationship Features:**
- Foreign key constraints ensure referential integrity
- Delete rule `.nullify` prevents orphaned items
- Inverse relationship enables bidirectional navigation

### 3. Comprehensive Validation

```swift
// ValidationService.swift
try ValidationService.validateItem(
    name: name,
    quantity: quantity,
    price: price,
    category: category
)
```

**Validation Rules:**
| Field | Validation |
|-------|------------|
| Name | 1-100 chars, allowed characters only, no suspicious content |
| Quantity | 0 to 999,999 (non-negative integer) |
| Price | 0 to 999,999.99 (max 2 decimal places) |

### 4. Security Features

```swift
// SecurityUtilities.swift
let safeName = SecurityUtilities.sanitize(userInput)
let isSuspicious = SecurityUtilities.containsSuspiciousContent(input)
```

**Security Measures:**
- Input sanitization (HTML stripping, whitespace normalization)
- Injection attack detection (SQL, XSS, JavaScript)
- Audit trail logging
- Data integrity checksums

### 5. Data Migration

```swift
// MigrationService.swift
let migratedCount = try await migrationService.migrateFromUserDefaults()
```

**Migration Features:**
- Automatic migration on first launch after update
- Transactional (all or nothing)
- Preserves original creation dates
- Maps legacy categories to new CategoryEntity

---

## Project Structure

```
InventoryApp/
├── App/
│   └── InventoryApp.swift          # App entry with ModelContainer
├── Models/
│   ├── Item.swift                  # @Model with relationships
│   ├── CategoryEntity.swift        # @Model for categories
│   └── Category.swift              # Enum helper
├── ViewModels/
│   ├── InventoryViewModel.swift    # List state management
│   └── AddItemViewModel.swift      # Form validation
├── Views/
│   ├── InventoryView.swift         # Main list with @Query
│   ├── AddItemView.swift           # Add/Edit form
│   └── ItemRowView.swift           # Reusable row
├── Repositories/
│   ├── ItemRepositoryProtocol.swift
│   └── SwiftDataItemRepository.swift
├── Services/
│   ├── ValidationService.swift     # Input validation
│   ├── SecurityUtilities.swift     # Security helpers
│   └── MigrationService.swift      # Data migration
└── Utilities/
    └── Constants.swift

InventoryAppTests/
├── ValidationServiceTests.swift
└── SecurityUtilitiesTests.swift
```

---

## Requirements

- **Xcode:** 15.0+
- **iOS:** 17.0+
- **Swift:** 5.9+

---

## How to Run

1. Open `InventoryApp.xcodeproj` in Xcode
2. Select an iPhone simulator (iOS 17+)
3. Press `⌘R` to build and run
4. Press `⌘U` to run unit tests

---

## Course Outcomes Demonstrated

### Outcome 4: Innovative Techniques
- SwiftData for modern persistence
- `@Query` for reactive data fetching
- Entity relationships with proper delete rules

### Outcome 5: Security Mindset
- Input validation before storage
- Sanitization to prevent injection attacks
- Audit trail for security events
- Defense in depth approach

---

## Testing

### Unit Tests
- `ValidationServiceTests.swift` - 15+ tests for validation logic
- `SecurityUtilitiesTests.swift` - 15+ tests for security utilities

### Manual Testing
1. Add items with various inputs (test validation)
2. Try special characters in names (test sanitization)
3. Delete categories (verify items retain but category becomes nil)
4. Reinstall app (verify migration from UserDefaults)

---

## Database Schema

### Items Table
| Column | Type | Constraints |
|--------|------|-------------|
| id | UUID | PRIMARY KEY, UNIQUE |
| name | String | NOT NULL |
| quantity | Int | NOT NULL |
| price | Double | NOT NULL |
| createdAt | Date | NOT NULL |
| updatedAt | Date | NOT NULL |
| category | UUID? | FOREIGN KEY → CategoryEntity |

### Categories Table
| Column | Type | Constraints |
|--------|------|-------------|
| id | UUID | PRIMARY KEY, UNIQUE |
| name | String | NOT NULL |
| iconName | String | NOT NULL |
| colorHex | String | NOT NULL |
| createdAt | Date | NOT NULL |

---

## Author

**Hamad Alghaithi**  
CS 499 - Computer Science Capstone  
Southern New Hampshire University
