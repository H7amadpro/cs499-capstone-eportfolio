//
//  AddItemViewModel.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//
//  MILESTONE FOUR: Database Enhancement
//
//  This ViewModel handles adding and editing inventory items:
//  - Comprehensive validation before saving
//  - Input sanitization for security
//  - SwiftData integration for persistence
//  - User-friendly error messages
//

import Foundation
import SwiftData

/// ViewModel for the Add/Edit Item screen
///
/// Responsibilities:
/// - Manages form state for item creation/editing
/// - Validates all input before saving
/// - Sanitizes input for security
/// - Coordinates with repository for persistence
///
/// SECURITY: All input is validated and sanitized before
/// being saved to the database
@Observable
final class AddItemViewModel {
    
    // MARK: - Form State
    
    /// Item name input
    var name: String = ""
    
    /// Quantity input as string (for text field binding)
    var quantityString: String = ""
    
    /// Price input as string (for text field binding)
    var priceString: String = ""
    
    /// Selected category
    var selectedCategory: CategoryEntity?
    
    // MARK: - UI State
    
    /// Available categories for picker
    var categories: [CategoryEntity] = []
    
    /// Validation error message to display
    var validationError: String?
    
    /// Whether to show validation error alert
    var showValidationError: Bool = false
    
    /// Whether save was successful (triggers dismiss)
    var didSaveSuccessfully: Bool = false
    
    /// Whether currently saving
    var isSaving: Bool = false
    
    // MARK: - Edit Mode
    
    /// Item being edited (nil for new item)
    var editingItem: Item?
    
    /// Whether in edit mode
    var isEditing: Bool {
        editingItem != nil
    }
    
    /// Title for the screen
    var screenTitle: String {
        isEditing ? "Edit Item" : "Add Item"
    }
    
    /// Title for the save button
    var saveButtonTitle: String {
        isEditing ? "Update" : "Add Item"
    }
    
    // MARK: - Private Properties
    
    /// Repository for data access
    private var repository: SwiftDataItemRepository?
    
    /// Category repository
    private var categoryRepository: SwiftDataCategoryRepository?
    
    // MARK: - Computed Properties
    
    /// Parsed quantity value
    var quantity: Int {
        Int(quantityString) ?? 0
    }
    
    /// Parsed price value
    var price: Double {
        Double(priceString.replacingOccurrences(of: "$", with: "")) ?? 0.0
    }
    
    /// Whether form has valid input (basic check for button state)
    var isFormValid: Bool {
        !name.trimmingCharacters(in: .whitespaces).isEmpty &&
        quantity >= 0 &&
        price >= 0
    }
    
    // MARK: - Initialization
    
    init() {}
    
    /// Initializes for editing an existing item
    /// - Parameter item: Item to edit
    init(editing item: Item) {
        self.editingItem = item
        self.name = item.name
        self.quantityString = String(item.quantity)
        self.priceString = String(format: "%.2f", item.price)
        self.selectedCategory = item.category
    }
    
    // MARK: - Setup
    
    /// Configures the ViewModel with a model context
    /// - Parameter modelContext: SwiftData ModelContext
    func configure(with modelContext: ModelContext) {
        self.repository = SwiftDataItemRepository(modelContext: modelContext)
        self.categoryRepository = SwiftDataCategoryRepository(modelContext: modelContext)
        loadCategories()
    }
    
    /// Loads available categories
    func loadCategories() {
        guard let categoryRepository = categoryRepository else { return }
        categories = categoryRepository.fetchAll()
        
        // Select first category by default if none selected
        if selectedCategory == nil && !categories.isEmpty {
            selectedCategory = categories.first
        }
    }
    
    // MARK: - Save Operation
    
    /// Validates and saves the item
    ///
    /// This method:
    /// 1. Validates all input using ValidationService
    /// 2. Sanitizes input using SecurityUtilities
    /// 3. Creates or updates the item
    /// 4. Saves to SwiftData via repository
    ///
    /// SECURITY: All input is validated and sanitized before storage
    func save() {
        isSaving = true
        validationError = nil
        
        // Step 1: Validate all input
        do {
            try ValidationService.validateItem(
                name: name,
                quantity: quantity,
                price: price,
                category: selectedCategory
            )
        } catch let error as ValidationError {
            showValidationError(error.errorDescription ?? "Validation failed")
            isSaving = false
            return
        } catch {
            showValidationError("An unexpected error occurred")
            isSaving = false
            return
        }
        
        // Step 2: Create or update item
        guard let repository = repository else {
            showValidationError("Unable to save. Please try again.")
            isSaving = false
            return
        }
        
        do {
            if let existingItem = editingItem {
                // Update existing item
                existingItem.update(
                    name: name,
                    quantity: quantity,
                    price: price,
                    category: selectedCategory
                )
                try repository.update(existingItem)
            } else {
                // Create new item
                let newItem = Item(
                    name: name,
                    quantity: quantity,
                    price: price,
                    category: selectedCategory
                )
                try repository.add(newItem)
            }
            
            // Success
            didSaveSuccessfully = true
            
        } catch {
            // SECURITY: Don't expose internal error details
            showValidationError("Failed to save item. Please try again.")
        }
        
        isSaving = false
    }
    
    // MARK: - Helper Methods
    
    /// Shows a validation error to the user
    private func showValidationError(_ message: String) {
        validationError = message
        showValidationError = true
    }
    
    /// Clears the validation error
    func clearValidationError() {
        validationError = nil
        showValidationError = false
    }
    
    /// Resets the form to initial state
    func resetForm() {
        name = ""
        quantityString = ""
        priceString = ""
        selectedCategory = categories.first
        editingItem = nil
        validationError = nil
        didSaveSuccessfully = false
    }
    
    /// Populates form with item data for editing
    /// - Parameter item: Item to edit
    func populateForEditing(_ item: Item) {
        editingItem = item
        name = item.name
        quantityString = String(item.quantity)
        priceString = String(format: "%.2f", item.price)
        selectedCategory = item.category
    }
}
