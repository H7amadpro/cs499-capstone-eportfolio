//
//  InventoryViewModel.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//
//  MILESTONE FOUR: Database Enhancement
//
//  This ViewModel has been updated to work with SwiftData:
//  - Uses SwiftDataItemRepository for data access
//  - Maintains MVVM architecture from Milestone Two
//  - Keeps algorithm optimizations from Milestone Three
//  - Adds validation before all database operations
//

import Foundation
import SwiftData
import Combine

/// ViewModel for the main inventory list screen
///
/// Responsibilities:
/// - Manages inventory item state
/// - Handles search with debouncing (Milestone Three optimization)
/// - Coordinates with repository for data operations
/// - Provides computed properties for UI
///
/// Architecture: MVVM with Repository Pattern
/// - View observes this ViewModel via @Observable
/// - ViewModel uses Repository for data access
/// - Repository abstracts SwiftData operations
@Observable
final class InventoryViewModel {
    
    // MARK: - Published Properties
    
    /// All items currently displayed (filtered by search if active)
    var items: [Item] = []
    
    /// Current search query entered by user
    var searchQuery: String = "" {
        didSet {
            // Debounced search from Milestone Three
            searchSubject.send(searchQuery)
        }
    }
    
    /// Currently selected category filter (nil = all categories)
    var selectedCategory: CategoryEntity?
    
    /// All available categories for filtering
    var categories: [CategoryEntity] = []
    
    /// Loading state for UI feedback
    var isLoading: Bool = false
    
    /// Error message to display to user
    var errorMessage: String?
    
    /// Whether to show error alert
    var showError: Bool = false
    
    // MARK: - Private Properties
    
    /// Repository for data access
    private var repository: SwiftDataItemRepository?
    
    /// Category repository
    private var categoryRepository: SwiftDataCategoryRepository?
    
    /// Combine subject for debounced search
    private let searchSubject = PassthroughSubject<String, Never>()
    
    /// Combine cancellables storage
    private var cancellables = Set<AnyCancellable>()
    
    // MARK: - Computed Properties
    
    /// Total count of items
    var itemCount: Int {
        items.count
    }
    
    /// Total inventory value
    var totalValue: Double {
        items.reduce(0) { $0 + $1.totalValue }
    }
    
    /// Formatted total value for display
    var formattedTotalValue: String {
        String(format: "$%.2f", totalValue)
    }
    
    /// Items with low stock (quantity ≤ 5)
    var lowStockItems: [Item] {
        items.filter { $0.isLowStock }
    }
    
    /// Count of low stock items
    var lowStockCount: Int {
        lowStockItems.count
    }
    
    /// Whether there are any low stock items
    var hasLowStockItems: Bool {
        lowStockCount > 0
    }
    
    // MARK: - Initialization
    
    init() {
        setupSearchDebouncing()
    }
    
    // MARK: - Setup Methods
    
    /// Configures the ViewModel with a model context
    /// Called from the View when context is available
    ///
    /// - Parameter modelContext: SwiftData ModelContext
    func configure(with modelContext: ModelContext) {
        self.repository = SwiftDataItemRepository(modelContext: modelContext)
        self.categoryRepository = SwiftDataCategoryRepository(modelContext: modelContext)
        loadData()
    }
    
    /// Sets up debounced search using Combine
    /// Waits 300ms after user stops typing before searching
    /// This optimization reduces unnecessary database queries
    private func setupSearchDebouncing() {
        searchSubject
            .debounce(for: .milliseconds(300), scheduler: DispatchQueue.main)
            .removeDuplicates()
            .sink { [weak self] query in
                self?.performSearch(query: query)
            }
            .store(in: &cancellables)
    }
    
    // MARK: - Data Loading
    
    /// Loads all data from the repository
    func loadData() {
        loadCategories()
        loadItems()
    }
    
    /// Loads items from repository
    func loadItems() {
        guard let repository = repository else { return }
        
        isLoading = true
        
        if let category = selectedCategory {
            items = repository.fetchByCategory(category)
        } else if !searchQuery.isEmpty {
            items = repository.searchItems(query: searchQuery)
        } else {
            items = repository.fetchAll()
        }
        
        isLoading = false
    }
    
    /// Loads categories from repository
    func loadCategories() {
        guard let categoryRepository = categoryRepository else { return }
        categories = categoryRepository.fetchAll()
    }
    
    /// Performs search with the given query
    private func performSearch(query: String) {
        guard let repository = repository else { return }
        
        if query.isEmpty {
            items = repository.fetchAll()
        } else {
            items = repository.searchItems(query: query)
        }
    }
    
    // MARK: - CRUD Operations
    
    /// Deletes an item
    ///
    /// - Parameter item: Item to delete
    func deleteItem(_ item: Item) {
        guard let repository = repository else { return }
        
        do {
            try repository.delete(item)
            loadItems()  // Refresh the list
        } catch {
            showError(message: "Failed to delete item")
        }
    }
    
    /// Deletes items at the specified index set
    /// Used for SwiftUI List onDelete
    ///
    /// - Parameter indexSet: Indices of items to delete
    func deleteItems(at indexSet: IndexSet) {
        guard let repository = repository else { return }
        
        let itemsToDelete = indexSet.map { items[$0] }
        
        do {
            try repository.deleteMultiple(itemsToDelete)
            loadItems()
        } catch {
            showError(message: "Failed to delete items")
        }
    }
    
    // MARK: - Filtering
    
    /// Filters items by category
    ///
    /// - Parameter category: Category to filter by, or nil for all
    func filterByCategory(_ category: CategoryEntity?) {
        selectedCategory = category
        loadItems()
    }
    
    /// Clears all filters and search
    func clearFilters() {
        searchQuery = ""
        selectedCategory = nil
        loadItems()
    }
    
    // MARK: - Analytics
    
    /// Gets breakdown of items by category
    /// - Returns: Dictionary of category name to item count
    func getCategoryBreakdown() -> [String: Int] {
        var breakdown: [String: Int] = [:]
        for item in items {
            let categoryName = item.categoryName
            breakdown[categoryName, default: 0] += 1
        }
        return breakdown
    }
    
    // MARK: - Error Handling
    
    /// Shows an error message to the user
    /// SECURITY: Uses generic messages that don't expose internal details
    private func showError(message: String) {
        errorMessage = message
        showError = true
    }
    
    /// Clears the current error
    func clearError() {
        errorMessage = nil
        showError = false
    }
}
