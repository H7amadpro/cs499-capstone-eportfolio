//
//  SwiftDataItemRepository.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//
//  MILESTONE FOUR: Database Enhancement
//
//  This file demonstrates:
//  - SwiftData implementation of repository pattern
//  - Type-safe queries with FetchDescriptor
//  - Proper ModelContext usage for CRUD operations
//  - Error handling that doesn't expose internal details
//
//  Why SwiftData over UserDefaults:
//  - Relational data with proper foreign keys
//  - Efficient queries with predicates
//  - Automatic change tracking
//  - Built-in migration support
//  - Better performance for large datasets
//

import Foundation
import SwiftData

/// SwiftData implementation of ItemRepositoryProtocol
///
/// This repository provides a clean abstraction over SwiftData,
/// allowing the rest of the app to work with items without
/// knowing the underlying storage mechanism.
///
/// SECURITY: All operations use SwiftData's parameterized queries,
/// which prevent SQL injection attacks by design.
final class SwiftDataItemRepository: ItemRepositoryProtocol {
    
    // MARK: - Properties
    
    /// SwiftData model context for database operations
    private let modelContext: ModelContext
    
    // MARK: - Initialization
    
    /// Creates a repository with the given model context
    /// - Parameter modelContext: SwiftData ModelContext for database access
    init(modelContext: ModelContext) {
        self.modelContext = modelContext
    }
    
    // MARK: - Fetch Operations
    
    /// Fetches all items sorted alphabetically by name
    ///
    /// Uses SwiftData's FetchDescriptor for efficient querying.
    /// The sort is performed at the database level for better performance.
    ///
    /// Time Complexity: O(n log n) for sorting
    /// - Returns: Array of all items
    func fetchAll() -> [Item] {
        let descriptor = FetchDescriptor<Item>(
            sortBy: [SortDescriptor(\.name, comparator: .localizedStandard)]
        )
        
        do {
            return try modelContext.fetch(descriptor)
        } catch {
            // SECURITY: Log error but don't expose details
            SecurityUtilities.logSecurityEvent(
                type: .dataModification,
                details: "Failed to fetch items"
            )
            return []
        }
    }
    
    /// Fetches a single item by UUID
    ///
    /// Uses SwiftData predicate for O(1) lookup by primary key.
    ///
    /// - Parameter id: UUID of the item
    /// - Returns: Item if found, nil otherwise
    func fetch(byId id: UUID) -> Item? {
        let descriptor = FetchDescriptor<Item>(
            predicate: #Predicate { $0.id == id }
        )
        
        do {
            let results = try modelContext.fetch(descriptor)
            return results.first
        } catch {
            return nil
        }
    }
    
    /// Fetches items belonging to a specific category
    ///
    /// - Parameter category: CategoryEntity to filter by
    /// - Returns: Array of items in the category
    func fetchByCategory(_ category: CategoryEntity) -> [Item] {
        let categoryId = category.id
        let descriptor = FetchDescriptor<Item>(
            predicate: #Predicate { $0.category?.id == categoryId },
            sortBy: [SortDescriptor(\.name, comparator: .localizedStandard)]
        )
        
        do {
            return try modelContext.fetch(descriptor)
        } catch {
            return []
        }
    }
    
    /// Fetches items with quantity at or below threshold
    ///
    /// - Parameter threshold: Maximum quantity for "low stock"
    /// - Returns: Low stock items sorted by quantity (lowest first)
    func fetchLowStock(threshold: Int = 5) -> [Item] {
        let descriptor = FetchDescriptor<Item>(
            predicate: #Predicate { $0.quantity <= threshold },
            sortBy: [SortDescriptor(\.quantity)]
        )
        
        do {
            return try modelContext.fetch(descriptor)
        } catch {
            return []
        }
    }
    
    // MARK: - Search Operations
    
    /// Searches items by name containing the query string
    ///
    /// Uses case-insensitive search for better user experience.
    /// The search is performed at the database level for efficiency.
    ///
    /// - Parameter query: Search query string
    /// - Returns: Matching items sorted by name
    func searchItems(query: String) -> [Item] {
        guard !query.isEmpty else {
            return fetchAll()
        }
        
        // Sanitize search query for security
        let sanitizedQuery = SecurityUtilities.sanitize(query)
        
        let descriptor = FetchDescriptor<Item>(
            predicate: #Predicate { item in
                item.name.localizedStandardContains(sanitizedQuery)
            },
            sortBy: [SortDescriptor(\.name, comparator: .localizedStandard)]
        )
        
        do {
            return try modelContext.fetch(descriptor)
        } catch {
            return []
        }
    }
    
    // MARK: - CRUD Operations
    
    /// Adds a new item to the database
    ///
    /// The item is inserted into the context and saved immediately.
    /// Validation should be performed before calling this method.
    ///
    /// - Parameter item: Item to add
    /// - Throws: Error if save fails
    func add(_ item: Item) throws {
        // Log the addition for audit trail
        SecurityUtilities.logSecurityEvent(
            type: .dataModification,
            details: "Adding item: \(item.name)"
        )
        
        modelContext.insert(item)
        try modelContext.save()
    }
    
    /// Updates an existing item
    ///
    /// SwiftData automatically tracks changes to @Model objects,
    /// so we just need to save the context.
    ///
    /// - Parameter item: Item with updated values
    /// - Throws: Error if save fails
    func update(_ item: Item) throws {
        // Update the audit timestamp
        item.updatedAt = Date()
        
        // Log the update for audit trail
        SecurityUtilities.logSecurityEvent(
            type: .dataModification,
            details: "Updating item: \(item.name)"
        )
        
        try modelContext.save()
    }
    
    /// Deletes an item from the database
    ///
    /// - Parameter item: Item to delete
    /// - Throws: Error if delete fails
    func delete(_ item: Item) throws {
        // Log the deletion for audit trail
        SecurityUtilities.logSecurityEvent(
            type: .dataModification,
            details: "Deleting item: \(item.name)"
        )
        
        modelContext.delete(item)
        try modelContext.save()
    }
    
    /// Deletes an item by its UUID
    ///
    /// - Parameter id: UUID of the item to delete
    /// - Throws: Error if item not found or delete fails
    func delete(byId id: UUID) throws {
        guard let item = fetch(byId: id) else {
            throw RepositoryError.itemNotFound
        }
        try delete(item)
    }
    
    /// Deletes multiple items in a batch
    ///
    /// More efficient than deleting one at a time as it
    /// only saves the context once at the end.
    ///
    /// - Parameter items: Array of items to delete
    /// - Throws: Error if any delete fails
    func deleteMultiple(_ items: [Item]) throws {
        for item in items {
            modelContext.delete(item)
        }
        try modelContext.save()
    }
    
    // MARK: - Analytics
    
    /// Total count of items in the database
    var itemCount: Int {
        let descriptor = FetchDescriptor<Item>()
        return (try? modelContext.fetchCount(descriptor)) ?? 0
    }
    
    /// Total value of all inventory (sum of quantity × price)
    var totalInventoryValue: Double {
        fetchAll().reduce(0) { $0 + $1.totalValue }
    }
}

// MARK: - Category Repository

/// SwiftData implementation of CategoryRepositoryProtocol
final class SwiftDataCategoryRepository: CategoryRepositoryProtocol {
    
    private let modelContext: ModelContext
    
    init(modelContext: ModelContext) {
        self.modelContext = modelContext
    }
    
    func fetchAll() -> [CategoryEntity] {
        let descriptor = FetchDescriptor<CategoryEntity>(
            sortBy: [SortDescriptor(\.name, comparator: .localizedStandard)]
        )
        
        do {
            return try modelContext.fetch(descriptor)
        } catch {
            return []
        }
    }
    
    func fetch(byName name: String) -> CategoryEntity? {
        let descriptor = FetchDescriptor<CategoryEntity>(
            predicate: #Predicate { $0.name == name }
        )
        
        do {
            return try modelContext.fetch(descriptor).first
        } catch {
            return nil
        }
    }
    
    func fetch(byId id: UUID) -> CategoryEntity? {
        let descriptor = FetchDescriptor<CategoryEntity>(
            predicate: #Predicate { $0.id == id }
        )
        
        do {
            return try modelContext.fetch(descriptor).first
        } catch {
            return nil
        }
    }
    
    func add(_ category: CategoryEntity) throws {
        modelContext.insert(category)
        try modelContext.save()
    }
    
    func delete(_ category: CategoryEntity) throws {
        modelContext.delete(category)
        try modelContext.save()
    }
}

// MARK: - Repository Errors

/// Errors that can occur during repository operations
enum RepositoryError: LocalizedError {
    case itemNotFound
    case saveFailed
    case deleteFailed
    case fetchFailed
    
    var errorDescription: String? {
        switch self {
        case .itemNotFound:
            return "Item not found"
        case .saveFailed:
            return "Failed to save changes"
        case .deleteFailed:
            return "Failed to delete item"
        case .fetchFailed:
            return "Failed to load items"
        }
    }
}
