//
//  ItemRepositoryProtocol.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//
//  MILESTONE FOUR: Database Enhancement
//
//  This protocol defines the contract for item data access.
//  Using a protocol allows for:
//  - Dependency injection in ViewModels
//  - Easy testing with mock implementations
//  - Future flexibility to swap storage backends
//
//  Design Pattern: Repository Pattern
//  The repository abstracts data access, providing a clean API
//  that hides the underlying storage mechanism (SwiftData).
//

import Foundation
import SwiftData

/// Protocol defining the contract for item data access operations
///
/// This protocol enables:
/// - Dependency injection for testability
/// - Abstraction of storage implementation
/// - Consistent API across different storage backends
///
/// Implementations:
/// - SwiftDataItemRepository: Production implementation using SwiftData
/// - MockItemRepository: Testing implementation with in-memory storage
protocol ItemRepositoryProtocol {
    
    // MARK: - Fetch Operations
    
    /// Fetches all items from storage
    /// - Returns: Array of all items, sorted by name
    func fetchAll() -> [Item]
    
    /// Fetches a single item by its unique identifier
    /// - Parameter id: UUID of the item to fetch
    /// - Returns: Item if found, nil otherwise
    func fetch(byId id: UUID) -> Item?
    
    /// Fetches items belonging to a specific category
    /// - Parameter category: CategoryEntity to filter by
    /// - Returns: Array of items in the category
    func fetchByCategory(_ category: CategoryEntity) -> [Item]
    
    /// Fetches items with low stock (quantity ≤ threshold)
    /// - Parameter threshold: Maximum quantity to consider "low stock"
    /// - Returns: Array of low stock items, sorted by quantity ascending
    func fetchLowStock(threshold: Int) -> [Item]
    
    // MARK: - Search Operations
    
    /// Searches items by name or category
    /// - Parameter query: Search query string
    /// - Returns: Array of matching items
    func searchItems(query: String) -> [Item]
    
    // MARK: - CRUD Operations
    
    /// Adds a new item to storage
    /// - Parameter item: Item to add
    /// - Throws: Error if save fails
    func add(_ item: Item) throws
    
    /// Updates an existing item in storage
    /// - Parameter item: Item with updated values
    /// - Throws: Error if save fails
    func update(_ item: Item) throws
    
    /// Deletes an item from storage
    /// - Parameter item: Item to delete
    /// - Throws: Error if delete fails
    func delete(_ item: Item) throws
    
    /// Deletes an item by its unique identifier
    /// - Parameter id: UUID of the item to delete
    /// - Throws: Error if item not found or delete fails
    func delete(byId id: UUID) throws
    
    // MARK: - Batch Operations
    
    /// Deletes multiple items at once
    /// - Parameter items: Array of items to delete
    /// - Throws: Error if any delete fails
    func deleteMultiple(_ items: [Item]) throws
    
    // MARK: - Analytics
    
    /// Returns the total count of items
    var itemCount: Int { get }
    
    /// Returns the total value of all inventory
    var totalInventoryValue: Double { get }
}

// MARK: - Category Repository Protocol

/// Protocol for category data access operations
protocol CategoryRepositoryProtocol {
    
    /// Fetches all categories
    /// - Returns: Array of all categories, sorted by name
    func fetchAll() -> [CategoryEntity]
    
    /// Fetches a category by name
    /// - Parameter name: Category name to search for
    /// - Returns: CategoryEntity if found, nil otherwise
    func fetch(byName name: String) -> CategoryEntity?
    
    /// Fetches a category by ID
    /// - Parameter id: UUID of the category
    /// - Returns: CategoryEntity if found, nil otherwise
    func fetch(byId id: UUID) -> CategoryEntity?
    
    /// Adds a new category
    /// - Parameter category: Category to add
    /// - Throws: Error if save fails
    func add(_ category: CategoryEntity) throws
    
    /// Deletes a category
    /// - Parameter category: Category to delete
    /// - Throws: Error if delete fails
    func delete(_ category: CategoryEntity) throws
}
