//
//  InventoryApp.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//
//  MILESTONE FOUR: Database Enhancement
//
//  Main application entry point with SwiftData configuration.
//  This file sets up the ModelContainer for persistent storage
//  and handles data migration from legacy UserDefaults storage.
//

import SwiftUI
import SwiftData

/// Main application structure
@main
struct InventoryApp: App {
    
    // MARK: - Properties
    
    /// The SwiftData model container for persistent storage
    let modelContainer: ModelContainer
    
    /// Service for migrating legacy data
    let migrationService: MigrationService
    
    // MARK: - Initialization
    
    init() {
        // Define the schema with all model types
        let schema = Schema([
            Item.self,
            CategoryEntity.self
        ])
        
        // Configure model container with schema
        // Using default configuration stores data in app's Documents directory
        let modelConfiguration = ModelConfiguration(
            schema: schema,
            isStoredInMemoryOnly: false  // Persist to disk
        )
        
        do {
            // Initialize the model container
            let container = try ModelContainer(
                for: schema,
                configurations: [modelConfiguration]
            )
            
            // Assign to properties
            self.modelContainer = container
            
            // Initialize migration service
            self.migrationService = MigrationService(modelContext: container.mainContext)
            
            // Seed default categories if database is empty (synchronous)
            InventoryApp.seedDefaultCategoriesIfNeeded(context: container.mainContext)
            
        } catch {
            // SECURITY: Don't expose internal error details to users
            // Log error for debugging but show generic message
            print("❌ Failed to initialize SwiftData: \(error.localizedDescription)")
            fatalError("Failed to initialize data storage. Please reinstall the app.")
        }
    }
    
    // MARK: - Body
    
    var body: some Scene {
        WindowGroup {
            InventoryView()
                .modelContainer(modelContainer)
                .task {
                    // Perform migration from UserDefaults if needed
                    // This runs after the view appears, when self is fully initialized
                    await performMigrationIfNeeded()
                }
        }
    }
    
    // MARK: - Private Methods
    
    /// Performs migration from UserDefaults to SwiftData if needed
    private func performMigrationIfNeeded() async {
        do {
            let migratedCount = try await migrationService.migrateFromUserDefaults()
            if migratedCount > 0 {
                print("✅ Successfully migrated \(migratedCount) items from UserDefaults")
            }
        } catch {
            print("⚠️ Migration failed: \(error.localizedDescription)")
            // Non-fatal: app can continue without migration
        }
    }
    
    /// Seeds default categories if the database is empty
    /// - Parameter context: The model context to use
    private static func seedDefaultCategoriesIfNeeded(context: ModelContext) {
        // Check if categories already exist
        let descriptor = FetchDescriptor<CategoryEntity>()
        
        do {
            let existingCategories = try context.fetch(descriptor)
            
            // Only seed if no categories exist
            guard existingCategories.isEmpty else { return }
            
            // Create default categories
            let defaultCategories = [
                CategoryEntity(name: "Electronics", iconName: "laptopcomputer", colorHex: "#007AFF"),
                CategoryEntity(name: "Office Supplies", iconName: "pencil.and.ruler", colorHex: "#34C759"),
                CategoryEntity(name: "Furniture", iconName: "chair.lounge", colorHex: "#FF9500"),
                CategoryEntity(name: "Food & Beverage", iconName: "cup.and.saucer", colorHex: "#FF2D55"),
                CategoryEntity(name: "Clothing", iconName: "tshirt", colorHex: "#AF52DE"),
                CategoryEntity(name: "Tools", iconName: "wrench.and.screwdriver", colorHex: "#8E8E93"),
                CategoryEntity(name: "Other", iconName: "square.grid.2x2", colorHex: "#5856D6")
            ]
            
            // Insert all categories
            for category in defaultCategories {
                context.insert(category)
            }
            
            // Save context
            try context.save()
            print("✅ Seeded \(defaultCategories.count) default categories")
            
        } catch {
            print("⚠️ Failed to seed categories: \(error.localizedDescription)")
            // Non-fatal: app can work without default categories
        }
    }
}

