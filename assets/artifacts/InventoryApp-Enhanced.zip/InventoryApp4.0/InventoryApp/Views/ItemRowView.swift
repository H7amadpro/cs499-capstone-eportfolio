//
//  ItemRowView.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//
//  MILESTONE FOUR: Database Enhancement
//
//  Reusable row component for displaying inventory items in a list.
//

import SwiftUI

/// Row view for displaying an inventory item
struct ItemRowView: View {
    
    /// The item to display
    let item: Item
    
    var body: some View {
        HStack(spacing: 12) {
            // Category icon
            Image(systemName: item.categoryIconName)
                .font(.title2)
                .foregroundColor(.accentColor)
                .frame(width: 40, height: 40)
                .background(Color.accentColor.opacity(0.1))
                .cornerRadius(8)
            
            // Item details
            VStack(alignment: .leading, spacing: 4) {
                Text(item.name)
                    .font(.headline)
                    .lineLimit(1)
                
                HStack(spacing: 8) {
                    Text(item.categoryName)
                        .font(.caption)
                        .foregroundColor(.secondary)
                    
                    if item.isLowStock {
                        Label("Low Stock", systemImage: "exclamationmark.triangle.fill")
                            .font(.caption2)
                            .foregroundColor(.orange)
                    }
                }
            }
            
            Spacer()
            
            // Quantity and price
            VStack(alignment: .trailing, spacing: 4) {
                Text(item.formattedPrice)
                    .font(.headline)
                
                Text("Qty: \(item.quantity)")
                    .font(.caption)
                    .foregroundColor(item.isLowStock ? .orange : .secondary)
            }
        }
        .padding(.vertical, 4)
    }
}

// MARK: - Preview

#Preview {
    List {
        ItemRowView(item: Item(name: "MacBook Pro", quantity: 5, price: 1999.99))
        ItemRowView(item: Item(name: "iPhone 15", quantity: 2, price: 999.99))
    }
    .modelContainer(for: Item.self, inMemory: true)
}
