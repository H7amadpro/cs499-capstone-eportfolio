//
//  InventoryView.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//
//  MILESTONE FOUR: Database Enhancement
//
//  This view demonstrates:
//  - SwiftData @Query for reactive data fetching
//  - SwiftUI integration with SwiftData
//  - MVVM architecture with SwiftData
//

import SwiftUI
import SwiftData

/// Main inventory list view
///
/// Uses SwiftData's @Query for automatic data fetching and updates.
/// The view automatically refreshes when the database changes.
struct InventoryView: View {
    
    // MARK: - Environment
    
    /// SwiftData model context from environment
    @Environment(\.modelContext) private var modelContext
    
    /// Items fetched from SwiftData
    /// @Query automatically observes changes and updates the view
    @Query(sort: \Item.name) private var items: [Item]
    
    /// Categories for filtering
    @Query(sort: \CategoryEntity.name) private var categories: [CategoryEntity]
    
    // MARK: - State
    
    /// Search text binding
    @State private var searchText = ""
    
    /// Selected category for filtering
    @State private var selectedCategory: CategoryEntity?
    
    /// Whether to show add item sheet
    @State private var showingAddItem = false
    
    /// Item selected for editing
    @State private var editingItem: Item?
    
    /// Whether to show low stock alert
    @State private var showingLowStockAlert = false
    
    // MARK: - Computed Properties
    
    /// Filtered items based on search and category
    var filteredItems: [Item] {
        var result = items
        
        // Filter by category
        if let category = selectedCategory {
            result = result.filter { $0.category?.id == category.id }
        }
        
        // Filter by search text
        if !searchText.isEmpty {
            result = result.filter { item in
                item.name.localizedCaseInsensitiveContains(searchText)
            }
        }
        
        return result
    }
    
    /// Items with low stock
    var lowStockItems: [Item] {
        items.filter { $0.quantity <= 5 }
    }
    
    /// Total inventory value
    var totalValue: Double {
        filteredItems.reduce(0) { $0 + $1.totalValue }
    }
    
    // MARK: - Body
    
    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                // Summary header
                summaryHeader
                
                // Category filter
                if !categories.isEmpty {
                    categoryFilter
                }
                
                // Item list
                itemList
            }
            .navigationTitle("Inventory")
            .searchable(text: $searchText, prompt: "Search items...")
            .toolbar {
                ToolbarItem(placement: .primaryAction) {
                    Button {
                        showingAddItem = true
                    } label: {
                        Image(systemName: "plus")
                    }
                }
                
                ToolbarItem(placement: .topBarLeading) {
                    if !lowStockItems.isEmpty {
                        Button {
                            showingLowStockAlert = true
                        } label: {
                            HStack(spacing: 4) {
                                Image(systemName: "exclamationmark.triangle.fill")
                                Text("\(lowStockItems.count)")
                            }
                            .foregroundColor(.orange)
                        }
                    }
                }
            }
            .sheet(isPresented: $showingAddItem) {
                AddItemView()
            }
            .sheet(item: $editingItem) { item in
                AddItemView(editing: item)
            }
            .alert("Low Stock Items", isPresented: $showingLowStockAlert) {
                Button("OK", role: .cancel) {}
            } message: {
                Text("\(lowStockItems.count) items are running low on stock.")
            }
        }
    }
    
    // MARK: - Subviews
    
    /// Summary header showing total items and value
    private var summaryHeader: some View {
        HStack {
            VStack(alignment: .leading) {
                Text("\(filteredItems.count) Items")
                    .font(.headline)
                Text("Total: \(totalValue, format: .currency(code: "USD"))")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
            }
            
            Spacer()
            
            if !lowStockItems.isEmpty {
                VStack(alignment: .trailing) {
                    Text("\(lowStockItems.count) Low Stock")
                        .font(.caption)
                        .foregroundColor(.orange)
                }
            }
        }
        .padding()
        .background(Color(.systemGroupedBackground))
    }
    
    /// Horizontal category filter buttons
    private var categoryFilter: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                // All categories button
                CategoryFilterButton(
                    title: "All",
                    iconName: "square.grid.2x2",
                    isSelected: selectedCategory == nil
                ) {
                    selectedCategory = nil
                }
                
                // Individual category buttons
                ForEach(categories) { category in
                    CategoryFilterButton(
                        title: category.name,
                        iconName: category.iconName,
                        isSelected: selectedCategory?.id == category.id
                    ) {
                        selectedCategory = category
                    }
                }
            }
            .padding(.horizontal)
        }
        .padding(.vertical, 8)
        .background(Color(.systemGroupedBackground))
    }
    
    /// List of inventory items
    private var itemList: some View {
        List {
            if filteredItems.isEmpty {
                ContentUnavailableView {
                    Label("No Items", systemImage: "tray")
                } description: {
                    if !searchText.isEmpty {
                        Text("No items match your search.")
                    } else if selectedCategory != nil {
                        Text("No items in this category.")
                    } else {
                        Text("Add your first inventory item.")
                    }
                } actions: {
                    Button("Add Item") {
                        showingAddItem = true
                    }
                }
            } else {
                ForEach(filteredItems) { item in
                    ItemRowView(item: item)
                        .contentShape(Rectangle())
                        .onTapGesture {
                            editingItem = item
                        }
                }
                .onDelete(perform: deleteItems)
            }
        }
        .listStyle(.plain)
    }
    
    // MARK: - Methods
    
    /// Deletes items at the specified indices
    private func deleteItems(at offsets: IndexSet) {
        for index in offsets {
            let item = filteredItems[index]
            modelContext.delete(item)
        }
        
        do {
            try modelContext.save()
        } catch {
            print("Failed to delete items: \(error)")
        }
    }
}

// MARK: - Category Filter Button

/// Button for filtering by category
struct CategoryFilterButton: View {
    let title: String
    let iconName: String
    let isSelected: Bool
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            HStack(spacing: 4) {
                Image(systemName: iconName)
                    .font(.caption)
                Text(title)
                    .font(.caption)
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 6)
            .background(isSelected ? Color.accentColor : Color(.systemGray5))
            .foregroundColor(isSelected ? .white : .primary)
            .cornerRadius(16)
        }
        .buttonStyle(.plain)
    }
}

// MARK: - Preview

#Preview {
    InventoryView()
        .modelContainer(for: [Item.self, CategoryEntity.self], inMemory: true)
}
