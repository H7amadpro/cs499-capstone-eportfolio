//
//  AddItemView.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//
//  MILESTONE FOUR: Database Enhancement
//
//  This view handles adding and editing inventory items with:
//  - Form validation before saving
//  - Category selection with SwiftData
//  - User-friendly error messages
//

import SwiftUI
import SwiftData

/// View for adding or editing an inventory item
struct AddItemView: View {
    
    // MARK: - Environment
    
    @Environment(\.modelContext) private var modelContext
    @Environment(\.dismiss) private var dismiss
    
    /// Categories for picker
    @Query(sort: \CategoryEntity.name) private var categories: [CategoryEntity]
    
    // MARK: - State
    
    @State private var name = ""
    @State private var quantityString = ""
    @State private var priceString = ""
    @State private var selectedCategory: CategoryEntity?
    
    @State private var showingError = false
    @State private var errorMessage = ""
    @State private var isSaving = false
    
    // MARK: - Edit Mode
    
    /// Item being edited (nil for new item)
    let editingItem: Item?
    
    /// Whether in edit mode
    var isEditing: Bool {
        editingItem != nil
    }
    
    // MARK: - Initialization
    
    init(editing item: Item? = nil) {
        self.editingItem = item
    }
    
    // MARK: - Computed Properties
    
    /// Parsed quantity value
    var quantity: Int {
        Int(quantityString) ?? 0
    }
    
    /// Parsed price value
    var price: Double {
        Double(priceString) ?? 0.0
    }
    
    /// Whether form can be submitted
    var canSave: Bool {
        !name.trimmingCharacters(in: .whitespaces).isEmpty &&
        !quantityString.isEmpty &&
        !priceString.isEmpty
    }
    
    // MARK: - Body
    
    var body: some View {
        NavigationStack {
            Form {
                // Item details section
                Section("Item Details") {
                    TextField("Name", text: $name)
                        .textContentType(.name)
                        .autocorrectionDisabled()
                    
                    TextField("Quantity", text: $quantityString)
                        .keyboardType(.numberPad)
                    
                    TextField("Price", text: $priceString)
                        .keyboardType(.decimalPad)
                }
                
                // Category section
                Section("Category") {
                    if categories.isEmpty {
                        Text("No categories available")
                            .foregroundColor(.secondary)
                    } else {
                        Picker("Category", selection: $selectedCategory) {
                            Text("None").tag(nil as CategoryEntity?)
                            ForEach(categories) { category in
                                HStack {
                                    Image(systemName: category.iconName)
                                    Text(category.name)
                                }
                                .tag(category as CategoryEntity?)
                            }
                        }
                    }
                }
                
                // Preview section
                if canSave {
                    Section("Preview") {
                        HStack {
                            Text("Total Value")
                            Spacer()
                            Text(Double(quantity) * price, format: .currency(code: "USD"))
                                .foregroundColor(.secondary)
                        }
                    }
                }
            }
            .navigationTitle(isEditing ? "Edit Item" : "Add Item")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") {
                        dismiss()
                    }
                }
                
                ToolbarItem(placement: .confirmationAction) {
                    Button(isEditing ? "Update" : "Add") {
                        saveItem()
                    }
                    .disabled(!canSave || isSaving)
                }
            }
            .alert("Error", isPresented: $showingError) {
                Button("OK", role: .cancel) {}
            } message: {
                Text(errorMessage)
            }
            .onAppear {
                populateForEditing()
            }
        }
    }
    
    // MARK: - Methods
    
    /// Populates form fields when editing
    private func populateForEditing() {
        if let item = editingItem {
            name = item.name
            quantityString = String(item.quantity)
            priceString = String(format: "%.2f", item.price)
            selectedCategory = item.category
        } else if selectedCategory == nil && !categories.isEmpty {
            selectedCategory = categories.first
        }
    }
    
    /// Validates and saves the item
    private func saveItem() {
        isSaving = true
        
        // Validate input
        do {
            try ValidationService.validateItem(
                name: name,
                quantity: quantity,
                price: price,
                category: selectedCategory
            )
        } catch let error as ValidationError {
            showError(error.errorDescription ?? "Validation failed")
            isSaving = false
            return
        } catch {
            showError("An unexpected error occurred")
            isSaving = false
            return
        }
        
        // Save item
        if let existingItem = editingItem {
            // Update existing
            existingItem.update(
                name: name,
                quantity: quantity,
                price: price,
                category: selectedCategory
            )
        } else {
            // Create new
            let newItem = Item(
                name: name,
                quantity: quantity,
                price: price,
                category: selectedCategory
            )
            modelContext.insert(newItem)
        }
        
        // Save context
        do {
            try modelContext.save()
            dismiss()
        } catch {
            showError("Failed to save item. Please try again.")
        }
        
        isSaving = false
    }
    
    /// Shows an error message
    private func showError(_ message: String) {
        errorMessage = message
        showingError = true
    }
}

// MARK: - Preview

#Preview("Add Item") {
    AddItemView()
        .modelContainer(for: [Item.self, CategoryEntity.self], inMemory: true)
}

#Preview("Edit Item") {
    let item = Item(name: "Test Item", quantity: 10, price: 29.99)
    return AddItemView(editing: item)
        .modelContainer(for: [Item.self, CategoryEntity.self], inMemory: true)
}
