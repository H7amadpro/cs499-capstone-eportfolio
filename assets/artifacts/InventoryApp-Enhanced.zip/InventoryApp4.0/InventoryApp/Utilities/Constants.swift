//
//  Constants.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//
//  MILESTONE FOUR: Database Enhancement
//
//  Centralized configuration constants for the application.
//

import Foundation

/// Application-wide constants
enum Constants {
    
    // MARK: - Validation Limits
    
    /// Maximum length for item names
    static let maxNameLength = 100
    
    /// Minimum length for item names
    static let minNameLength = 1
    
    /// Maximum quantity for any item
    static let maxQuantity = 999_999
    
    /// Maximum price for any item
    static let maxPrice: Double = 999_999.99
    
    // MARK: - Stock Thresholds
    
    /// Quantity threshold for low stock warning
    static let lowStockThreshold = 5
    
    // MARK: - UserDefaults Keys
    
    /// Key for legacy inventory data (used in migration)
    static let legacyInventoryKey = "inventory_items"
    
    /// Key for migration completion flag
    static let migrationCompletedKey = "migration_v1_completed"
    
    // MARK: - Date Formats
    
    /// Standard date formatter for display
    static let displayDateFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        formatter.timeStyle = .short
        return formatter
    }()
    
    // MARK: - Currency
    
    /// Default currency code
    static let currencyCode = "USD"
}
