//
//  ValidationService.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//
//  MILESTONE FOUR: Database Enhancement
//
//  This file demonstrates:
//  - Comprehensive input validation before database storage
//  - User-friendly error messages
//  - Security-focused validation rules
//  - Defense in depth approach to data integrity
//
//  Security Considerations:
//  - All user input is validated before reaching the database
//  - Length limits prevent buffer overflow attacks
//  - Character validation prevents injection attacks
//  - Numeric bounds prevent integer overflow
//
//  Course Outcome 5: Security Mindset
//  This service anticipates adversarial input and validates
//  all data before it can affect the database.
//

import Foundation

// MARK: - Validation Errors

/// Enumeration of all possible validation errors
/// Each case provides a specific, user-friendly error message
///
/// SECURITY: Error messages are informative but don't expose
/// internal implementation details that could aid attackers
enum ValidationError: LocalizedError {
    // Name validation errors
    case emptyName
    case nameTooLong(maxLength: Int)
    case nameTooShort(minLength: Int)
    case invalidCharactersInName
    case nameContainsSuspiciousContent
    
    // Quantity validation errors
    case negativeQuantity
    case quantityTooLarge(maxQuantity: Int)
    case invalidQuantityFormat
    
    // Price validation errors
    case negativePrice
    case priceTooLarge(maxPrice: Double)
    case invalidPriceFormat
    case tooManyDecimalPlaces
    
    // Category validation errors
    case invalidCategory
    case categoryRequired
    
    // General errors
    case multipleErrors([ValidationError])
    
    /// User-friendly error description
    /// These messages are safe to display to users
    var errorDescription: String? {
        switch self {
        case .emptyName:
            return "Item name cannot be empty"
        case .nameTooLong(let maxLength):
            return "Item name cannot exceed \(maxLength) characters"
        case .nameTooShort(let minLength):
            return "Item name must be at least \(minLength) character(s)"
        case .invalidCharactersInName:
            return "Item name contains invalid characters"
        case .nameContainsSuspiciousContent:
            return "Item name contains disallowed content"
        case .negativeQuantity:
            return "Quantity cannot be negative"
        case .quantityTooLarge(let maxQuantity):
            return "Quantity cannot exceed \(maxQuantity.formatted())"
        case .invalidQuantityFormat:
            return "Quantity must be a whole number"
        case .negativePrice:
            return "Price cannot be negative"
        case .priceTooLarge(let maxPrice):
            return "Price cannot exceed \(String(format: "$%.2f", maxPrice))"
        case .invalidPriceFormat:
            return "Price format is invalid"
        case .tooManyDecimalPlaces:
            return "Price can have at most 2 decimal places"
        case .invalidCategory:
            return "Please select a valid category"
        case .categoryRequired:
            return "Please select a category"
        case .multipleErrors(let errors):
            return errors.compactMap { $0.errorDescription }.joined(separator: "\n")
        }
    }
    
    /// Recovery suggestion for the user
    var recoverySuggestion: String? {
        switch self {
        case .emptyName:
            return "Enter a descriptive name for the item"
        case .nameTooLong:
            return "Try using a shorter, more concise name"
        case .invalidCharactersInName:
            return "Use only letters, numbers, spaces, and basic punctuation"
        case .negativeQuantity:
            return "Enter 0 or a positive number"
        case .negativePrice:
            return "Enter 0 or a positive price"
        default:
            return nil
        }
    }
}

// MARK: - Validation Service

/// Service responsible for validating all user input before database storage
///
/// This service implements defense-in-depth by validating:
/// 1. Data type correctness
/// 2. Value range constraints
/// 3. Character safety (no injection attacks)
/// 4. Business logic rules
///
/// SECURITY: All validation happens before data reaches SwiftData
/// to prevent malicious data from being persisted
final class ValidationService {
    
    // MARK: - Constants
    
    /// Maximum allowed length for item names
    /// Prevents excessively long strings that could cause UI issues
    static let maxNameLength = 100
    
    /// Minimum allowed length for item names
    static let minNameLength = 1
    
    /// Maximum allowed quantity for any item
    /// Prevents integer overflow and unrealistic values
    static let maxQuantity = 999_999
    
    /// Maximum allowed price for any item
    /// Prevents floating point issues with very large numbers
    static let maxPrice: Double = 999_999.99
    
    /// Characters allowed in item names
    /// Whitelist approach is more secure than blacklist
    static let allowedNameCharacters = CharacterSet.alphanumerics
        .union(.whitespaces)
        .union(CharacterSet(charactersIn: "-_.,&'\"()"))
    
    // MARK: - Main Validation Method
    
    /// Validates all item properties before saving to database
    ///
    /// - Parameters:
    ///   - name: Item name to validate
    ///   - quantity: Item quantity to validate
    ///   - price: Item price to validate
    ///   - category: Category entity (optional)
    ///
    /// - Throws: ValidationError if any validation fails
    ///
    /// Usage:
    /// ```swift
    /// do {
    ///     try ValidationService.validateItem(
    ///         name: nameField,
    ///         quantity: quantityField,
    ///         price: priceField,
    ///         category: selectedCategory
    ///     )
    ///     // Safe to save to database
    /// } catch let error as ValidationError {
    ///     // Show error.errorDescription to user
    /// }
    /// ```
    static func validateItem(
        name: String,
        quantity: Int,
        price: Double,
        category: CategoryEntity?
    ) throws {
        var errors: [ValidationError] = []
        
        // Validate name
        if let nameError = validateName(name) {
            errors.append(nameError)
        }
        
        // Validate quantity
        if let quantityError = validateQuantity(quantity) {
            errors.append(quantityError)
        }
        
        // Validate price
        if let priceError = validatePrice(price) {
            errors.append(priceError)
        }
        
        // Validate category (optional but recommended)
        // Note: Category is optional to allow items without categories
        // Uncomment below to require category:
        // if category == nil {
        //     errors.append(.categoryRequired)
        // }
        
        // Throw if any errors found
        if errors.count == 1 {
            throw errors[0]
        } else if errors.count > 1 {
            throw ValidationError.multipleErrors(errors)
        }
    }
    
    // MARK: - Individual Validation Methods
    
    /// Validates item name
    ///
    /// Checks:
    /// - Not empty
    /// - Within length limits
    /// - Contains only allowed characters
    /// - No suspicious content (potential injection)
    ///
    /// - Parameter name: Name string to validate
    /// - Returns: ValidationError if invalid, nil if valid
    static func validateName(_ name: String) -> ValidationError? {
        let trimmedName = name.trimmingCharacters(in: .whitespacesAndNewlines)
        
        // Check for empty name
        if trimmedName.isEmpty {
            return .emptyName
        }
        
        // Check minimum length
        if trimmedName.count < minNameLength {
            return .nameTooShort(minLength: minNameLength)
        }
        
        // Check maximum length
        if trimmedName.count > maxNameLength {
            return .nameTooLong(maxLength: maxNameLength)
        }
        
        // Check for invalid characters (security measure)
        let nameCharacterSet = CharacterSet(charactersIn: trimmedName)
        if !allowedNameCharacters.isSuperset(of: nameCharacterSet) {
            return .invalidCharactersInName
        }
        
        // Check for suspicious content (injection attempts)
        if SecurityUtilities.containsSuspiciousContent(trimmedName) {
            return .nameContainsSuspiciousContent
        }
        
        return nil
    }
    
    /// Validates item quantity
    ///
    /// Checks:
    /// - Non-negative
    /// - Within maximum limit
    ///
    /// - Parameter quantity: Quantity integer to validate
    /// - Returns: ValidationError if invalid, nil if valid
    static func validateQuantity(_ quantity: Int) -> ValidationError? {
        // Check for negative quantity
        if quantity < 0 {
            return .negativeQuantity
        }
        
        // Check maximum quantity
        if quantity > maxQuantity {
            return .quantityTooLarge(maxQuantity: maxQuantity)
        }
        
        return nil
    }
    
    /// Validates item price
    ///
    /// Checks:
    /// - Non-negative
    /// - Within maximum limit
    /// - Valid decimal format (max 2 decimal places)
    ///
    /// - Parameter price: Price double to validate
    /// - Returns: ValidationError if invalid, nil if valid
    static func validatePrice(_ price: Double) -> ValidationError? {
        // Check for negative price
        if price < 0 {
            return .negativePrice
        }
        
        // Check maximum price
        if price > maxPrice {
            return .priceTooLarge(maxPrice: maxPrice)
        }
        
        // Check for NaN or Infinity (invalid floating point values)
        if price.isNaN || price.isInfinite {
            return .invalidPriceFormat
        }
        
        // Check decimal places (max 2 for currency)
        let decimalPlaces = getDecimalPlaces(price)
        if decimalPlaces > 2 {
            return .tooManyDecimalPlaces
        }
        
        return nil
    }
    
    /// Validates a price string before conversion
    ///
    /// - Parameter priceString: String representation of price
    /// - Returns: Validated Double or nil if invalid
    static func validatePriceString(_ priceString: String) -> Double? {
        // Remove currency symbols and whitespace
        let cleanedString = priceString
            .replacingOccurrences(of: "$", with: "")
            .replacingOccurrences(of: ",", with: "")
            .trimmingCharacters(in: .whitespaces)
        
        // Attempt conversion
        guard let price = Double(cleanedString) else {
            return nil
        }
        
        // Validate the converted value
        if validatePrice(price) != nil {
            return nil
        }
        
        return price
    }
    
    /// Validates a quantity string before conversion
    ///
    /// - Parameter quantityString: String representation of quantity
    /// - Returns: Validated Int or nil if invalid
    static func validateQuantityString(_ quantityString: String) -> Int? {
        let cleanedString = quantityString
            .replacingOccurrences(of: ",", with: "")
            .trimmingCharacters(in: .whitespaces)
        
        guard let quantity = Int(cleanedString) else {
            return nil
        }
        
        if validateQuantity(quantity) != nil {
            return nil
        }
        
        return quantity
    }
    
    // MARK: - Helper Methods
    
    /// Counts decimal places in a Double
    ///
    /// - Parameter value: Double value to check
    /// - Returns: Number of decimal places
    private static func getDecimalPlaces(_ value: Double) -> Int {
        let stringValue = String(format: "%.10f", value)
        guard let decimalIndex = stringValue.firstIndex(of: ".") else {
            return 0
        }
        
        let decimalPart = String(stringValue[stringValue.index(after: decimalIndex)...])
        let trimmed = decimalPart.replacingOccurrences(of: "0+$", with: "", options: .regularExpression)
        
        return trimmed.count
    }
}
