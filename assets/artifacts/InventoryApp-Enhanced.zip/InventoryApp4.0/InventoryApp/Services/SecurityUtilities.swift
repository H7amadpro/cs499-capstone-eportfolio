//
//  SecurityUtilities.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//
//  MILESTONE FOUR: Database Enhancement
//
//  This file demonstrates:
//  - Input sanitization to prevent injection attacks
//  - Security-focused string processing
//  - Defense in depth approach
//  - Audit trail support
//
//  Course Outcome 5: Security Mindset
//  This utility class anticipates adversarial exploits by:
//  - Sanitizing all user input before storage
//  - Detecting potential injection attempts
//  - Providing secure string handling utilities
//
//  Security Measures:
//  - HTML tag stripping prevents XSS if data is displayed in web views
//  - SQL-like pattern detection (even though SwiftData prevents injection)
//  - Script tag detection for defense in depth
//  - Whitespace normalization prevents hidden character attacks
//

import Foundation

/// Utility class providing security-focused string operations
///
/// All user input should pass through these utilities before
/// being stored in the database. This provides defense in depth
/// even though SwiftData uses parameterized queries.
///
/// SECURITY PRINCIPLE: Never trust user input
final class SecurityUtilities {
    
    // MARK: - Suspicious Patterns
    
    /// Patterns that may indicate injection attempts
    /// These are checked even though SwiftData prevents SQL injection
    /// as a defense-in-depth measure
    private static let suspiciousPatterns: [String] = [
        "<script",          // JavaScript injection
        "</script",
        "javascript:",      // JavaScript protocol
        "onclick",          // Event handlers
        "onerror",
        "onload",
        "DROP TABLE",       // SQL injection patterns
        "DELETE FROM",
        "INSERT INTO",
        "UPDATE SET",
        "UNION SELECT",
        "--",               // SQL comment
        "/*",               // SQL block comment
        "*/",
        "';",               // SQL statement terminator
        "1=1",              // SQL tautology
        "OR 1=1",
        "' OR '",
        "eval(",            // Code execution
        "exec(",
        "system(",
    ]
    
    /// HTML tags to strip from input
    private static let htmlTagPattern = "<[^>]+>"
    
    // MARK: - Sanitization Methods
    
    /// Sanitizes user input by removing potentially harmful content
    ///
    /// This method:
    /// 1. Trims leading/trailing whitespace
    /// 2. Removes HTML tags
    /// 3. Normalizes internal whitespace
    /// 4. Removes control characters
    ///
    /// - Parameter input: Raw user input string
    /// - Returns: Sanitized string safe for storage
    ///
    /// Usage:
    /// ```swift
    /// let safeName = SecurityUtilities.sanitize(userInput)
    /// // safeName is now safe to store in database
    /// ```
    static func sanitize(_ input: String) -> String {
        var result = input
        
        // Step 1: Trim whitespace
        result = result.trimmingCharacters(in: .whitespacesAndNewlines)
        
        // Step 2: Remove HTML tags
        result = stripHTMLTags(result)
        
        // Step 3: Remove control characters (except newlines and tabs)
        result = removeControlCharacters(result)
        
        // Step 4: Normalize whitespace (collapse multiple spaces)
        result = normalizeWhitespace(result)
        
        // Step 5: Limit length to prevent buffer issues
        if result.count > 1000 {
            result = String(result.prefix(1000))
        }
        
        return result
    }
    
    /// Strips HTML tags from a string
    ///
    /// Prevents XSS attacks if the data is later displayed in a web view
    /// or exported to HTML format
    ///
    /// - Parameter input: String potentially containing HTML
    /// - Returns: String with HTML tags removed
    static func stripHTMLTags(_ input: String) -> String {
        guard let regex = try? NSRegularExpression(
            pattern: htmlTagPattern,
            options: .caseInsensitive
        ) else {
            return input
        }
        
        let range = NSRange(input.startIndex..., in: input)
        return regex.stringByReplacingMatches(
            in: input,
            options: [],
            range: range,
            withTemplate: ""
        )
    }
    
    /// Removes control characters from a string
    ///
    /// Control characters can be used to hide malicious content
    /// or cause display issues
    ///
    /// - Parameter input: String to clean
    /// - Returns: String with control characters removed
    static func removeControlCharacters(_ input: String) -> String {
        // Keep newlines and tabs, remove other control characters
        let allowedControlChars = CharacterSet(charactersIn: "\n\t")
        let controlChars = CharacterSet.controlCharacters.subtracting(allowedControlChars)
        
        return input.unicodeScalars
            .filter { !controlChars.contains($0) }
            .map { String($0) }
            .joined()
    }
    
    /// Normalizes whitespace by collapsing multiple spaces into one
    ///
    /// - Parameter input: String with potentially irregular whitespace
    /// - Returns: String with normalized whitespace
    static func normalizeWhitespace(_ input: String) -> String {
        let components = input.components(separatedBy: .whitespaces)
        return components.filter { !$0.isEmpty }.joined(separator: " ")
    }
    
    // MARK: - Detection Methods
    
    /// Checks if input contains suspicious content that may indicate an attack
    ///
    /// This is a defense-in-depth measure. Even though SwiftData
    /// uses parameterized queries (preventing SQL injection), we still
    /// check for suspicious patterns to:
    /// 1. Log potential attack attempts
    /// 2. Prevent stored XSS if data is displayed elsewhere
    /// 3. Maintain security best practices
    ///
    /// - Parameter input: String to check
    /// - Returns: true if suspicious content detected
    static func containsSuspiciousContent(_ input: String) -> Bool {
        let lowercaseInput = input.lowercased()
        
        for pattern in suspiciousPatterns {
            if lowercaseInput.contains(pattern.lowercased()) {
                // Log the detection (in production, this would go to security logs)
                logSecurityEvent(
                    type: .suspiciousInput,
                    details: "Detected pattern: \(pattern)"
                )
                return true
            }
        }
        
        return false
    }
    
    /// Validates that input is safe for storage
    ///
    /// Combines sanitization check with suspicious content detection
    ///
    /// - Parameter input: String to validate
    /// - Returns: true if input is safe
    static func isInputSafe(_ input: String) -> Bool {
        // Check for suspicious patterns
        if containsSuspiciousContent(input) {
            return false
        }
        
        // Check for null bytes (can cause issues in C-based systems)
        if input.contains("\0") {
            return false
        }
        
        // Check for excessively long input
        if input.count > 10000 {
            return false
        }
        
        return true
    }
    
    // MARK: - Audit Trail
    
    /// Security event types for logging
    enum SecurityEventType: String {
        case suspiciousInput = "SUSPICIOUS_INPUT"
        case validationFailure = "VALIDATION_FAILURE"
        case unauthorizedAccess = "UNAUTHORIZED_ACCESS"
        case dataModification = "DATA_MODIFICATION"
    }
    
    /// Logs a security event for audit purposes
    ///
    /// In a production environment, this would write to a secure
    /// audit log that cannot be modified by the application.
    ///
    /// - Parameters:
    ///   - type: Type of security event
    ///   - details: Additional details about the event
    static func logSecurityEvent(type: SecurityEventType, details: String) {
        let timestamp = ISO8601DateFormatter().string(from: Date())
        let logMessage = "[\(timestamp)] SECURITY [\(type.rawValue)]: \(details)"
        
        // In production, this would go to a secure audit log
        // For now, we print to console (visible in Xcode debug output)
        #if DEBUG
        print("🔒 \(logMessage)")
        #endif
        
        // TODO: In production, implement secure logging:
        // - Write to encrypted log file
        // - Send to security monitoring service
        // - Store in tamper-evident format
    }
    
    // MARK: - Data Integrity
    
    /// Generates a simple checksum for data integrity verification
    ///
    /// This can be used to detect if data has been tampered with
    /// outside of the application
    ///
    /// - Parameter data: Data to checksum
    /// - Returns: Checksum string
    static func generateChecksum(_ data: String) -> String {
        var hash = 0
        for char in data.unicodeScalars {
            hash = 31 &* hash &+ Int(char.value)
        }
        return String(format: "%08x", hash)
    }
    
    /// Verifies data against a checksum
    ///
    /// - Parameters:
    ///   - data: Data to verify
    ///   - checksum: Expected checksum
    /// - Returns: true if data matches checksum
    static func verifyChecksum(_ data: String, checksum: String) -> Bool {
        return generateChecksum(data) == checksum
    }
}

// MARK: - String Extension

extension String {
    /// Sanitized version of this string
    /// Convenience property for cleaner code
    var sanitized: String {
        SecurityUtilities.sanitize(self)
    }
    
    /// Whether this string is safe for storage
    var isSafe: Bool {
        SecurityUtilities.isInputSafe(self)
    }
}
