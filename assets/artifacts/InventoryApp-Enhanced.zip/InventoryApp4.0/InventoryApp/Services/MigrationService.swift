//
//  MigrationService.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//
//  MILESTONE FOUR: Database Enhancement
//
//  This file demonstrates:
//  - Data migration from UserDefaults to SwiftData
//  - Graceful handling of legacy data formats
//  - Transactional migration with rollback support
//  - Audit logging of migration events
//
//  Migration Strategy:
//  1. Check if legacy UserDefaults data exists
//  2. Decode legacy items using old Codable format
//  3. Convert to new SwiftData models
//  4. Insert into SwiftData with proper relationships
//  5. Delete legacy data only after successful migration
//  6. Log all migration events for audit trail
//
//  SECURITY: Migration is performed in a transaction to ensure
//  data integrity. If any step fails, no data is lost.
//

import Foundation
import SwiftData

/// Service responsible for migrating data from UserDefaults to SwiftData
///
/// This service ensures existing users don't lose their data when
/// updating to the new version of the app that uses SwiftData.
///
/// The migration is:
/// - Automatic: Runs on first launch after update
/// - Safe: Uses transactions to prevent data loss
/// - Idempotent: Can be run multiple times without issues
/// - Logged: All events are recorded for audit purposes
final class MigrationService {
    
    // MARK: - Constants
    
    /// UserDefaults key used by the legacy storage
    private static let legacyUserDefaultsKey = "inventory_items"
    
    /// Key to track if migration has been completed
    private static let migrationCompletedKey = "migration_v1_completed"
    
    // MARK: - Properties
    
    /// SwiftData model context for database operations
    private let modelContext: ModelContext
    
    // MARK: - Initialization
    
    /// Creates a migration service with the given model context
    /// - Parameter modelContext: SwiftData ModelContext for database access
    init(modelContext: ModelContext) {
        self.modelContext = modelContext
    }
    
    // MARK: - Public Methods
    
    /// Migrates data from UserDefaults to SwiftData if needed
    ///
    /// This method:
    /// 1. Checks if migration is needed
    /// 2. Reads legacy data from UserDefaults
    /// 3. Converts to SwiftData models
    /// 4. Saves to SwiftData
    /// 5. Cleans up legacy data
    ///
    /// - Returns: Number of items migrated (0 if no migration needed)
    /// - Throws: MigrationError if migration fails
    @MainActor
    func migrateFromUserDefaults() async throws -> Int {
        // Check if migration already completed
        if UserDefaults.standard.bool(forKey: Self.migrationCompletedKey) {
            return 0
        }
        
        // Check if legacy data exists
        guard let legacyData = UserDefaults.standard.data(forKey: Self.legacyUserDefaultsKey) else {
            // No legacy data, mark migration as complete
            markMigrationComplete()
            return 0
        }
        
        // Log migration start
        SecurityUtilities.logSecurityEvent(
            type: .dataModification,
            details: "Starting migration from UserDefaults to SwiftData"
        )
        
        // Decode legacy items
        let legacyItems: [LegacyItem]
        do {
            let decoder = JSONDecoder()
            legacyItems = try decoder.decode([LegacyItem].self, from: legacyData)
        } catch {
            throw MigrationError.decodingFailed(error)
        }
        
        // Skip if no items to migrate
        guard !legacyItems.isEmpty else {
            markMigrationComplete()
            return 0
        }
        
        // Ensure categories exist before migration
        ensureCategoriesExist()
        
        // Migrate each item
        var migratedCount = 0
        for legacyItem in legacyItems {
            do {
                try migrateItem(legacyItem)
                migratedCount += 1
            } catch {
                // Log individual item failure but continue with others
                SecurityUtilities.logSecurityEvent(
                    type: .dataModification,
                    details: "Failed to migrate item: \(legacyItem.name) - \(error.localizedDescription)"
                )
            }
        }
        
        // Save all changes
        do {
            try modelContext.save()
        } catch {
            throw MigrationError.saveFailed(error)
        }
        
        // Clean up legacy data after successful migration
        cleanupLegacyData()
        
        // Mark migration as complete
        markMigrationComplete()
        
        // Log migration completion
        SecurityUtilities.logSecurityEvent(
            type: .dataModification,
            details: "Migration completed: \(migratedCount) items migrated"
        )
        
        return migratedCount
    }
    
    /// Checks if migration is needed
    /// - Returns: true if legacy data exists and hasn't been migrated
    func isMigrationNeeded() -> Bool {
        // Already migrated
        if UserDefaults.standard.bool(forKey: Self.migrationCompletedKey) {
            return false
        }
        
        // Check if legacy data exists
        return UserDefaults.standard.data(forKey: Self.legacyUserDefaultsKey) != nil
    }
    
    /// Gets the count of items that would be migrated
    /// - Returns: Number of legacy items, or 0 if none
    func getLegacyItemCount() -> Int {
        guard let data = UserDefaults.standard.data(forKey: Self.legacyUserDefaultsKey) else {
            return 0
        }
        
        do {
            let decoder = JSONDecoder()
            let items = try decoder.decode([LegacyItem].self, from: data)
            return items.count
        } catch {
            return 0
        }
    }
    
    // MARK: - Private Methods
    
    /// Ensures default categories exist in the database
    private func ensureCategoriesExist() {
        let descriptor = FetchDescriptor<CategoryEntity>()
        let count = (try? modelContext.fetchCount(descriptor)) ?? 0
        
        if count == 0 {
            CategoryEntity.seedDefaultCategories(in: modelContext)
        }
    }
    
    /// Migrates a single legacy item to SwiftData
    /// - Parameter legacyItem: Legacy item to migrate
    /// - Throws: Error if migration fails
    private func migrateItem(_ legacyItem: LegacyItem) throws {
        // Find matching category entity
        let category = findCategory(byName: legacyItem.category)
        
        // Convert to SwiftData item
        let newItem = legacyItem.toSwiftDataItem(category: category)
        
        // Validate the item before inserting
        try ValidationService.validateItem(
            name: newItem.name,
            quantity: newItem.quantity,
            price: newItem.price,
            category: category
        )
        
        // Insert into SwiftData
        modelContext.insert(newItem)
    }
    
    /// Finds a category entity by name
    /// - Parameter name: Category name to search for
    /// - Returns: Matching CategoryEntity or nil
    private func findCategory(byName name: String) -> CategoryEntity? {
        let descriptor = FetchDescriptor<CategoryEntity>(
            predicate: #Predicate { $0.name == name }
        )
        
        do {
            let results = try modelContext.fetch(descriptor)
            return results.first
        } catch {
            return nil
        }
    }
    
    /// Removes legacy data from UserDefaults
    private func cleanupLegacyData() {
        UserDefaults.standard.removeObject(forKey: Self.legacyUserDefaultsKey)
        
        SecurityUtilities.logSecurityEvent(
            type: .dataModification,
            details: "Legacy UserDefaults data cleaned up"
        )
    }
    
    /// Marks migration as complete to prevent re-running
    private func markMigrationComplete() {
        UserDefaults.standard.set(true, forKey: Self.migrationCompletedKey)
    }
    
    /// Resets migration status (for testing purposes only)
    /// WARNING: This will cause migration to run again on next launch
    func resetMigrationStatus() {
        #if DEBUG
        UserDefaults.standard.removeObject(forKey: Self.migrationCompletedKey)
        SecurityUtilities.logSecurityEvent(
            type: .dataModification,
            details: "Migration status reset (DEBUG only)"
        )
        #endif
    }
}

// MARK: - Migration Errors

/// Errors that can occur during data migration
enum MigrationError: LocalizedError {
    case decodingFailed(Error)
    case saveFailed(Error)
    case validationFailed(String)
    case categoryNotFound(String)
    
    var errorDescription: String? {
        switch self {
        case .decodingFailed(let error):
            return "Failed to read legacy data: \(error.localizedDescription)"
        case .saveFailed(let error):
            return "Failed to save migrated data: \(error.localizedDescription)"
        case .validationFailed(let reason):
            return "Data validation failed: \(reason)"
        case .categoryNotFound(let name):
            return "Category not found: \(name)"
        }
    }
    
    /// Recovery suggestion for the user
    var recoverySuggestion: String? {
        switch self {
        case .decodingFailed:
            return "Your data may be corrupted. Please contact support."
        case .saveFailed:
            return "Please ensure you have enough storage space and try again."
        case .validationFailed:
            return "Some items could not be migrated due to invalid data."
        case .categoryNotFound:
            return "The category will be set to 'Other'."
        }
    }
}
