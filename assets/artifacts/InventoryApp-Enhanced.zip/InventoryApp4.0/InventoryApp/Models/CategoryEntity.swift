//
//  CategoryEntity.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//
//  MILESTONE FOUR: Database Enhancement
//
//  This file demonstrates:
//  - SwiftData @Model for category persistence
//  - One-to-many relationship with Item entities
//  - Inverse relationship for data integrity
//  - Database seeding for default categories
//
//  Database Design Decisions:
//  - Separate CategoryEntity allows custom categories in future
//  - @Relationship with inverse ensures referential integrity
//  - deleteRule: .nullify prevents orphaned items when category deleted
//  - Storing iconName and colorHex allows UI customization
//

import Foundation
import SwiftData

/// Represents a category for organizing inventory items
///
/// This model class establishes a one-to-many relationship with Item.
/// Each category can have multiple items, but each item belongs to one category.
///
/// Database Relationship:
/// - CategoryEntity (1) ←→ (Many) Item
/// - Inverse relationship ensures bidirectional navigation
/// - Delete rule: nullify (items keep existing but category becomes nil)
///
/// SECURITY: Category names are sanitized before storage
@Model
final class CategoryEntity {
    
    // MARK: - Persisted Properties
    
    /// Unique identifier for the category
    /// Primary key in the categories table
    @Attribute(.unique) var id: UUID
    
    /// Display name of the category
    /// Example: "Electronics", "Furniture"
    var name: String
    
    /// SF Symbol icon name for UI display
    /// Example: "laptopcomputer", "chair.fill"
    var iconName: String
    
    /// Hex color code for UI theming
    /// Example: "#007AFF" for blue
    var colorHex: String
    
    /// Timestamp when category was created
    /// Part of audit trail
    var createdAt: Date
    
    // MARK: - Relationships
    
    /// Items belonging to this category
    /// @Relationship with inverse ensures data integrity
    ///
    /// deleteRule: .nullify means when this category is deleted,
    /// associated items will have their category set to nil
    /// (rather than being deleted or causing an error)
    @Relationship(deleteRule: .nullify, inverse: \Item.category)
    var items: [Item]?
    
    // MARK: - Computed Properties
    
    /// Number of items in this category
    var itemCount: Int {
        items?.count ?? 0
    }
    
    /// Total value of all items in this category
    var totalValue: Double {
        items?.reduce(0) { $0 + $1.totalValue } ?? 0
    }
    
    /// Formatted total value for display
    var formattedTotalValue: String {
        String(format: "$%.2f", totalValue)
    }
    
    // MARK: - Initialization
    
    /// Creates a new category
    ///
    /// - Parameters:
    ///   - name: Category display name
    ///   - iconName: SF Symbol icon name
    ///   - colorHex: Hex color code for theming
    init(name: String, iconName: String, colorHex: String = "#007AFF") {
        self.id = UUID()
        self.name = SecurityUtilities.sanitize(name)
        self.iconName = iconName
        self.colorHex = colorHex
        self.createdAt = Date()
    }
    
    // MARK: - Static Methods
    
    /// Seeds default categories into the database
    /// Called on first app launch when no categories exist
    ///
    /// - Parameter context: SwiftData ModelContext for insertion
    ///
    /// This ensures users have categories available immediately
    /// without needing to create them manually
    static func seedDefaultCategories(in context: ModelContext) {
        let defaultCategories: [(name: String, icon: String, color: String)] = [
            ("Electronics", "laptopcomputer", "#007AFF"),
            ("Furniture", "chair.fill", "#8B4513"),
            ("Supplies", "pencil.and.ruler.fill", "#FF9500"),
            ("Accessories", "headphones", "#AF52DE"),
            ("Clothing", "tshirt.fill", "#FF2D55"),
            ("Food", "fork.knife", "#34C759"),
            ("Tools", "wrench.and.screwdriver.fill", "#5856D6"),
            ("Other", "square.grid.2x2.fill", "#8E8E93")
        ]
        
        for (name, icon, color) in defaultCategories {
            let category = CategoryEntity(
                name: name,
                iconName: icon,
                colorHex: color
            )
            context.insert(category)
        }
    }
    
    /// Finds a category by name in the given context
    ///
    /// - Parameters:
    ///   - name: Category name to search for (case-insensitive)
    ///   - context: SwiftData ModelContext for querying
    /// - Returns: Matching CategoryEntity or nil if not found
    ///
    /// Used during migration to match old category strings to new entities
    static func find(byName name: String, in context: ModelContext) -> CategoryEntity? {
        let lowercaseName = name.lowercased()
        let descriptor = FetchDescriptor<CategoryEntity>(
            predicate: #Predicate { $0.name.localizedStandardContains(lowercaseName) }
        )
        
        do {
            let results = try context.fetch(descriptor)
            return results.first
        } catch {
            print("⚠️ Error finding category: \(error.localizedDescription)")
            return nil
        }
    }
}

// MARK: - Sample Data

extension CategoryEntity {
    /// Sample category for SwiftUI previews
    static var sample: CategoryEntity {
        CategoryEntity(name: "Electronics", iconName: "laptopcomputer", colorHex: "#007AFF")
    }
    
    /// Sample categories for testing
    static var sampleCategories: [CategoryEntity] {
        [
            CategoryEntity(name: "Electronics", iconName: "laptopcomputer", colorHex: "#007AFF"),
            CategoryEntity(name: "Furniture", iconName: "chair.fill", colorHex: "#8B4513"),
            CategoryEntity(name: "Supplies", iconName: "pencil.and.ruler.fill", colorHex: "#FF9500")
        ]
    }
}
