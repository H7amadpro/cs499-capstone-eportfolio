//
//  Category.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//
//  MILESTONE FOUR: Database Enhancement
//
//  This enum is kept for UI convenience and backward compatibility.
//  It provides a type-safe way to reference default categories
//  and is used for seeding the database with CategoryEntity records.
//
//  Note: CategoryEntity is the actual database model.
//  This enum is a helper for UI components and migration.
//

import Foundation

/// Enumeration of default inventory categories
///
/// This enum provides:
/// - Type-safe category references in code
/// - Default icon and color mappings
/// - Backward compatibility with legacy code
///
/// The actual database storage uses CategoryEntity @Model class,
/// which allows for custom categories beyond these defaults.
enum Category: String, CaseIterable, Identifiable {
    case electronics = "Electronics"
    case furniture = "Furniture"
    case supplies = "Supplies"
    case accessories = "Accessories"
    case clothing = "Clothing"
    case food = "Food"
    case tools = "Tools"
    case other = "Other"
    
    // MARK: - Identifiable
    
    var id: String { rawValue }
    
    // MARK: - Display Properties
    
    /// Human-readable display name
    var displayName: String { rawValue }
    
    /// SF Symbol icon name for this category
    var iconName: String {
        switch self {
        case .electronics: return "laptopcomputer"
        case .furniture: return "chair.fill"
        case .supplies: return "pencil.and.ruler.fill"
        case .accessories: return "headphones"
        case .clothing: return "tshirt.fill"
        case .food: return "fork.knife"
        case .tools: return "wrench.and.screwdriver.fill"
        case .other: return "square.grid.2x2.fill"
        }
    }
    
    /// Hex color code for this category
    var colorHex: String {
        switch self {
        case .electronics: return "#007AFF"
        case .furniture: return "#8B4513"
        case .supplies: return "#FF9500"
        case .accessories: return "#AF52DE"
        case .clothing: return "#FF2D55"
        case .food: return "#34C759"
        case .tools: return "#5856D6"
        case .other: return "#8E8E93"
        }
    }
    
    // MARK: - Factory Methods
    
    /// Creates a Category from a string name
    /// Returns .other if no match found
    ///
    /// - Parameter name: Category name string
    /// - Returns: Matching Category case or .other
    static func from(name: String) -> Category {
        Category(rawValue: name) ?? .other
    }
}
