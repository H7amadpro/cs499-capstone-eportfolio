//
//  Item.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//
//  MILESTONE FOUR: Database Enhancement
//
//  This file demonstrates:
//  - SwiftData @Model macro for persistence
//  - Entity relationships with CategoryEntity
//  - Audit trail with createdAt/updatedAt timestamps
//  - Data integrity through proper modeling
//
//  Database Design Decisions:
//  - Using UUID for primary key ensures uniqueness across devices
//  - @Attribute(.unique) prevents duplicate IDs
//  - @Relationship establishes foreign key to CategoryEntity
//  - Timestamps provide audit trail for security compliance
//

import Foundation
import SwiftData

/// Represents an inventory item stored in SwiftData
///
/// This model class replaces the previous Codable struct used with UserDefaults.
/// SwiftData provides:
/// - Automatic persistence to SQLite
/// - Type-safe queries with @Query
/// - Relationship management with @Relationship
/// - Change tracking for efficient saves
///
/// SECURITY: All properties are validated before saving via ValidationService
@Model
final class Item {
    
    // MARK: - Persisted Properties
    
    /// Unique identifier for the item
    /// Using @Attribute(.unique) ensures no duplicate IDs in database
    /// This is the primary key for the items table
    @Attribute(.unique) var id: UUID
    
    /// Name of the inventory item
    /// Validated: 1-100 characters, sanitized for security
    var name: String
    
    /// Current quantity in stock
    /// Validated: 0 to 999,999 (non-negative integer)
    var quantity: Int
    
    /// Unit price of the item
    /// Validated: 0 to 999,999.99 (non-negative decimal)
    var price: Double
    
    /// Timestamp when item was created
    /// Part of audit trail for security compliance
    var createdAt: Date
    
    /// Timestamp when item was last modified
    /// Updated automatically on every save
    /// Part of audit trail for security compliance
    var updatedAt: Date
    
    // MARK: - Relationships
    
    /// Category this item belongs to
    /// @Relationship establishes a many-to-one relationship with CategoryEntity
    /// Optional because an item might temporarily have no category (during migration)
    ///
    /// Database Design: This creates a foreign key constraint
    /// If category is deleted, item's category becomes nil (nullify rule)
    @Relationship var category: CategoryEntity?
    
    // MARK: - Computed Properties
    
    /// Formatted price string for display
    /// Example: "$19.99"
    var formattedPrice: String {
        String(format: "$%.2f", price)
    }
    
    /// Total value of this item (quantity × price)
    /// Used for inventory valuation calculations
    var totalValue: Double {
        Double(quantity) * price
    }
    
    /// Category name for display purposes
    /// Returns "Uncategorized" if no category assigned
    var categoryName: String {
        category?.name ?? "Uncategorized"
    }
    
    /// Category icon name for UI
    /// Returns default icon if no category assigned
    var categoryIconName: String {
        category?.iconName ?? "square.grid.2x2.fill"
    }
    
    /// Indicates if item is low on stock (quantity ≤ 5)
    /// Used for low stock alerts
    var isLowStock: Bool {
        quantity <= 5
    }
    
    // MARK: - Initialization
    
    /// Creates a new inventory item
    ///
    /// - Parameters:
    ///   - name: Item name (will be sanitized)
    ///   - quantity: Stock quantity
    ///   - price: Unit price
    ///   - category: Associated category entity (optional)
    ///
    /// - Note: Use ValidationService.validateItem() before creating
    init(
        name: String,
        quantity: Int,
        price: Double,
        category: CategoryEntity? = nil
    ) {
        self.id = UUID()
        self.name = SecurityUtilities.sanitize(name)
        self.quantity = quantity
        self.price = price
        self.category = category
        self.createdAt = Date()
        self.updatedAt = Date()
    }
    
    /// Creates an item with a specific ID (used for migration)
    ///
    /// - Parameters:
    ///   - id: Existing UUID to preserve
    ///   - name: Item name
    ///   - quantity: Stock quantity
    ///   - price: Unit price
    ///   - category: Associated category entity
    ///   - createdAt: Original creation date
    ///
    /// - Note: This initializer is primarily for migration from UserDefaults
    init(
        id: UUID,
        name: String,
        quantity: Int,
        price: Double,
        category: CategoryEntity?,
        createdAt: Date
    ) {
        self.id = id
        self.name = SecurityUtilities.sanitize(name)
        self.quantity = quantity
        self.price = price
        self.category = category
        self.createdAt = createdAt
        self.updatedAt = Date()
    }
    
    // MARK: - Methods
    
    /// Updates the item's properties and refreshes updatedAt timestamp
    ///
    /// - Parameters:
    ///   - name: New name (will be sanitized)
    ///   - quantity: New quantity
    ///   - price: New price
    ///   - category: New category
    ///
    /// - Note: Call ValidationService.validateItem() before updating
    func update(
        name: String,
        quantity: Int,
        price: Double,
        category: CategoryEntity?
    ) {
        self.name = SecurityUtilities.sanitize(name)
        self.quantity = quantity
        self.price = price
        self.category = category
        self.updatedAt = Date()  // Update audit timestamp
    }
}

// MARK: - Sample Data

extension Item {
    /// Sample items for SwiftUI previews and testing
    /// These are NOT persisted to the database
    static var sampleItems: [Item] {
        [
            Item(name: "MacBook Pro", quantity: 5, price: 1999.99),
            Item(name: "iPhone 15", quantity: 25, price: 999.99),
            Item(name: "AirPods Pro", quantity: 50, price: 249.99),
            Item(name: "iPad Air", quantity: 15, price: 599.99),
            Item(name: "Apple Watch", quantity: 30, price: 399.99)
        ]
    }
}

// MARK: - Legacy Support

/// Legacy Item structure for UserDefaults migration
/// This struct matches the old Codable format used before SwiftData
/// Used only by MigrationService to read old data
struct LegacyItem: Codable {
    let id: String
    var name: String
    var quantity: Int
    var price: Double
    var category: String
    let createdAt: Date
    
    /// Converts legacy item to new SwiftData Item
    /// - Parameter categoryEntity: The matching CategoryEntity from database
    /// - Returns: New Item instance ready for SwiftData
    func toSwiftDataItem(category categoryEntity: CategoryEntity?) -> Item {
        Item(
            id: UUID(uuidString: id) ?? UUID(),
            name: name,
            quantity: quantity,
            price: price,
            category: categoryEntity,
            createdAt: createdAt
        )
    }
}
