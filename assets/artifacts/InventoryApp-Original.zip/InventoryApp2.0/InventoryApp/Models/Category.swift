//
//  Category.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//
//  Enum defining predefined categories for inventory items
//  Provides type-safe category selection with associated SF Symbol icons
//

import Foundation

enum Category: String, CaseIterable, Identifiable {
    case electronics = "Electronics"
    case furniture = "Furniture"
    case supplies = "Supplies"
    case accessories = "Accessories"
    case clothing = "Clothing"
    case food = "Food"
    case tools = "Tools"
    case other = "Other"
    
    /// Unique identifier for Identifiable conformance
    var id: String { rawValue }
    
    /// Human-readable display name
    var displayName: String {
        rawValue
    }
    
    /// SF Symbol icon name for visual representation in the UI
    var iconName: String {
        switch self {
        case .electronics: return "laptopcomputer"
        case .furniture: return "chair.fill"
        case .supplies: return "pencil.and.ruler.fill"
        case .accessories: return "headphones"
        case .clothing: return "tshirt.fill"
        case .food: return "fork.knife"
        case .tools: return "wrench.and.screwdriver.fill"
        case .other: return "square.grid.2x2.fill"
        }
    }
}
