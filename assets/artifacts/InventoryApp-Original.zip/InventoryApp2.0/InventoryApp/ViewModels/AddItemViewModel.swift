//
//  AddItemViewModel.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//
//  ViewModel for the add/edit item form screen
//  Handles form state management, input validation, and save operations
//  Demonstrates proper separation of validation logic from the View
//

import Foundation
import Combine

/// ViewModel responsible for add/edit item form logic and validation
final class AddItemViewModel: ObservableObject {
    
    // MARK: - Published Properties (Form State)
    
    /// Item name input field
    @Published var name: String = ""
    
    /// Quantity input (stored as String for TextField binding)
    @Published var quantity: String = ""
    
    /// Price input (stored as String for TextField binding)
    @Published var price: String = ""
    
    /// Selected category
    @Published var category: String = ""
    
    /// Current validation error message (nil if valid)
    @Published var validationError: String?
    
    /// Indicates save operation in progress
    @Published private(set) var isSaving: Bool = false
    
    /// Set to true when item is saved successfully
    @Published private(set) var didSaveSuccessfully: Bool = false
    
    // MARK: - Computed Properties
    
    /// Returns true if editing an existing item, false if adding new
    var isEditing: Bool {
        editingItem != nil
    }
    
    /// Dynamic navigation title based on add/edit mode
    var navigationTitle: String {
        isEditing ? "Edit Item" : "Add Item"
    }
    
    /// Dynamic button title based on add/edit mode
    var saveButtonTitle: String {
        isEditing ? "Update Item" : "Add Item"
    }
    
    /// Converts quantity string to Int (nil if invalid)
    var quantityValue: Int? {
        Int(quantity)
    }
    
    /// Converts price string to Double (nil if invalid)
    var priceValue: Double? {
        Double(price)
    }
    
    // MARK: - Private Properties
    
    /// The item being edited (nil if adding new item)
    private var editingItem: Item?
    
    /// Repository for data persistence
    private let repository: ItemRepositoryProtocol
    
    // MARK: - Initialization
    
    /// Creates ViewModel for adding a new item
    /// - Parameter repository: Data repository for persistence
    init(repository: ItemRepositoryProtocol = ItemRepository()) {
        self.repository = repository
        self.editingItem = nil
    }
    
    /// Creates ViewModel for editing an existing item
    /// - Parameters:
    ///   - repository: Data repository for persistence
    ///   - item: The existing item to edit
    init(repository: ItemRepositoryProtocol = ItemRepository(), item: Item) {
        self.repository = repository
        self.editingItem = item
        
        // Pre-populate form fields with existing item data
        self.name = item.name
        self.quantity = String(item.quantity)
        self.price = String(item.price)
        self.category = item.category
    }
    
    // MARK: - Validation
    
    /// Validates all form fields according to business rules
    /// - Returns: true if all fields are valid, false otherwise
    func validate() -> Bool {
        validationError = nil
        
        // Rule 1: Name cannot be empty
        if name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            validationError = ValidationError.emptyName.errorDescription
            return false
        }
        
        // Rule 2: Name cannot exceed maximum length
        if name.count > Constants.Validation.maxNameLength {
            validationError = ValidationError.nameTooLong(maxLength: Constants.Validation.maxNameLength).errorDescription
            return false
        }
        
        // Rule 3: Quantity must be a valid integer
        guard let quantityInt = Int(quantity) else {
            validationError = ValidationError.invalidQuantity.errorDescription
            return false
        }
        
        // Rule 4: Quantity cannot be negative
        if quantityInt < Constants.Validation.minQuantity {
            validationError = ValidationError.negativeQuantity.errorDescription
            return false
        }
        
        // Rule 5: Price must be a valid number
        guard let priceDouble = Double(price) else {
            validationError = ValidationError.invalidPrice.errorDescription
            return false
        }
        
        // Rule 6: Price cannot be negative
        if priceDouble < Constants.Validation.minPrice {
            validationError = ValidationError.negativePrice.errorDescription
            return false
        }
        
        // Rule 7: Category must be selected
        if category.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            validationError = ValidationError.emptyCategory.errorDescription
            return false
        }
        
        return true
    }
    
    // MARK: - Save Operations
    
    /// Validates form and saves item to repository
    /// - Returns: true if save was successful, false if validation failed
    @discardableResult
    func save() -> Bool {
        // First validate all inputs
        guard validate() else {
            return false
        }
        
        isSaving = true
        
        // Clean up input values
        let trimmedName = name.trimmingCharacters(in: .whitespacesAndNewlines)
        let trimmedCategory = category.trimmingCharacters(in: .whitespacesAndNewlines)
        let quantityInt = Int(quantity) ?? 0
        let priceDouble = Double(price) ?? 0.0
        
        if let existingItem = editingItem {
            // Update existing item - preserve original ID and creation date
            let updatedItem = Item(
                id: existingItem.id,
                name: trimmedName,
                quantity: quantityInt,
                price: priceDouble,
                category: trimmedCategory,
                createdAt: existingItem.createdAt
            )
            repository.updateItem(updatedItem)
        } else {
            // Create new item with auto-generated ID
            let newItem = Item(
                name: trimmedName,
                quantity: quantityInt,
                price: priceDouble,
                category: trimmedCategory
            )
            repository.addItem(newItem)
        }
        
        isSaving = false
        didSaveSuccessfully = true
        return true
    }
    
    /// Clears the current validation error
    func clearError() {
        validationError = nil
    }
    
    /// Resets form to initial empty state
    func resetForm() {
        name = ""
        quantity = ""
        price = ""
        category = ""
        validationError = nil
        didSaveSuccessfully = false
    }
}
