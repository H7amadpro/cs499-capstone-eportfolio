//
//  InventoryViewModel.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//
//  ViewModel for the main inventory list screen
//  Implements MVVM pattern - separates business logic from the View layer
//  Uses Combine framework for reactive data binding with @Published properties
//

import Foundation
import Combine

/// ViewModel responsible for managing inventory list state and business logic
/// Demonstrates dependency injection through protocol-based repository
final class InventoryViewModel: ObservableObject {
    
    // MARK: - Published Properties
    // These properties automatically notify the View when changed
    
    /// All inventory items loaded from the repository
    @Published private(set) var items: [Item] = []
    
    /// Current search query entered by the user
    @Published var searchText: String = ""
    
    /// Indicates whether data is currently being loaded
    @Published private(set) var isLoading: Bool = false
    
    /// Error message to display to the user (nil if no error)
    @Published var errorMessage: String?
    
    // MARK: - Computed Properties
    
    /// Returns items filtered by the current search text
    /// Searches both item name and category for matches
    var filteredItems: [Item] {
        guard !searchText.isEmpty else {
            return items
        }
        
        let lowercaseQuery = searchText.lowercased()
        return items.filter { item in
            item.name.lowercased().contains(lowercaseQuery) ||
            item.category.lowercased().contains(lowercaseQuery)
        }
    }
    
    /// Total number of items in inventory
    var totalItemCount: Int {
        items.count
    }
    
    /// Calculates total value of all inventory items
    var totalInventoryValue: Double {
        items.reduce(0) { $0 + $1.totalValue }
    }
    
    /// Returns formatted string of total inventory value
    var formattedTotalValue: String {
        String(format: "$%.2f", totalInventoryValue)
    }
    
    // MARK: - Private Properties
    
    /// Repository for data access - injected through initializer
    private let repository: ItemRepositoryProtocol
    
    /// Set to store Combine subscriptions
    private var cancellables = Set<AnyCancellable>()
    
    // MARK: - Initialization
    
    /// Creates ViewModel with dependency injection
    /// - Parameter repository: Data repository (defaults to production ItemRepository)
    init(repository: ItemRepositoryProtocol = ItemRepository()) {
        self.repository = repository
        loadItems()
        setupSearchDebounce()
    }
    
    // MARK: - Private Methods
    
    /// Configures debounced search to prevent excessive filtering on each keystroke
    private func setupSearchDebounce() {
        $searchText
            .debounce(for: .seconds(Constants.UI.searchDebounceInterval), scheduler: RunLoop.main)
            .sink { [weak self] _ in
                self?.objectWillChange.send()
            }
            .store(in: &cancellables)
    }
    
    // MARK: - Public Methods
    
    /// Loads all items from the repository
    func loadItems() {
        isLoading = true
        errorMessage = nil
        
        // Simulates async operation - will be truly async when migrated to CoreData
        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }
            self.items = self.repository.getAllItems()
            self.isLoading = false
        }
    }
    
    /// Deletes a specific item from inventory
    /// - Parameter item: The item to delete
    func deleteItem(_ item: Item) {
        repository.deleteItem(id: item.id)
        loadItems()
    }
    
    /// Deletes items at specified index positions (used by SwiftUI onDelete modifier)
    /// - Parameter offsets: IndexSet of items to delete
    func deleteItem(at offsets: IndexSet) {
        for index in offsets {
            let item = filteredItems[index]
            repository.deleteItem(id: item.id)
        }
        loadItems()
    }
    
    /// Clears any displayed error message
    func clearError() {
        errorMessage = nil
    }
    
    /// Refreshes the item list from repository
    func refresh() {
        loadItems()
    }
}
