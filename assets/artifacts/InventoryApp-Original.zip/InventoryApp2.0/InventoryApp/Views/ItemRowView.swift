//
//  ItemRowView.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//
//  Reusable row component for displaying inventory items in a list
//  Demonstrates SwiftUI component composition and reusability
//

import SwiftUI

/// A reusable row view for displaying item information in the inventory list
struct ItemRowView: View {
    
    // MARK: - Properties
    
    /// The item to display in this row
    let item: Item
    
    // MARK: - Body
    
    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            // Category icon with colored background
            categoryIcon
            
            // Item details stack
            VStack(alignment: .leading, spacing: 4) {
                // Item name - primary text
                Text(item.name)
                    .font(.headline)
                    .foregroundColor(.primary)
                    .lineLimit(2)
                
                // Category badge
                Text(item.category)
                    .font(.caption)
                    .foregroundColor(.secondary)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 2)
                    .background(Color.secondary.opacity(0.1))
                    .cornerRadius(4)
                
                // Quantity and price row
                HStack {
                    Label("\(item.quantity)", systemImage: "number")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                    
                    Spacer()
                    
                    Text(item.formattedPrice)
                        .font(.subheadline)
                        .fontWeight(.medium)
                        .foregroundColor(.primary)
                }
                .padding(.top, 4)
            }
            
            Spacer()
        }
        .padding(.vertical, 8)
    }
    
    // MARK: - Subviews
    
    /// Icon representing the item's category with SF Symbol
    private var categoryIcon: some View {
        let category = Category(rawValue: item.category) ?? .other
        
        return Image(systemName: category.iconName)
            .font(.title2)
            .foregroundColor(.white)
            .frame(width: 44, height: 44)
            .background(Color.accentColor)
            .cornerRadius(10)
    }
}

// MARK: - Preview

struct ItemRowView_Previews: PreviewProvider {
    static var previews: some View {
        List {
            ItemRowView(item: Item.sampleItem)
            ItemRowView(item: Item(name: "Very Long Item Name That Should Wrap to Multiple Lines", quantity: 100, price: 49.99, category: "Supplies"))
        }
    }
}
