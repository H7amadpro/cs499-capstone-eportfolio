//
//  DataManager.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//
//  Low-level data persistence service using UserDefaults
//  This implementation will be replaced with CoreData in the database enhancement phase
//  The Repository layer abstracts this implementation detail from the rest of the app
//

import Foundation

/// Singleton class responsible for data persistence using UserDefaults
/// Handles JSON encoding/decoding of Item objects
final class DataManager {
    
    // MARK: - Singleton
    
    /// Shared instance for app-wide data access
    static let shared = DataManager()
    
    // MARK: - Properties
    
    /// Key used to store items in UserDefaults
    private let userDefaultsKey = Constants.Storage.userDefaultsKey
    
    /// In-memory cache of items
    private var items: [Item] = []
    
    /// JSON encoder for serialization
    private let encoder = JSONEncoder()
    
    /// JSON decoder for deserialization
    private let decoder = JSONDecoder()
    
    // MARK: - Initialization
    
    /// Private initializer enforces singleton pattern
    private init() {
        loadItems()
    }
    
    // MARK: - Private Methods
    
    /// Loads items from UserDefaults into memory
    private func loadItems() {
        guard let data = UserDefaults.standard.data(forKey: userDefaultsKey) else {
            items = []
            return
        }
        
        do {
            items = try decoder.decode([Item].self, from: data)
        } catch {
            print("Error decoding items: \(error)")
            items = []
        }
    }
    
    /// Persists current items array to UserDefaults
    private func saveItems() {
        do {
            let data = try encoder.encode(items)
            UserDefaults.standard.set(data, forKey: userDefaultsKey)
        } catch {
            print("Error encoding items: \(error)")
        }
    }
    
    // MARK: - Public Methods
    
    /// Returns all items sorted alphabetically by name
    /// Uses Swift's built-in sort (O(n log n)) - improved from original bubble sort
    func getAllItems() -> [Item] {
        return items.sorted { $0.name.lowercased() < $1.name.lowercased() }
    }
    
    /// Adds a new item to storage
    /// - Parameter item: The item to add
    func addItem(_ item: Item) {
        items.append(item)
        saveItems()
    }
    
    /// Updates an existing item in storage
    /// - Parameter item: The item with updated values (matched by ID)
    func updateItem(_ item: Item) {
        guard let index = items.firstIndex(where: { $0.id == item.id }) else {
            return
        }
        items[index] = item
        saveItems()
    }
    
    /// Deletes an item from storage by ID
    /// - Parameter id: The unique identifier of the item to delete
    func deleteItem(id: String) {
        items.removeAll { $0.id == id }
        saveItems()
    }
    
    /// Searches items by name using optimized filter
    /// - Parameter query: The search query string
    /// - Returns: Matching items sorted alphabetically
    func searchItems(query: String) -> [Item] {
        guard !query.isEmpty else {
            return getAllItems()
        }
        
        let lowercaseQuery = query.lowercased()
        return items
            .filter { $0.name.lowercased().contains(lowercaseQuery) }
            .sorted { $0.name.lowercased() < $1.name.lowercased() }
    }
    
    /// Retrieves a single item by ID
    /// - Parameter id: The unique identifier of the item
    /// - Returns: The item if found, nil otherwise
    func getItem(byId id: String) -> Item? {
        items.first { $0.id == id }
    }
    
    /// Clears all items from storage (useful for testing)
    func clearAllItems() {
        items = []
        saveItems()
    }
}
