//
//  ItemRepositoryProtocol.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//
//  Protocol defining the contract for item data access operations
//  Enables dependency injection and testability by allowing mock implementations
//  ViewModels depend on this protocol, not concrete implementations (Dependency Inversion)
//

import Foundation

/// Protocol defining the interface for item repository operations
/// Abstracts the data access layer from ViewModels for loose coupling
protocol ItemRepositoryProtocol {
    
    /// Retrieves all items from storage, sorted alphabetically by name
    /// - Returns: Array of all inventory items
    func getAllItems() -> [Item]
    
    /// Adds a new item to storage
    /// - Parameter item: The item to add
    func addItem(_ item: Item)
    
    /// Updates an existing item in storage
    /// - Parameter item: The item with updated values (matched by ID)
    func updateItem(_ item: Item)
    
    /// Deletes an item from storage by its unique identifier
    /// - Parameter id: The ID of the item to delete
    func deleteItem(id: String)
    
    /// Searches items by name, returning matches sorted alphabetically
    /// - Parameter query: The search query string
    /// - Returns: Array of items matching the search query
    func searchItems(query: String) -> [Item]
    
    /// Retrieves a single item by its unique identifier
    /// - Parameter id: The ID of the item to retrieve
    /// - Returns: The item if found, nil otherwise
    func getItem(byId id: String) -> Item?
}
