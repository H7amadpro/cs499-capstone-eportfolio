//
//  ItemRepository.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//
//  Concrete implementation of ItemRepositoryProtocol
//  Wraps DataManager and provides a clean interface for data operations
//  Can be easily swapped for CoreData implementation in future enhancement
//

import Foundation

/// Production implementation of ItemRepositoryProtocol
/// Uses DataManager singleton for actual data persistence
final class ItemRepository: ItemRepositoryProtocol {
    
    // MARK: - Properties
    
    /// Reference to the data manager for persistence operations
    private let dataManager: DataManager
    
    // MARK: - Initialization
    
    /// Creates a repository using the shared DataManager instance
    init() {
        self.dataManager = DataManager.shared
    }
    
    /// Creates a repository with a custom DataManager (useful for testing)
    init(dataManager: DataManager) {
        self.dataManager = dataManager
    }
    
    // MARK: - ItemRepositoryProtocol Implementation
    
    func getAllItems() -> [Item] {
        dataManager.getAllItems()
    }
    
    func addItem(_ item: Item) {
        dataManager.addItem(item)
    }
    
    func updateItem(_ item: Item) {
        dataManager.updateItem(item)
    }
    
    func deleteItem(id: String) {
        dataManager.deleteItem(id: id)
    }
    
    func searchItems(query: String) -> [Item] {
        dataManager.searchItems(query: query)
    }
    
    func getItem(byId id: String) -> Item? {
        dataManager.getItem(byId: id)
    }
}

// MARK: - Mock Repository for Testing

/// Mock implementation of ItemRepositoryProtocol for unit testing and SwiftUI previews
/// Uses in-memory storage instead of UserDefaults
final class MockItemRepository: ItemRepositoryProtocol {
    
    /// In-memory storage for mock items
    private var items: [Item] = Item.sampleItems
    
    func getAllItems() -> [Item] {
        items.sorted { $0.name.lowercased() < $1.name.lowercased() }
    }
    
    func addItem(_ item: Item) {
        items.append(item)
    }
    
    func updateItem(_ item: Item) {
        guard let index = items.firstIndex(where: { $0.id == item.id }) else { return }
        items[index] = item
    }
    
    func deleteItem(id: String) {
        items.removeAll { $0.id == id }
    }
    
    func searchItems(query: String) -> [Item] {
        guard !query.isEmpty else { return getAllItems() }
        let lowercaseQuery = query.lowercased()
        return items
            .filter { $0.name.lowercased().contains(lowercaseQuery) }
            .sorted { $0.name.lowercased() < $1.name.lowercased() }
    }
    
    func getItem(byId id: String) -> Item? {
        items.first { $0.id == id }
    }
    
    /// Resets repository to initial sample data (useful between tests)
    func reset() {
        items = Item.sampleItems
    }
}
