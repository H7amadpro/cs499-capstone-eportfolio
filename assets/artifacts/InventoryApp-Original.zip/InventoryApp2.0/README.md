# Inventory App - Enhanced MVVM + SwiftUI Version

**Author:** Hamad Alghaithi  
**Course:** CS 499 - Computer Science Capstone  
**Institution:** Southern New Hampshire University

A modern iOS inventory management app demonstrating software engineering best practices including MVVM architecture, SwiftUI, dependency injection, and comprehensive unit testing. This is the enhanced version refactored from the original basic MVC/UIKit implementation.

## Overview

This project demonstrates my proficiency in modern iOS development by refactoring a basic inventory app to follow industry best practices and design patterns. The enhancement focuses on software design and engineering improvements.

## Features

- Add, edit, and delete inventory items
- Search items by name or category
- Category-based organization with SF Symbol icons
- Pull-to-refresh functionality
- Swipe-to-delete gesture
- Real-time inventory value calculation
- Form validation with user-friendly error messages
- Unit tests for ViewModels

## Architecture

### MVVM Pattern

The app follows the Model-View-ViewModel (MVVM) architectural pattern:

- **Models**: Data structures representing the domain (`Item`, `Category`)
- **Views**: SwiftUI views for UI rendering (`InventoryView`, `AddItemView`, `ItemRowView`)
- **ViewModels**: Business logic and state management (`InventoryViewModel`, `AddItemViewModel`)

### Design Patterns Implemented

| Pattern | Implementation | Purpose |
|---------|---------------|---------|
| **MVVM** | ViewModels with `@Published` properties | Separation of UI and business logic |
| **Repository** | `ItemRepositoryProtocol` + `ItemRepository` | Abstracts data access layer |
| **Dependency Injection** | Protocol-based constructor injection | Enables testability and loose coupling |
| **Observer** | Combine's `@Published` and `@StateObject` | Reactive data binding |
| **Singleton** | `DataManager.shared` | Single point of data access |

## Project Structure

```
InventoryApp/
├── App/
│   └── InventoryApp.swift           # SwiftUI App entry point
├── Models/
│   ├── Item.swift                   # Item data model (Identifiable, Codable)
│   └── Category.swift               # Category enum with icons
├── ViewModels/
│   ├── InventoryViewModel.swift     # Main list state management
│   └── AddItemViewModel.swift       # Form state and validation
├── Views/
│   ├── InventoryView.swift          # Main list screen
│   ├── AddItemView.swift            # Add/Edit form screen
│   └── ItemRowView.swift            # Reusable list row component
├── Repositories/
│   ├── ItemRepositoryProtocol.swift # Repository interface
│   └── ItemRepository.swift         # Repository implementation + Mock
├── Services/
│   └── DataManager.swift            # UserDefaults persistence
└── Utilities/
    ├── ValidationError.swift        # Custom error types
    └── Constants.swift              # App-wide constants
```

## Technical Specifications

- **Language**: Swift 5.9+
- **Framework**: SwiftUI
- **Minimum iOS**: 16.0
- **Architecture**: MVVM
- **Storage**: UserDefaults (ready for CoreData migration)
- **Testing**: XCTest with mock repository

## Key Improvements Over Original

### 1. Architecture (MVC → MVVM)

**Before:**
- All logic in ViewControllers
- Tightly coupled components
- Difficult to test

**After:**
- Clear separation of concerns
- ViewModels handle business logic
- Views are purely declarative
- Easy to unit test

### 2. UI Framework (UIKit → SwiftUI)

**Before:**
- Imperative UI code
- Manual layout constraints
- Delegate patterns

**After:**
- Declarative UI
- Automatic layout
- Data binding with `@Published`
- Built-in navigation and sheets

### 3. Data Access (Direct → Repository Pattern)

**Before:**
- ViewControllers directly called DataManager
- No abstraction layer
- Impossible to mock for testing

**After:**
- Repository protocol defines interface
- ViewModels depend on protocol, not implementation
- MockItemRepository for testing and previews

### 4. Validation

**Before:**
- Basic empty field checks
- Generic error messages

**After:**
- Comprehensive validation rules
- Specific error messages for each case
- Name length limits (200 chars)
- Numeric validation for quantity/price
- Non-negative value enforcement

### 5. Error Handling

**Before:**
- Minimal error handling
- Silent failures

**After:**
- Custom error enums (`ValidationError`, `DataError`)
- User-friendly error messages
- Proper error propagation

## Setup Instructions

1. Download and unzip the project
2. Open `InventoryApp.xcodeproj` in Xcode 15+
3. Select a simulator (iPhone 15 recommended)
4. Build and Run (⌘R)

## Running Tests

1. Open the project in Xcode
2. Press ⌘U to run all tests
3. View results in the Test Navigator

## Code Examples

### ViewModel with Dependency Injection

```swift
class InventoryViewModel: ObservableObject {
    @Published private(set) var items: [Item] = []
    private let repository: ItemRepositoryProtocol
    
    init(repository: ItemRepositoryProtocol = ItemRepository()) {
        self.repository = repository
        loadItems()
    }
}
```

### SwiftUI View with ViewModel

```swift
struct InventoryView: View {
    @StateObject private var viewModel = InventoryViewModel()
    
    var body: some View {
        NavigationStack {
            List {
                ForEach(viewModel.filteredItems) { item in
                    ItemRowView(item: item)
                }
                .onDelete(perform: viewModel.deleteItem)
            }
            .searchable(text: $viewModel.searchText)
        }
    }
}
```

### Unit Test with Mock Repository

```swift
func testDeleteItem_ShouldRemoveItemFromList() {
    // Given
    let mockRepository = MockItemRepository()
    let sut = InventoryViewModel(repository: mockRepository)
    let itemToDelete = sut.items.first!
    
    // When
    sut.deleteItem(itemToDelete)
    
    // Then
    XCTAssertFalse(sut.items.contains(where: { $0.id == itemToDelete.id }))
}
```

## Future Enhancements

This enhanced version is ready for additional improvements in other capstone categories:

1. **Database Enhancement**: Replace UserDefaults with CoreData or SQLite
2. **Algorithm Optimization**: Implement binary search and optimized sorting
3. **Cloud Sync**: Add iCloud synchronization
4. **Authentication**: Implement user accounts and security

## Design Patterns Demonstrated

This project demonstrates proficiency in:

- **SOLID Principles**: Single responsibility, dependency inversion
- **Clean Architecture**: Layered architecture with clear boundaries
- **Reactive Programming**: Combine framework integration
- **Protocol-Oriented Programming**: Protocols for abstraction
- **Test-Driven Development**: Unit tests with mocks

## License

This is a capstone project for CS 499 at Southern New Hampshire University, demonstrating software engineering skills in iOS development.

---

**Hamad Alghaithi**  
CS 499 - Computer Science Capstone  
Southern New Hampshire University
