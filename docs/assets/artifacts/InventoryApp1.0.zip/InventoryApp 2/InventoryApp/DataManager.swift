//
//  DataManager.swift
//  InventoryApp
//  - Uses UserDefaults
//  - Linear search O(n)
//  - Bubble sort O(n²)
//

import Foundation

class DataManager {
    static let shared = DataManager()
    private let userDefaultsKey = "inventory_items"
    
    // Simple array to store items (inefficient)
    private var items: [Item] = []
    
    private init() {
        loadItems()
    }
    
    // MARK: - Load/Save (inefficient - loads/saves everything)
    
    func loadItems() {
        if let data = UserDefaults.standard.data(forKey: userDefaultsKey) {
            let decoder = JSONDecoder()
            items = (try? decoder.decode([Item].self, from: data)) ?? []
        }
    }
    
    func saveItems() {
        let encoder = JSONEncoder()
        if let data = try? encoder.encode(items) {
            UserDefaults.standard.set(data, forKey: userDefaultsKey)
        }
    }
    
    // MARK: - CRUD Operations
    
    func getAllItems() -> [Item] {
        // Return sorted items using bubble sort (inefficient)
        return bubbleSort(items: items)
    }
    
    func addItem(_ item: Item) {
        items.append(item)
        saveItems()
    }
    
    func updateItem(id: String, name: String, quantity: Int, price: Double, category: String) {
        // Linear search - intentionally inefficient O(n)
        for i in 0..<items.count {
            if items[i].id == id {
                items[i].name = name
                items[i].quantity = quantity
                items[i].price = price
                items[i].category = category
                break
            }
        }
        saveItems()
    }
    
    func deleteItem(id: String) {
        // Linear search - intentionally inefficient O(n)
        var newItems: [Item] = []
        for item in items {
            if item.id != id {
                newItems.append(item)
            }
        }
        items = newItems
        saveItems()
    }
    
    // MARK: - Search (Linear Search - O(n))
    
    func searchItems(query: String) -> [Item] {
        if query.isEmpty {
            return getAllItems()
        }
        
        // Linear search - intentionally inefficient
        var results: [Item] = []
        let lowercaseQuery = query.lowercased()
        
        for item in items {
            if item.name.lowercased().contains(lowercaseQuery) {
                results.append(item)
            }
        }
        
        return results
    }
    
    // MARK: - Bubble Sort (O(n²) - intentionally inefficient)
    
    func bubbleSort(items: [Item]) -> [Item] {
        var arr = items
        let n = arr.count
        
        // Bubble sort implementation
        for i in 0..<n {
            for j in 0..<(n - i - 1) {
                if arr[j].name.lowercased() > arr[j + 1].name.lowercased() {
                    // Swap
                    let temp = arr[j]
                    arr[j] = arr[j + 1]
                    arr[j + 1] = temp
                }
            }
        }
        
        return arr
    }
    
    func getItem(byId id: String) -> Item? {
        // Linear search - intentionally inefficient
        for item in items {
            if item.id == id {
                return item
            }
        }
        return nil
    }
}
