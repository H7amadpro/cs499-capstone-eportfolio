//
//  AddItemViewController.swift
//  InventoryApp
//

import UIKit

class AddItemViewController: UIViewController {
    
    // UI Components
    private var nameTextField: UITextField!
    private var quantityTextField: UITextField!
    private var priceTextField: UITextField!
    private var categoryTextField: UITextField!
    private var saveButton: UIButton!
    private var scrollView: UIScrollView!
    private var contentView: UIView!
    
    // Data
    var itemToEdit: Item?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        title = itemToEdit == nil ? "Add Item" : "Edit Item"
        view.backgroundColor = .systemBackground
        
        setupUI()
        
        if let item = itemToEdit {
            populateFields(with: item)
        }
    }
    
    // MARK: - Setup UI
    
    func setupUI() {
        // Scroll view for keyboard handling
        scrollView = UIScrollView()
        scrollView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(scrollView)
        
        contentView = UIView()
        contentView.translatesAutoresizingMaskIntoConstraints = false
        scrollView.addSubview(contentView)
        
        // Name field
        let nameLabel = createLabel(text: "Item Name *")
        nameTextField = createTextField(placeholder: "Enter item name")
        
        // Quantity field
        let quantityLabel = createLabel(text: "Quantity *")
        quantityTextField = createTextField(placeholder: "Enter quantity")
        quantityTextField.keyboardType = .numberPad
        
        // Price field
        let priceLabel = createLabel(text: "Price *")
        priceTextField = createTextField(placeholder: "Enter price")
        priceTextField.keyboardType = .decimalPad
        
        // Category field
        let categoryLabel = createLabel(text: "Category")
        categoryTextField = createTextField(placeholder: "Enter category (optional)")
        
        // Save button
        saveButton = UIButton(type: .system)
        saveButton.setTitle("Save", for: .normal)
        saveButton.backgroundColor = .systemBlue
        saveButton.setTitleColor(.white, for: .normal)
        saveButton.layer.cornerRadius = 8
        saveButton.translatesAutoresizingMaskIntoConstraints = false
        saveButton.addTarget(self, action: #selector(saveButtonTapped), for: .touchUpInside)
        
        // Add to content view
        contentView.addSubview(nameLabel)
        contentView.addSubview(nameTextField)
        contentView.addSubview(quantityLabel)
        contentView.addSubview(quantityTextField)
        contentView.addSubview(priceLabel)
        contentView.addSubview(priceTextField)
        contentView.addSubview(categoryLabel)
        contentView.addSubview(categoryTextField)
        contentView.addSubview(saveButton)
        
        // Layout constraints
        NSLayoutConstraint.activate([
            scrollView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            scrollView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            scrollView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            scrollView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            
            contentView.topAnchor.constraint(equalTo: scrollView.topAnchor),
            contentView.leadingAnchor.constraint(equalTo: scrollView.leadingAnchor),
            contentView.trailingAnchor.constraint(equalTo: scrollView.trailingAnchor),
            contentView.bottomAnchor.constraint(equalTo: scrollView.bottomAnchor),
            contentView.widthAnchor.constraint(equalTo: scrollView.widthAnchor),
            
            nameLabel.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 20),
            nameLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 20),
            nameLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -20),
            
            nameTextField.topAnchor.constraint(equalTo: nameLabel.bottomAnchor, constant: 8),
            nameTextField.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 20),
            nameTextField.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -20),
            nameTextField.heightAnchor.constraint(equalToConstant: 44),
            
            quantityLabel.topAnchor.constraint(equalTo: nameTextField.bottomAnchor, constant: 20),
            quantityLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 20),
            quantityLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -20),
            
            quantityTextField.topAnchor.constraint(equalTo: quantityLabel.bottomAnchor, constant: 8),
            quantityTextField.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 20),
            quantityTextField.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -20),
            quantityTextField.heightAnchor.constraint(equalToConstant: 44),
            
            priceLabel.topAnchor.constraint(equalTo: quantityTextField.bottomAnchor, constant: 20),
            priceLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 20),
            priceLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -20),
            
            priceTextField.topAnchor.constraint(equalTo: priceLabel.bottomAnchor, constant: 8),
            priceTextField.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 20),
            priceTextField.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -20),
            priceTextField.heightAnchor.constraint(equalToConstant: 44),
            
            categoryLabel.topAnchor.constraint(equalTo: priceTextField.bottomAnchor, constant: 20),
            categoryLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 20),
            categoryLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -20),
            
            categoryTextField.topAnchor.constraint(equalTo: categoryLabel.bottomAnchor, constant: 8),
            categoryTextField.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 20),
            categoryTextField.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -20),
            categoryTextField.heightAnchor.constraint(equalToConstant: 44),
            
            saveButton.topAnchor.constraint(equalTo: categoryTextField.bottomAnchor, constant: 30),
            saveButton.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 20),
            saveButton.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -20),
            saveButton.heightAnchor.constraint(equalToConstant: 50),
            saveButton.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -20)
        ])
    }
    
    // MARK: - Helper Methods
    
    func createLabel(text: String) -> UILabel {
        let label = UILabel()
        label.text = text
        label.font = .systemFont(ofSize: 14, weight: .medium)
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }
    
    func createTextField(placeholder: String) -> UITextField {
        let textField = UITextField()
        textField.placeholder = placeholder
        textField.borderStyle = .roundedRect
        textField.translatesAutoresizingMaskIntoConstraints = false
        return textField
    }
    
    func populateFields(with item: Item) {
        nameTextField.text = item.name
        quantityTextField.text = "\(item.quantity)"
        priceTextField.text = "\(item.price)"
        categoryTextField.text = item.category
    }
    
    // MARK: - Actions
    
    @objc func saveButtonTapped() {
       
        guard let name = nameTextField.text, !name.isEmpty else {
            showAlert(message: "Please enter item name")
            return
        }
        
        guard let quantityText = quantityTextField.text, !quantityText.isEmpty,
              let quantity = Int(quantityText) else {
            showAlert(message: "Please enter valid quantity")
            return
        }
        
        guard let priceText = priceTextField.text, !priceText.isEmpty,
              let price = Double(priceText) else {
            showAlert(message: "Please enter valid price")
            return
        }
        
        let category = categoryTextField.text ?? ""
        
        if let item = itemToEdit {
            // Update existing item
            DataManager.shared.updateItem(id: item.id, name: name, quantity: quantity, price: price, category: category)
        } else {
            // Add new item
            let newItem = Item(name: name, quantity: quantity, price: price, category: category)
            DataManager.shared.addItem(newItem)
        }
        
        navigationController?.popViewController(animated: true)
    }
    
    func showAlert(message: String) {
        let alert = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }
}
