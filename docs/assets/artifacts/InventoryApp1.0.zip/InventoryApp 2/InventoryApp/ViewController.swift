//
//  ViewController.swift
//  InventoryApp
//
//  Main inventory list screen
//
//  - All logic in ViewController
//  - Direct DataManager calls from UI
//  - Basic UI
//  - Minimal separation of concerns
//

import UIKit

class ViewController: UIViewController {
    
    // UI Components
    private var tableView: UITableView!
    private var searchBar: UISearchBar!
    private var addButton: UIBarButtonItem!
    
    // Data
    private var items: [Item] = []
    private var isSearching = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        title = "Inventory"
        view.backgroundColor = .systemBackground
        
        setupUI()
        loadItems()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        loadItems()
    }
    
    // MARK: - Setup UI
    
    func setupUI() {
        // Search bar
        searchBar = UISearchBar()
        searchBar.delegate = self
        searchBar.placeholder = "Search items..."
        searchBar.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(searchBar)
        
        // Table view
        tableView = UITableView()
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "ItemCell")
        tableView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(tableView)
        
        // Add button
        addButton = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(addButtonTapped))
        navigationItem.rightBarButtonItem = addButton
        
        // Layout constraints
        NSLayoutConstraint.activate([
            searchBar.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            searchBar.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            searchBar.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            
            tableView.topAnchor.constraint(equalTo: searchBar.bottomAnchor),
            tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            tableView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
    }
    
    // MARK: - Data Loading
    
    func loadItems() {
        // Direct call to DataManager
        items = DataManager.shared.getAllItems()
        tableView.reloadData()
    }
    
    // MARK: - Actions
    
    @objc func addButtonTapped() {
        let addVC = AddItemViewController()
        navigationController?.pushViewController(addVC, animated: true)
    }
    
    func editItem(_ item: Item) {
        let addVC = AddItemViewController()
        addVC.itemToEdit = item
        navigationController?.pushViewController(addVC, animated: true)
    }
    
    func deleteItem(_ item: Item) {
        let alert = UIAlertController(title: "Delete Item", message: "Delete \(item.name)?", preferredStyle: .alert)
        
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        alert.addAction(UIAlertAction(title: "Delete", style: .destructive) { _ in
            DataManager.shared.deleteItem(id: item.id)
            self.loadItems()
        })
        
        present(alert, animated: true)
    }
}

// MARK: - UITableViewDataSource

extension ViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return items.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ItemCell", for: indexPath)
        let item = items[indexPath.row]
        
        // Basic cell configuration
        var content = cell.defaultContentConfiguration()
        content.text = item.name
        content.secondaryText = "Qty: \(item.quantity) | $\(String(format: "%.2f", item.price)) | \(item.category)"
        cell.contentConfiguration = content
        
        return cell
    }
}

// MARK: - UITableViewDelegate

extension ViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        let item = items[indexPath.row]
        editItem(item)
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            let item = items[indexPath.row]
            deleteItem(item)
        }
    }
}

// MARK: - UISearchBarDelegate

extension ViewController: UISearchBarDelegate {
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        // Search on every keystroke
        if searchText.isEmpty {
            isSearching = false
            loadItems()
        } else {
            isSearching = true
            // Linear search
            items = DataManager.shared.searchItems(query: searchText)
            tableView.reloadData()
        }
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searchBar.text = ""
        searchBar.resignFirstResponder()
        isSearching = false
        loadItems()
    }
}
