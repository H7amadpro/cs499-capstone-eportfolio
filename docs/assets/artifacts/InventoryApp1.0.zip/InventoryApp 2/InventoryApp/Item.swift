//
//  Item.swift
//  InventoryApp
//

import Foundation

struct Item: Codable {
    var id: String
    var name: String
    var quantity: Int
    var price: Double
    var category: String
    var createdAt: Date
    
    
    init(name: String, quantity: Int, price: Double, category: String) {
        self.id = UUID().uuidString
        self.name = name
        self.quantity = quantity
        self.price = price
        self.category = category
        self.createdAt = Date()
    }
}
