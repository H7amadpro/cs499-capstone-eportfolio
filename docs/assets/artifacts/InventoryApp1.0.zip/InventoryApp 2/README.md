# Basic Inventory Manager - iOS Capstone Project

A native Swift/UIKit inventory management app with intentional limitations in software design, algorithms, and database implementation for a computer science capstone project.

## Overview

This app provides basic inventory management functionality with deliberately inefficient implementations that can be improved as part of a capstone project. The app is fully functional but has clear areas for enhancement.

## Features

- ✅ Add inventory items (name, quantity, price, category)
- ✅ View list of all items
- ✅ Edit existing items
- ✅ Delete items (swipe to delete)
- ✅ Simple search functionality
- ✅ Basic sorting

## Intentional Limitations

### 1. Software Design (Architecture)

**Current Implementation:**
- **Basic MVC**: All business logic in ViewControllers
- **No MVVM**: No view models or proper separation
- **Direct Data Access**: ViewControllers call DataManager directly
- **No Dependency Injection**: Tight coupling throughout
- **Minimal Error Handling**: Basic alerts only
- **No Unit Tests**: No testing infrastructure
- **UIKit + Programmatic UI**: No SwiftUI, no Storyboards

**Improvement Opportunities:**
- Implement MVVM or VIPER architecture
- Add proper separation of concerns
- Create repository pattern for data access
- Implement dependency injection
- Add comprehensive error handling
- Write unit and UI tests
- Migrate to SwiftUI

### 2. Algorithms (Performance)

**Current Implementation:**
- **Linear Search (O(n))**: `searchItems()` iterates through all items
- **Bubble Sort (O(n²))**: `bubbleSort()` uses inefficient bubble sort
- **No Optimization**: Searches on every keystroke without debouncing
- **Simple Array**: Basic array-based data structure
- **No Indexing**: No search optimization

**Files to Review:**
- `DataManager.swift` - Lines 62-75 (Linear Search)
- `DataManager.swift` - Lines 79-98 (Bubble Sort)

**Improvement Opportunities:**
- Implement binary search with sorted data
- Use efficient sorting (QuickSort, MergeSort, or built-in sort)
- Add search indexing or trie data structure
- Implement debouncing for search
- Use hash maps/dictionaries for O(1) lookups
- Add pagination for large datasets

### 3. Database Implementation

**Current Implementation:**
- **UserDefaults Storage**: Simple key-value storage (not a proper database)
- **No Data Validation**: No constraints or validation
- **No Relationships**: Flat data structure only
- **Load All Data**: Entire dataset loaded for every operation
- **No Security**: No authentication or encryption
- **No Cloud Sync**: Local storage only
- **No Backup**: No data backup mechanism

**Files to Review:**
- `DataManager.swift` - All methods load/save entire dataset

**Improvement Opportunities:**
- Migrate to CoreData or Realm
- Implement proper database schema with relationships
- Add data validation and constraints
- Implement proper indexing
- Add user authentication (Keychain)
- Implement iCloud sync
- Add data backup and restore
- Implement offline-first architecture with sync

## Technical Specifications

- **Language**: Swift 5
- **Framework**: UIKit (programmatic UI)
- **Minimum iOS**: 15.0
- **Architecture**: Basic MVC
- **Storage**: UserDefaults
- **UI**: Programmatic Auto Layout

## Project Structure

```
InventoryApp/
├── InventoryApp.xcodeproj/
│   └── project.pbxproj
└── InventoryApp/
    ├── AppDelegate.swift           # App entry point
    ├── ViewController.swift         # Main inventory list screen
    ├── AddItemViewController.swift  # Add/Edit item screen
    ├── Item.swift                   # Data model
    ├── DataManager.swift            # Storage manager (UserDefaults)
    └── Info.plist                   # App configuration
```

## Setup Instructions

### Option 1: Open in Xcode (Recommended)

1. Download the `InventoryApp` folder
2. Double-click `InventoryApp.xcodeproj` to open in Xcode
3. Select a simulator or your device
4. Click Run (⌘R)

### Option 2: Manual Setup

1. Open Xcode
2. File → Open → Select `InventoryApp.xcodeproj`
3. Wait for indexing to complete
4. Select target device/simulator
5. Build and Run

## How to Use

1. **Add Item**: Tap the "+" button in the top-right
2. **Edit Item**: Tap any item in the list
3. **Delete Item**: Swipe left on an item
4. **Search**: Type in the search bar at the top

## Key Files for Capstone Improvements

### DataManager.swift
Contains all intentionally inefficient algorithms:
- `searchItems()` - Linear search implementation
- `bubbleSort()` - Bubble sort implementation
- All CRUD operations load/save entire dataset

### ViewController.swift
Main screen with all UI logic:
- Direct DataManager calls (no separation)
- Search on every keystroke (no debouncing)
- All business logic in ViewController

### AddItemViewController.swift
Add/Edit screen:
- Minimal validation
- Direct DataManager calls
- Basic error handling

## Measuring Improvements

### Performance Metrics
- **Search Time**: Use `CFAbsoluteTimeGetCurrent()` to measure search operations
- **Sort Time**: Measure sorting performance with large datasets
- **Memory Usage**: Use Instruments to track memory consumption
- **App Size**: Monitor binary size

### Code Quality Metrics
- **Test Coverage**: Aim for >80% code coverage
- **Cyclomatic Complexity**: Use SwiftLint to measure
- **Code Duplication**: Identify and eliminate duplicates
- **Maintainability**: Improve separation of concerns

### Suggested Improvements

#### Phase 1: Architecture Refactoring
1. Implement MVVM pattern
2. Create ViewModels for each screen
3. Add Coordinator pattern for navigation
4. Implement dependency injection
5. Write unit tests for ViewModels

#### Phase 2: Algorithm Optimization
1. Replace linear search with binary search
2. Implement efficient sorting (use Swift's built-in sort)
3. Add search debouncing (0.3s delay)
4. Implement search indexing
5. Add performance benchmarks

#### Phase 3: Database Migration
1. Migrate from UserDefaults to CoreData
2. Create proper entity relationships
3. Add data validation
4. Implement NSFetchedResultsController
5. Add database migrations

#### Phase 4: Advanced Features
1. Add user authentication (Keychain)
2. Implement iCloud sync
3. Add offline support
4. Implement data backup/restore
5. Add analytics and crash reporting

## Testing the Limitations

### Test Linear Search Performance
```swift
let startTime = CFAbsoluteTimeGetCurrent()
let results = DataManager.shared.searchItems(query: "test")
let endTime = CFAbsoluteTimeGetCurrent()
print("Search took \(endTime - startTime) seconds")
```

### Test Bubble Sort Performance
```swift
let startTime = CFAbsoluteTimeGetCurrent()
let sorted = DataManager.shared.bubbleSort(items: items)
let endTime = CFAbsoluteTimeGetCurrent()
print("Sort took \(endTime - startTime) seconds")
```

### Generate Test Data
Add this method to DataManager for testing:
```swift
func generateTestData(count: Int) {
    for i in 0..<count {
        let item = Item(
            name: "Item \(i)",
            quantity: Int.random(in: 1...100),
            price: Double.random(in: 1.0...1000.0),
            category: "Category \(i % 5)"
        )
        addItem(item)
    }
}
```

## Requirements

- macOS with Xcode 15.0 or later
- iOS 15.0 or later (for deployment)
- Swift 5.0 or later

## Notes

- This app is intentionally basic to serve as a starting point
- All limitations are documented and deliberate
- Focus on demonstrating measurable improvements
- Document your changes and improvements thoroughly
- Keep the original version for comparison

## License

This is a capstone project starter template. Feel free to modify and improve as needed for your academic project.

## Next Steps

1. Run the app and familiarize yourself with the codebase
2. Review `DataManager.swift` to understand the inefficient algorithms
3. Create a branch for your improvements
4. Start with architecture improvements, then algorithms, then database
5. Document all changes and measure performance improvements
