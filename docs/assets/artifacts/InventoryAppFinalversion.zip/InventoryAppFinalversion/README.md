# Inventory Management App - Final Version

**Author:** Hamad Alghaithi  
**Course:** CS 499 - Computer Science Capstone  
**Institution:** Southern New Hampshire University  
**Version:** 3.0 (Final ePortfolio)

---

## Overview

A professional iOS inventory management application built with Swift 5.9 and SwiftUI, demonstrating enhancements across three key areas: Software Design, Algorithms, and Database Implementation.

## Requirements

- **Xcode:** 15.0+
- **iOS:** 17.0+
- **Swift:** 5.9+
- **Device:** iPhone or iPad

## Setup Instructions

1. Unzip the project archive
2. Open `InventoryApp.xcodeproj` in Xcode
3. Select a signing team (Signing & Capabilities tab)
4. Select an iPhone simulator or connected device
5. Press **⌘R** to build and run
6. Press **⌘U** to run unit tests

## Project Architecture

### MVVM Pattern

```
InventoryApp/
├── App/
│   └── InventoryApp.swift          # App entry point, SwiftData setup
├── Models/
│   ├── Item.swift                  # @Model - Main inventory item
│   ├── CategoryEntity.swift        # @Model - Category with relationships
│   ├── AuditLogEntry.swift         # @Model - Activity tracking
│   └── ItemImage.swift             # @Model - Image attachments
├── ViewModels/
│   ├── InventoryViewModel.swift    # List state, search, filtering
│   ├── AddItemViewModel.swift      # Form validation, save logic
│   ├── DashboardViewModel.swift    # Analytics computations
│   └── SettingsViewModel.swift     # User preferences
├── Views/
│   ├── MainTabView.swift           # Tab navigation (5 tabs)
│   ├── Inventory/
│   │   ├── InventoryView.swift     # Main list with search/filter
│   │   ├── ItemDetailView.swift    # Full item details
│   │   └── AddItemView.swift       # Add/Edit form
│   ├── Dashboard/
│   │   └── DashboardView.swift     # Charts and analytics
│   ├── Categories/
│   │   └── CategoriesView.swift    # Category management
│   ├── Reports/
│   │   └── ExportView.swift        # CSV/JSON export
│   ├── Settings/
│   │   └── SettingsView.swift      # App configuration
│   ├── Scanner/
│   │   └── BarcodeScannerView.swift # Barcode scanning
│   ├── Components/
│   │   └── ItemRowView.swift       # Reusable list row
│   └── AuditLogView.swift          # Activity log
├── Services/
│   ├── ValidationService.swift     # Input validation
│   ├── SecurityUtilities.swift     # Sanitization, XSS/SQL prevention
│   ├── AuditService.swift          # Activity logging
│   ├── ExportManager.swift         # Data export (CSV/JSON)
│   ├── NotificationManager.swift   # Low stock alerts
│   └── BiometricAuthService.swift  # Face ID/Touch ID
├── Utilities/
│   ├── AlgorithmUtilities.swift    # Binary search, benchmarking
│   └── Constants.swift             # App-wide configuration
└── Extensions/
    └── Color+Hex.swift             # Hex color support
```

## Enhancement Areas

### 1. Software Design (Milestone Two)

| Aspect | Original | Enhanced |
|--------|----------|----------|
| Architecture | Basic MVC | MVVM with separation of concerns |
| UI Framework | UIKit/Storyboards | SwiftUI with declarative UI |
| Error Handling | None | ValidationService with typed errors |
| Testing | None | 40+ unit tests |
| Code Organization | Single file | 32 files across 8 folders |

### 2. Algorithm Optimization (Milestone Three)

| Operation | Original O(n) | Enhanced | Improvement |
|-----------|---------------|----------|-------------|
| Sort | Bubble O(n²) | Timsort O(n log n) | ~100x faster |
| Search | Linear O(n) | Binary O(log n) | ~1000x faster |
| Lookup | Array scan O(n) | Dictionary O(1) | Constant time |
| Filter | Per keystroke | Debounced 300ms | ~80% fewer ops |

### 3. Database Implementation (Milestone Four)

| Aspect | Original | Enhanced |
|--------|----------|----------|
| Storage | UserDefaults | SwiftData (SQLite) |
| Schema | Flat key-value | Relational with foreign keys |
| Validation | None | Comprehensive input validation |
| Security | None | XSS/SQL injection prevention |
| Audit Trail | None | Full activity logging |

## Features

1. **CRUD Operations** - Add, view, edit, delete inventory items
2. **SwiftData Persistence** - Relational database with @Model
3. **Dashboard Analytics** - Charts showing value by category, stock distribution
4. **Category Management** - Custom categories with icons and colors
5. **Search & Filter** - Debounced search with category/stock filters
6. **Sort Options** - Name, price, quantity, date (ascending/descending)
7. **Stock Level Tracking** - Visual indicators (optimal/low/critical/out)
8. **Barcode Scanner** - AVFoundation camera-based scanning
9. **Data Export** - CSV and JSON export with share sheet
10. **Audit Trail** - Complete activity log with filtering
11. **Input Validation** - Name, quantity, price validation
12. **Security** - XSS prevention, SQL injection detection, sanitization
13. **Biometric Auth** - Face ID / Touch ID support
14. **Low Stock Alerts** - Local notification support
15. **Item Detail View** - Comprehensive item information
16. **Quantity Adjustment** - Quick +/- from detail view
17. **Expiration Tracking** - Date-based expiration with warnings
18. **Tags System** - Flexible item tagging
19. **Pull to Refresh** - Standard iOS refresh pattern
20. **Unit Tests** - 40+ tests for validation, security, algorithms

## Running Tests

```
⌘U in Xcode
```

Test files:
- `ValidationServiceTests.swift` - Input validation tests
- `SecurityUtilitiesTests.swift` - Security and sanitization tests
- `AlgorithmTests.swift` - Binary search, sort, performance comparison

## License

This project was created for educational purposes as part of the CS 499 Computer Science Capstone at Southern New Hampshire University.

---

*Created by Hamad Alghaithi - CS 499 Capstone ePortfolio*
