//
//  AlgorithmTests.swift
//  InventoryAppTests
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//

import XCTest
@testable import InventoryApp

final class AlgorithmTests: XCTestCase {
    
    // MARK: - Binary Search Tests
    
    func testBinarySearchFound() {
        let array = [1, 3, 5, 7, 9, 11, 13, 15]
        XCTAssertEqual(AlgorithmUtilities.binarySearch(for: 7, in: array), 3)
    }
    
    func testBinarySearchNotFound() {
        let array = [1, 3, 5, 7, 9]
        XCTAssertNil(AlgorithmUtilities.binarySearch(for: 4, in: array))
    }
    
    func testBinarySearchFirstElement() {
        let array = [1, 3, 5, 7, 9]
        XCTAssertEqual(AlgorithmUtilities.binarySearch(for: 1, in: array), 0)
    }
    
    func testBinarySearchLastElement() {
        let array = [1, 3, 5, 7, 9]
        XCTAssertEqual(AlgorithmUtilities.binarySearch(for: 9, in: array), 4)
    }
    
    func testBinarySearchEmptyArray() {
        let array: [Int] = []
        XCTAssertNil(AlgorithmUtilities.binarySearch(for: 1, in: array))
    }
    
    func testBinarySearchSingleElement() {
        XCTAssertEqual(AlgorithmUtilities.binarySearch(for: 5, in: [5]), 0)
        XCTAssertNil(AlgorithmUtilities.binarySearch(for: 3, in: [5]))
    }
    
    func testBinarySearchStrings() {
        let array = ["apple", "banana", "cherry", "date", "elderberry"]
        XCTAssertEqual(AlgorithmUtilities.binarySearch(for: "cherry", in: array), 2)
    }
    
    // MARK: - Bubble Sort Tests (for comparison)
    
    func testBubbleSortIntegers() {
        var array = [5, 3, 8, 1, 9, 2, 7]
        AlgorithmUtilities.bubbleSort(&array)
        XCTAssertEqual(array, [1, 2, 3, 5, 7, 8, 9])
    }
    
    func testBubbleSortAlreadySorted() {
        var array = [1, 2, 3, 4, 5]
        AlgorithmUtilities.bubbleSort(&array)
        XCTAssertEqual(array, [1, 2, 3, 4, 5])
    }
    
    func testBubbleSortReversed() {
        var array = [5, 4, 3, 2, 1]
        AlgorithmUtilities.bubbleSort(&array)
        XCTAssertEqual(array, [1, 2, 3, 4, 5])
    }
    
    func testBubbleSortEmpty() {
        var array: [Int] = []
        AlgorithmUtilities.bubbleSort(&array)
        XCTAssertEqual(array, [])
    }
    
    func testBubbleSortSingleElement() {
        var array = [42]
        AlgorithmUtilities.bubbleSort(&array)
        XCTAssertEqual(array, [42])
    }
    
    // MARK: - Optimized Sort Tests
    
    func testOptimizedSortAscending() {
        let items = [3, 1, 4, 1, 5, 9, 2, 6]
        let sorted = AlgorithmUtilities.optimizedSort(items, by: \.self, ascending: true)
        XCTAssertEqual(sorted, [1, 1, 2, 3, 4, 5, 6, 9])
    }
    
    func testOptimizedSortDescending() {
        let items = [3, 1, 4, 1, 5]
        let sorted = AlgorithmUtilities.optimizedSort(items, by: \.self, ascending: false)
        XCTAssertEqual(sorted, [5, 4, 3, 1, 1])
    }
    
    // MARK: - Performance Comparison
    
    func testSortPerformanceComparison() {
        // Generate test data
        let size = 1000
        var bubbleArray = (0..<size).map { _ in Int.random(in: 0...10000) }
        let timsortArray = bubbleArray
        
        // Bubble Sort O(n²)
        let bubbleTime = AlgorithmUtilities.benchmark("Bubble Sort (\(size) items)") {
            AlgorithmUtilities.bubbleSort(&bubbleArray)
        }
        
        // Timsort O(n log n)
        let timsortTime = AlgorithmUtilities.benchmark("Timsort (\(size) items)") {
            _ = timsortArray.sorted()
        }
        
        // Timsort should be faster
        print("📊 Bubble: \(String(format: "%.4f", bubbleTime))s vs Timsort: \(String(format: "%.4f", timsortTime))s")
        print("📊 Timsort is \(String(format: "%.1f", bubbleTime / max(timsortTime, 0.0001)))x faster")
        
        // Both should produce same result
        XCTAssertEqual(bubbleArray, timsortArray.sorted())
    }
    
    // MARK: - Binary Search vs Linear Search Performance
    
    func testSearchPerformanceComparison() {
        let size = 10000
        let sortedArray = Array(0..<size)
        let target = size - 1
        
        // Linear search O(n)
        let linearTime = AlgorithmUtilities.benchmark("Linear Search") {
            _ = sortedArray.first { $0 == target }
        }
        
        // Binary search O(log n)
        let binaryTime = AlgorithmUtilities.benchmark("Binary Search") {
            _ = AlgorithmUtilities.binarySearch(for: target, in: sortedArray)
        }
        
        print("📊 Linear: \(String(format: "%.6f", linearTime))s vs Binary: \(String(format: "%.6f", binaryTime))s")
    }
}
