//
//  SecurityUtilitiesTests.swift
//  InventoryAppTests
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//

import XCTest
@testable import InventoryApp

final class SecurityUtilitiesTests: XCTestCase {
    
    // MARK: - Sanitization
    
    func testBasicSanitization() {
        let result = SecurityUtilities.sanitize("  Hello World  ")
        XCTAssertEqual(result, "Hello World")
    }
    
    func testHTMLStripping() {
        let result = SecurityUtilities.stripHTMLTags("<b>Bold</b> text")
        XCTAssertEqual(result, "Bold text")
    }
    
    func testScriptTagRemoval() {
        let result = SecurityUtilities.sanitize("<script>alert('xss')</script>Normal text")
        XCTAssertEqual(result, "alert('xss')Normal text")
    }
    
    func testWhitespaceNormalization() {
        let result = SecurityUtilities.normalizeWhitespace("Hello    World")
        XCTAssertEqual(result, "Hello World")
    }
    
    func testMaxLengthTruncation() {
        let longString = String(repeating: "a", count: 1500)
        let result = SecurityUtilities.sanitize(longString)
        XCTAssertEqual(result.count, 1000)
    }
    
    // MARK: - Suspicious Content Detection
    
    func testDetectsScriptTag() {
        XCTAssertTrue(SecurityUtilities.containsSuspiciousContent("<script>"))
    }
    
    func testDetectsSQLInjection() {
        XCTAssertTrue(SecurityUtilities.containsSuspiciousContent("'; DROP TABLE items; --"))
    }
    
    func testDetectsUnionSelect() {
        XCTAssertTrue(SecurityUtilities.containsSuspiciousContent("UNION SELECT * FROM users"))
    }
    
    func testSafeInput() {
        XCTAssertFalse(SecurityUtilities.containsSuspiciousContent("Normal item name"))
    }
    
    func testSafeSpecialCharacters() {
        XCTAssertFalse(SecurityUtilities.containsSuspiciousContent("Item #123 - Size: 5\""))
    }
    
    // MARK: - Checksum
    
    func testChecksumGeneration() {
        let checksum = SecurityUtilities.generateChecksum("test data")
        XCTAssertFalse(checksum.isEmpty)
        XCTAssertEqual(checksum.count, 64) // SHA-256 hex
    }
    
    func testChecksumConsistency() {
        let checksum1 = SecurityUtilities.generateChecksum("same data")
        let checksum2 = SecurityUtilities.generateChecksum("same data")
        XCTAssertEqual(checksum1, checksum2)
    }
    
    func testChecksumDifference() {
        let checksum1 = SecurityUtilities.generateChecksum("data 1")
        let checksum2 = SecurityUtilities.generateChecksum("data 2")
        XCTAssertNotEqual(checksum1, checksum2)
    }
    
    func testChecksumVerification() {
        let data = "verify me"
        let checksum = SecurityUtilities.generateChecksum(data)
        XCTAssertTrue(SecurityUtilities.verifyChecksum(data, checksum: checksum))
    }
    
    func testChecksumVerificationFails() {
        XCTAssertFalse(SecurityUtilities.verifyChecksum("data", checksum: "wrong"))
    }
    
    // MARK: - String Extension
    
    func testSanitizedExtension() {
        let result = "  <b>Test</b>  ".sanitized
        XCTAssertEqual(result, "Test")
    }
    
    func testIsSafeExtension() {
        XCTAssertTrue("Normal text".isSafe)
        XCTAssertFalse("<script>hack</script>".isSafe)
    }
}
