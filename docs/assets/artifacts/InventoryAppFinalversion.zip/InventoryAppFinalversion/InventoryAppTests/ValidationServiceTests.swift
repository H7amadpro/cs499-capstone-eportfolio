//
//  ValidationServiceTests.swift
//  InventoryAppTests
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//

import XCTest
@testable import InventoryApp

final class ValidationServiceTests: XCTestCase {
    
    // MARK: - Name Validation
    
    func testValidName() {
        XCTAssertNil(ValidationService.validateName("Laptop"))
    }
    
    func testEmptyName() {
        XCTAssertEqual(ValidationService.validateName(""), .emptyName)
    }
    
    func testWhitespaceName() {
        XCTAssertEqual(ValidationService.validateName("   "), .emptyName)
    }
    
    func testNameTooLong() {
        let longName = String(repeating: "a", count: 101)
        XCTAssertEqual(ValidationService.validateName(longName), .nameTooLong(100))
    }
    
    func testNameMaxLength() {
        let name = String(repeating: "a", count: 100)
        XCTAssertNil(ValidationService.validateName(name))
    }
    
    func testSuspiciousName() {
        XCTAssertEqual(ValidationService.validateName("<script>alert('xss')</script>"), .suspiciousInput("name"))
    }
    
    func testSQLInjectionName() {
        XCTAssertEqual(ValidationService.validateName("'; DROP TABLE items; --"), .suspiciousInput("name"))
    }
    
    // MARK: - Quantity Validation
    
    func testValidQuantity() {
        XCTAssertNil(ValidationService.validateQuantity(10))
    }
    
    func testZeroQuantity() {
        XCTAssertNil(ValidationService.validateQuantity(0))
    }
    
    func testNegativeQuantity() {
        XCTAssertEqual(ValidationService.validateQuantity(-1), .negativeQuantity)
    }
    
    func testQuantityTooLarge() {
        XCTAssertEqual(ValidationService.validateQuantity(1_000_000), .quantityTooLarge(999_999))
    }
    
    func testMaxQuantity() {
        XCTAssertNil(ValidationService.validateQuantity(999_999))
    }
    
    // MARK: - Price Validation
    
    func testValidPrice() {
        XCTAssertNil(ValidationService.validatePrice(29.99))
    }
    
    func testZeroPrice() {
        XCTAssertNil(ValidationService.validatePrice(0))
    }
    
    func testNegativePrice() {
        XCTAssertEqual(ValidationService.validatePrice(-1.0), .negativePrice)
    }
    
    func testPriceTooLarge() {
        XCTAssertEqual(ValidationService.validatePrice(1_000_000.0), .priceTooLarge(999_999.99))
    }
    
    // MARK: - Full Item Validation
    
    func testValidItem() {
        XCTAssertNoThrow(try ValidationService.validateItem(
            name: "Test Item", quantity: 10, price: 9.99, category: nil
        ))
    }
    
    func testInvalidItemThrows() {
        XCTAssertThrowsError(try ValidationService.validateItem(
            name: "", quantity: 10, price: 9.99, category: nil
        ))
    }
}
