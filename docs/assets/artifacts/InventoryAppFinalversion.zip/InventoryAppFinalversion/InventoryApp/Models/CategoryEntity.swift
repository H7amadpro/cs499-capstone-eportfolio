//
//  CategoryEntity.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//

import Foundation
import SwiftData

@Model
final class CategoryEntity {
    
    @Attribute(.unique) var id: UUID
    var name: String
    var iconName: String
    var colorHex: String
    var createdAt: Date
    var updatedAt: Date
    
    @Relationship(deleteRule: .nullify, inverse: \Item.category)
    var items: [Item]?
    
    var itemCount: Int {
        items?.count ?? 0
    }
    
    var totalValue: Double {
        items?.reduce(0) { $0 + $1.totalValue } ?? 0
    }
    
    init(name: String, iconName: String, colorHex: String) {
        self.id = UUID()
        self.name = name
        self.iconName = iconName
        self.colorHex = colorHex
        self.items = []
        self.createdAt = Date()
        self.updatedAt = Date()
    }
}
