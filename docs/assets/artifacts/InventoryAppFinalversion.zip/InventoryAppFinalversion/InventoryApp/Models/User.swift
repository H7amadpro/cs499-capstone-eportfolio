//
//  User.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//

import Foundation
import SwiftData

@Model
final class User {

    // MARK: - Properties

    @Attribute(.unique) var id: UUID
    @Attribute(.unique) var username: String
    var displayName: String
    var passwordHash: String
    var passwordSalt: String
    var role: String
    var email: String?
    var isActive: Bool
    var biometricEnabled: Bool
    var lastLoginDate: Date?
    var createdAt: Date
    var updatedAt: Date

    // MARK: - Relationships

    @Relationship var assignedBranch: Branch?

    // MARK: - Computed Properties

    var userRole: UserRole {
        UserRole(rawValue: role) ?? .viewer
    }

    // MARK: - Initialization

    init(
        username: String,
        displayName: String,
        passwordHash: String,
        passwordSalt: String,
        role: UserRole = .staff,
        email: String? = nil
    ) {
        self.id = UUID()
        self.username = username
        self.displayName = displayName
        self.passwordHash = passwordHash
        self.passwordSalt = passwordSalt
        self.role = role.rawValue
        self.email = email
        self.isActive = true
        self.biometricEnabled = false
        self.createdAt = Date()
        self.updatedAt = Date()
    }
}

// MARK: - User Role

enum UserRole: String, CaseIterable, Identifiable, Codable {
    case admin = "admin"
    case manager = "manager"
    case staff = "staff"
    case viewer = "viewer"

    var id: String { rawValue }

    var displayName: String {
        switch self {
        case .admin: return "Admin"
        case .manager: return "Manager"
        case .staff: return "Staff"
        case .viewer: return "Viewer"
        }
    }

    var description: String {
        switch self {
        case .admin: return "Full access to all features"
        case .manager: return "Manage items, categories, suppliers, and reports"
        case .staff: return "Add and edit items, adjust quantities"
        case .viewer: return "View-only access"
        }
    }

    var iconName: String {
        switch self {
        case .admin: return "shield.checkered"
        case .manager: return "person.badge.key"
        case .staff: return "person.fill"
        case .viewer: return "eye.fill"
        }
    }

    // MARK: - Permissions

    var canManageUsers: Bool { self == .admin }
    var canManageBranches: Bool { self == .admin }
    var canManageCategories: Bool { self == .admin || self == .manager }
    var canCreateItems: Bool { self != .viewer }
    var canEditItems: Bool { self != .viewer }
    var canDeleteItems: Bool { self == .admin || self == .manager }
    var canAdjustQuantity: Bool { self != .viewer }
    var canExportData: Bool { self == .admin || self == .manager }
    var canViewReports: Bool { true }
    var canManageSuppliers: Bool { self == .admin || self == .manager }
    var canBackupRestore: Bool { self == .admin }
    var canTransferStock: Bool { self == .admin || self == .manager }
    var canViewCost: Bool { self == .admin || self == .manager }  // Only Admin/Manager can view cost
}
