//
//  Supplier.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//

import Foundation
import SwiftData

@Model
final class Supplier {

    // MARK: - Properties

    @Attribute(.unique) var id: UUID
    var name: String
    var contactPerson: String?
    var email: String?
    var phone: String?
    var address: String?
    var notes: String?
    var isActive: Bool
    var createdAt: Date
    var updatedAt: Date

    // MARK: - Relationships

    @Relationship(deleteRule: .nullify, inverse: \Item.supplier)
    var items: [Item]?

    // MARK: - Computed Properties

    var itemCount: Int {
        items?.count ?? 0
    }

    var totalValue: Double {
        items?.reduce(0) { $0 + $1.totalValue } ?? 0
    }

    var formattedTotalValue: String {
        String(format: "$%.2f", totalValue)
    }

    // MARK: - Initialization

    init(
        name: String,
        contactPerson: String? = nil,
        email: String? = nil,
        phone: String? = nil,
        address: String? = nil,
        notes: String? = nil
    ) {
        self.id = UUID()
        self.name = name
        self.contactPerson = contactPerson
        self.email = email
        self.phone = phone
        self.address = address
        self.notes = notes
        self.isActive = true
        self.items = []
        self.createdAt = Date()
        self.updatedAt = Date()
    }
}
