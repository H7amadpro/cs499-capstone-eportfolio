//
//  ItemImage.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//

import Foundation
import SwiftData
import SwiftUI

@Model
final class ItemImage {
    
    @Attribute(.unique) var id: UUID
    @Attribute(.externalStorage) var imageData: Data
    var thumbnailData: Data?
    var caption: String?
    var order: Int
    var createdAt: Date
    
    @Relationship(inverse: \Item.images) var item: Item?
    
    init(imageData: Data, thumbnailData: Data? = nil, caption: String? = nil, order: Int = 0) {
        self.id = UUID()
        self.imageData = imageData
        self.thumbnailData = thumbnailData
        self.caption = caption
        self.order = order
        self.createdAt = Date()
    }
    
    #if canImport(UIKit)
    var uiImage: UIImage? {
        UIImage(data: imageData)
    }
    
    var thumbnail: UIImage? {
        if let data = thumbnailData {
            return UIImage(data: data)
        }
        return uiImage
    }
    #endif
}
