//
//  StockTransfer.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//

import Foundation
import SwiftData

@Model
final class StockTransfer {

    // MARK: - Properties

    @Attribute(.unique) var id: UUID
    var quantity: Int
    var notes: String?
    var status: String
    var createdAt: Date
    var completedAt: Date?

    // MARK: - Relationships

    @Relationship var item: Item?
    @Relationship var fromBranch: Branch?
    @Relationship var toBranch: Branch?
    @Relationship var initiatedBy: User?

    // MARK: - Computed Properties

    var transferStatus: TransferStatus {
        TransferStatus(rawValue: status) ?? .pending
    }

    var itemName: String {
        item?.name ?? "Unknown Item"
    }

    var fromBranchName: String {
        fromBranch?.name ?? "Unknown"
    }

    var toBranchName: String {
        toBranch?.name ?? "Unknown"
    }

    var initiatedByName: String {
        initiatedBy?.displayName ?? "Unknown"
    }

    // MARK: - Initialization

    init(
        item: Item,
        fromBranch: Branch,
        toBranch: Branch,
        quantity: Int,
        initiatedBy: User? = nil,
        notes: String? = nil
    ) {
        self.id = UUID()
        self.item = item
        self.fromBranch = fromBranch
        self.toBranch = toBranch
        self.quantity = quantity
        self.initiatedBy = initiatedBy
        self.notes = notes
        self.status = TransferStatus.pending.rawValue
        self.createdAt = Date()
    }

    // MARK: - Methods

    func complete() {
        status = TransferStatus.completed.rawValue
        completedAt = Date()
    }

    func cancel() {
        status = TransferStatus.cancelled.rawValue
        completedAt = Date()
    }
}

// MARK: - Transfer Status

enum TransferStatus: String, CaseIterable, Identifiable {
    case pending = "pending"
    case completed = "completed"
    case cancelled = "cancelled"

    var id: String { rawValue }

    var displayName: String {
        switch self {
        case .pending: return "Pending"
        case .completed: return "Completed"
        case .cancelled: return "Cancelled"
        }
    }

    var iconName: String {
        switch self {
        case .pending: return "clock.fill"
        case .completed: return "checkmark.circle.fill"
        case .cancelled: return "xmark.circle.fill"
        }
    }
}
