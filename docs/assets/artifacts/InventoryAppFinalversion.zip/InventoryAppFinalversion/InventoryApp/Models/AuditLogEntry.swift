//
//  AuditLogEntry.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//

import Foundation
import SwiftData

@Model
final class AuditLogEntry {

    @Attribute(.unique) var id: UUID
    var timestamp: Date
    var action: String
    var entityType: String
    var entityId: UUID
    var entityName: String
    var oldValue: String?
    var newValue: String?
    var notes: String?
    var userId: UUID?
    var userName: String?

    init(
        action: AuditAction,
        entityType: String,
        entityId: UUID,
        entityName: String,
        oldValue: String? = nil,
        newValue: String? = nil,
        notes: String? = nil,
        userId: UUID? = nil,
        userName: String? = nil
    ) {
        self.id = UUID()
        self.timestamp = Date()
        self.action = action.rawValue
        self.entityType = entityType
        self.entityId = entityId
        self.entityName = entityName
        self.oldValue = oldValue
        self.newValue = newValue
        self.notes = notes
        self.userId = userId
        self.userName = userName
    }

    var auditAction: AuditAction {
        AuditAction(rawValue: action) ?? .update
    }
}

enum AuditAction: String, CaseIterable, Identifiable {
    case create = "Created"
    case update = "Updated"
    case delete = "Deleted"
    case quantityIncrease = "Stock Added"
    case quantityDecrease = "Stock Removed"
    case export = "Exported"
    case login = "Login"
    case logout = "Logout"
    case transfer = "Stock Transfer"
    case backup = "Backup"
    case restore = "Restore"

    var id: String { rawValue }

    var iconName: String {
        switch self {
        case .create: return "plus.circle.fill"
        case .update: return "pencil.circle.fill"
        case .delete: return "trash.circle.fill"
        case .quantityIncrease: return "arrow.up.circle.fill"
        case .quantityDecrease: return "arrow.down.circle.fill"
        case .export: return "square.and.arrow.up.circle.fill"
        case .login: return "person.badge.key.fill"
        case .logout: return "rectangle.portrait.and.arrow.right.fill"
        case .transfer: return "arrow.left.arrow.right.circle.fill"
        case .backup: return "externaldrive.fill"
        case .restore: return "arrow.counterclockwise.circle.fill"
        }
    }
}
