//
//  Branch.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//

import Foundation
import SwiftData

@Model
final class Branch {

    // MARK: - Properties

    @Attribute(.unique) var id: UUID
    var name: String
    var address: String?
    var phone: String?
    var email: String?
    var isActive: Bool
    var isDefault: Bool
    var createdAt: Date
    var updatedAt: Date

    // MARK: - Relationships

    @Relationship(deleteRule: .nullify, inverse: \Item.branch)
    var items: [Item]?

    @Relationship(deleteRule: .nullify, inverse: \User.assignedBranch)
    var users: [User]?

    // MARK: - Computed Properties

    var itemCount: Int {
        items?.count ?? 0
    }

    var totalValue: Double {
        items?.reduce(0) { $0 + $1.totalValue } ?? 0
    }

    var formattedTotalValue: String {
        String(format: "$%.2f", totalValue)
    }

    var userCount: Int {
        users?.count ?? 0
    }

    // MARK: - Initialization

    init(
        name: String,
        address: String? = nil,
        phone: String? = nil,
        email: String? = nil,
        isDefault: Bool = false
    ) {
        self.id = UUID()
        self.name = name
        self.address = address
        self.phone = phone
        self.email = email
        self.isActive = true
        self.isDefault = isDefault
        self.items = []
        self.users = []
        self.createdAt = Date()
        self.updatedAt = Date()
    }
}
