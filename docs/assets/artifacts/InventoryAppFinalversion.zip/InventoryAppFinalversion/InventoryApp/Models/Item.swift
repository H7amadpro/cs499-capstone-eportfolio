//
//  Item.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//

import Foundation
import SwiftData

@Model
final class Item {
    
    // MARK: - Properties
    
    @Attribute(.unique) var id: UUID
    var name: String
    var itemDescription: String
    var quantity: Int
    var minimumQuantity: Int
    var maximumQuantity: Int?
    var price: Double
    var cost: Double?  // Cost field - only visible to Admin/Manager
    var barcode: String?
    var sku: String?
    var location: String?
    var notes: String?
    var tags: [String]
    var expirationDate: Date?
    var manufacturingDate: Date?
    var batchNumber: String?
    var createdAt: Date
    var updatedAt: Date
    
    // MARK: - Relationships

    @Relationship var category: CategoryEntity?
    @Relationship(deleteRule: .cascade) var images: [ItemImage]?
    @Relationship var branch: Branch?
    @Relationship var supplier: Supplier?
    
    // MARK: - Computed Properties
    
    var isLowStock: Bool {
        quantity <= minimumQuantity
    }
    
    var isOutOfStock: Bool {
        quantity <= 0
    }
    
    var totalValue: Double {
        Double(quantity) * price
    }
    
    var formattedPrice: String {
        String(format: "$%.2f", price)
    }
    
    var formattedCost: String? {
        guard let cost = cost else { return nil }
        return String(format: "$%.2f", cost)
    }
    
    var profitMargin: Double? {
        guard let cost = cost, cost > 0 else { return nil }
        return ((price - cost) / cost) * 100
    }
    
    var formattedTotalValue: String {
        String(format: "$%.2f", totalValue)
    }
    
    var categoryName: String {
        category?.name ?? "Uncategorized"
    }
    
    var categoryIconName: String {
        category?.iconName ?? "square.grid.2x2"
    }

    var branchName: String {
        branch?.name ?? "Unassigned"
    }

    var supplierName: String {
        supplier?.name ?? "No Supplier"
    }
    
    var stockStatus: StockStatus {
        if quantity <= 0 { return .outOfStock }
        if quantity <= minimumQuantity { return .critical }
        let ratio = maximumQuantity.map { Double(quantity) / Double($0) } ?? (Double(quantity) / Double(max(minimumQuantity * 4, 1)))
        if ratio < 0.25 { return .critical }
        if ratio < 0.50 { return .low }
        if ratio < 0.75 { return .adequate }
        if let max = maximumQuantity, quantity > max { return .overstock }
        return .optimal
    }
    
    var isExpired: Bool {
        guard let expDate = expirationDate else { return false }
        return expDate < Date()
    }
    
    var daysUntilExpiration: Int? {
        guard let expDate = expirationDate else { return nil }
        return Calendar.current.dateComponents([.day], from: Date(), to: expDate).day
    }
    
    var expirationStatus: ExpirationStatus {
        guard let days = daysUntilExpiration else { return .noExpiration }
        if days < 0 { return .expired }
        if days <= 7 { return .critical }
        if days <= 30 { return .warning }
        return .good
    }
    
    var stockPercentage: Double {
        guard let max = maximumQuantity, max > 0 else {
            let threshold = max(minimumQuantity * 4, 10)
            return min(Double(quantity) / Double(threshold), 1.0)
        }
        return min(Double(quantity) / Double(max), 1.0)
    }
    
    // MARK: - Initialization
    
    init(
        name: String,
        itemDescription: String = "",
        quantity: Int = 0,
        minimumQuantity: Int = 5,
        maximumQuantity: Int? = nil,
        price: Double = 0.0,
        cost: Double? = nil,
        barcode: String? = nil,
        sku: String? = nil,
        location: String? = nil,
        notes: String? = nil,
        tags: [String] = [],
        expirationDate: Date? = nil,
        manufacturingDate: Date? = nil,
        batchNumber: String? = nil,
        category: CategoryEntity? = nil,
        branch: Branch? = nil,
        supplier: Supplier? = nil
    ) {
        self.id = UUID()
        self.name = name
        self.itemDescription = itemDescription
        self.quantity = quantity
        self.minimumQuantity = minimumQuantity
        self.maximumQuantity = maximumQuantity
        self.price = price
        self.cost = cost
        self.barcode = barcode
        self.sku = sku
        self.location = location
        self.notes = notes
        self.tags = tags
        self.expirationDate = expirationDate
        self.manufacturingDate = manufacturingDate
        self.batchNumber = batchNumber
        self.category = category
        self.branch = branch
        self.supplier = supplier
        self.images = []
        self.createdAt = Date()
        self.updatedAt = Date()
    }
    
    // MARK: - Methods
    
    func update(
        name: String? = nil,
        itemDescription: String? = nil,
        quantity: Int? = nil,
        minimumQuantity: Int? = nil,
        maximumQuantity: Int?? = nil,
        price: Double? = nil,
        barcode: String?? = nil,
        location: String?? = nil,
        notes: String?? = nil,
        tags: [String]? = nil,
        expirationDate: Date?? = nil,
        category: CategoryEntity?? = nil
    ) {
        if let name = name { self.name = name }
        if let desc = itemDescription { self.itemDescription = desc }
        if let qty = quantity { self.quantity = qty }
        if let minQty = minimumQuantity { self.minimumQuantity = minQty }
        if let maxQty = maximumQuantity { self.maximumQuantity = maxQty }
        if let price = price { self.price = price }
        if let barcode = barcode { self.barcode = barcode }
        if let loc = location { self.location = loc }
        if let notes = notes { self.notes = notes }
        if let tags = tags { self.tags = tags }
        if let exp = expirationDate { self.expirationDate = exp }
        if let cat = category { self.category = cat }
        self.updatedAt = Date()
    }
}

// MARK: - Enums

enum StockStatus: String, CaseIterable {
    case outOfStock = "Out of Stock"
    case critical = "Critical"
    case low = "Low"
    case adequate = "Adequate"
    case optimal = "Optimal"
    case overstock = "Overstock"
    
    var color: String {
        switch self {
        case .outOfStock: return "red"
        case .critical: return "orange"
        case .low: return "yellow"
        case .adequate: return "green"
        case .optimal: return "green"
        case .overstock: return "blue"
        }
    }
}

enum ExpirationStatus: String {
    case noExpiration = "No Expiration"
    case good = "Good"
    case warning = "Expiring Soon"
    case critical = "Expiring This Week"
    case expired = "Expired"
}

enum SortOption: String, CaseIterable, Identifiable {
    case nameAsc = "Name (A-Z)"
    case nameDesc = "Name (Z-A)"
    case quantityAsc = "Quantity (Low to High)"
    case quantityDesc = "Quantity (High to Low)"
    case priceAsc = "Price (Low to High)"
    case priceDesc = "Price (High to Low)"
    case dateAddedDesc = "Date Added (Newest)"
    case dateAddedAsc = "Date Added (Oldest)"
    case lastModified = "Recently Modified"
    
    var id: String { rawValue }
}

enum StockLevelFilter: String, CaseIterable, Identifiable {
    case all = "All"
    case inStock = "In Stock"
    case lowStock = "Low Stock"
    case outOfStock = "Out of Stock"
    
    var id: String { rawValue }
}
