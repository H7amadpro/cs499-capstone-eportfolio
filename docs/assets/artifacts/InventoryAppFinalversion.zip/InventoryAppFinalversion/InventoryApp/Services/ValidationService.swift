//
//  ValidationService.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//

import Foundation

// MARK: - Validation Error

enum ValidationError: LocalizedError, Equatable {
    case emptyName
    case nameTooLong(Int)
    case nameTooShort(Int)
    case negativeQuantity
    case quantityTooLarge(Int)
    case negativePrice
    case priceTooLarge(Double)
    case invalidBarcode
    case suspiciousInput(String)
    
    var errorDescription: String? {
        switch self {
        case .emptyName: return "Item name cannot be empty."
        case .nameTooLong(let max): return "Name cannot exceed \(max) characters."
        case .nameTooShort(let min): return "Name must be at least \(min) character(s)."
        case .negativeQuantity: return "Quantity cannot be negative."
        case .quantityTooLarge(let max): return "Quantity cannot exceed \(max)."
        case .negativePrice: return "Price cannot be negative."
        case .priceTooLarge(let max): return "Price cannot exceed \(String(format: "$%.2f", max))."
        case .invalidBarcode: return "Invalid barcode format."
        case .suspiciousInput(let field): return "Invalid characters detected in \(field)."
        }
    }
    
    static func == (lhs: ValidationError, rhs: ValidationError) -> Bool {
        lhs.errorDescription == rhs.errorDescription
    }
}

// MARK: - Validation Service

struct ValidationService {
    
    static let maxNameLength = 100
    static let minNameLength = 1
    static let maxQuantity = 999_999
    static let maxPrice: Double = 999_999.99
    
    static func validateName(_ name: String) -> ValidationError? {
        let trimmed = name.trimmingCharacters(in: .whitespacesAndNewlines)
        if trimmed.isEmpty { return .emptyName }
        if trimmed.count < minNameLength { return .nameTooShort(minNameLength) }
        if trimmed.count > maxNameLength { return .nameTooLong(maxNameLength) }
        if SecurityUtilities.containsSuspiciousContent(trimmed) { return .suspiciousInput("name") }
        return nil
    }
    
    static func validateQuantity(_ quantity: Int) -> ValidationError? {
        if quantity < 0 { return .negativeQuantity }
        if quantity > maxQuantity { return .quantityTooLarge(maxQuantity) }
        return nil
    }
    
    static func validatePrice(_ price: Double) -> ValidationError? {
        if price < 0 { return .negativePrice }
        if price > maxPrice { return .priceTooLarge(maxPrice) }
        return nil
    }
    
    static func validateItem(
        name: String,
        quantity: Int,
        price: Double,
        category: CategoryEntity?
    ) throws {
        var errors: [ValidationError] = []
        if let e = validateName(name) { errors.append(e) }
        if let e = validateQuantity(quantity) { errors.append(e) }
        if let e = validatePrice(price) { errors.append(e) }
        if let first = errors.first { throw first }
    }
}
