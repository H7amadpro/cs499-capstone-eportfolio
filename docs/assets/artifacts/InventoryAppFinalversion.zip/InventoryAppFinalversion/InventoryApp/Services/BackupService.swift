//
//  BackupService.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//

import Foundation
import SwiftData

struct BackupService {

    // MARK: - Backup Data Structures

    struct BackupData: Codable {
        let version: String
        let createdAt: String
        let items: [ItemBackup]
        let categories: [CategoryBackup]
        let suppliers: [SupplierBackup]
        let branches: [BranchBackup]
        let auditEntries: [AuditBackup]
    }

    struct ItemBackup: Codable {
        let id: String
        let name: String
        let itemDescription: String
        let quantity: Int
        let minimumQuantity: Int
        let maximumQuantity: Int?
        let price: Double
        let barcode: String?
        let sku: String?
        let location: String?
        let notes: String?
        let tags: [String]
        let expirationDate: String?
        let manufacturingDate: String?
        let batchNumber: String?
        let categoryName: String?
        let branchName: String?
        let supplierName: String?
        let createdAt: String
        let updatedAt: String
    }

    struct CategoryBackup: Codable {
        let id: String
        let name: String
        let iconName: String
        let colorHex: String
    }

    struct SupplierBackup: Codable {
        let id: String
        let name: String
        let contactPerson: String?
        let email: String?
        let phone: String?
        let address: String?
        let notes: String?
    }

    struct BranchBackup: Codable {
        let id: String
        let name: String
        let address: String?
        let phone: String?
        let email: String?
        let isDefault: Bool
    }

    struct AuditBackup: Codable {
        let timestamp: String
        let action: String
        let entityType: String
        let entityName: String
        let oldValue: String?
        let newValue: String?
        let userName: String?
    }

    // MARK: - Date Formatter

    private static let isoFormatter: ISO8601DateFormatter = {
        let f = ISO8601DateFormatter()
        f.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        return f
    }()

    // MARK: - Export

    static func exportBackup(context: ModelContext) throws -> URL {
        let items = (try? context.fetch(FetchDescriptor<Item>())) ?? []
        let categories = (try? context.fetch(FetchDescriptor<CategoryEntity>())) ?? []
        let suppliers = (try? context.fetch(FetchDescriptor<Supplier>())) ?? []
        let branches = (try? context.fetch(FetchDescriptor<Branch>())) ?? []
        var auditDescriptor = FetchDescriptor<AuditLogEntry>(
            sortBy: [SortDescriptor(\.timestamp, order: .reverse)]
        )
        auditDescriptor.fetchLimit = 500
        let audit = (try? context.fetch(auditDescriptor)) ?? []

        let backup = BackupData(
            version: "2.0",
            createdAt: isoFormatter.string(from: Date()),
            items: items.map { item in
                ItemBackup(
                    id: item.id.uuidString,
                    name: item.name,
                    itemDescription: item.itemDescription,
                    quantity: item.quantity,
                    minimumQuantity: item.minimumQuantity,
                    maximumQuantity: item.maximumQuantity,
                    price: item.price,
                    barcode: item.barcode,
                    sku: item.sku,
                    location: item.location,
                    notes: item.notes,
                    tags: item.tags,
                    expirationDate: item.expirationDate.map { isoFormatter.string(from: $0) },
                    manufacturingDate: item.manufacturingDate.map { isoFormatter.string(from: $0) },
                    batchNumber: item.batchNumber,
                    categoryName: item.category?.name,
                    branchName: item.branch?.name,
                    supplierName: item.supplier?.name,
                    createdAt: isoFormatter.string(from: item.createdAt),
                    updatedAt: isoFormatter.string(from: item.updatedAt)
                )
            },
            categories: categories.map { cat in
                CategoryBackup(
                    id: cat.id.uuidString,
                    name: cat.name,
                    iconName: cat.iconName,
                    colorHex: cat.colorHex
                )
            },
            suppliers: suppliers.map { sup in
                SupplierBackup(
                    id: sup.id.uuidString,
                    name: sup.name,
                    contactPerson: sup.contactPerson,
                    email: sup.email,
                    phone: sup.phone,
                    address: sup.address,
                    notes: sup.notes
                )
            },
            branches: branches.map { br in
                BranchBackup(
                    id: br.id.uuidString,
                    name: br.name,
                    address: br.address,
                    phone: br.phone,
                    email: br.email,
                    isDefault: br.isDefault
                )
            },
            auditEntries: audit.map { entry in
                AuditBackup(
                    timestamp: isoFormatter.string(from: entry.timestamp),
                    action: entry.action,
                    entityType: entry.entityType,
                    entityName: entry.entityName,
                    oldValue: entry.oldValue,
                    newValue: entry.newValue,
                    userName: entry.userName
                )
            }
        )

        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        let data = try encoder.encode(backup)

        let fileName = "inventory_backup_\(Int(Date().timeIntervalSince1970)).json"
        let url = FileManager.default.temporaryDirectory.appendingPathComponent(fileName)
        try data.write(to: url)

        UserDefaults.standard.set(Date().timeIntervalSince1970, forKey: "lastBackupDate")

        return url
    }

    // MARK: - Import

    static func importBackup(from url: URL, context: ModelContext) throws {
        let data = try Data(contentsOf: url)
        let decoder = JSONDecoder()
        let backup = try decoder.decode(BackupData.self, from: data)

        // Clear existing items (keep users)
        let existingItems = (try? context.fetch(FetchDescriptor<Item>())) ?? []
        for item in existingItems { context.delete(item) }

        let existingCategories = (try? context.fetch(FetchDescriptor<CategoryEntity>())) ?? []
        for cat in existingCategories { context.delete(cat) }

        let existingSuppliers = (try? context.fetch(FetchDescriptor<Supplier>())) ?? []
        for sup in existingSuppliers { context.delete(sup) }

        let existingBranches = (try? context.fetch(FetchDescriptor<Branch>())) ?? []
        for br in existingBranches { context.delete(br) }

        let existingAudit = (try? context.fetch(FetchDescriptor<AuditLogEntry>())) ?? []
        for entry in existingAudit { context.delete(entry) }

        try context.save()

        // Restore categories
        var categoryMap: [String: CategoryEntity] = [:]
        for catBackup in backup.categories {
            let cat = CategoryEntity(name: catBackup.name, iconName: catBackup.iconName, colorHex: catBackup.colorHex)
            context.insert(cat)
            categoryMap[catBackup.name] = cat
        }

        // Restore branches
        var branchMap: [String: Branch] = [:]
        for brBackup in backup.branches {
            let br = Branch(name: brBackup.name, address: brBackup.address,
                          phone: brBackup.phone, email: brBackup.email,
                          isDefault: brBackup.isDefault)
            context.insert(br)
            branchMap[brBackup.name] = br
        }

        // Restore suppliers
        var supplierMap: [String: Supplier] = [:]
        for supBackup in backup.suppliers {
            let sup = Supplier(name: supBackup.name, contactPerson: supBackup.contactPerson,
                             email: supBackup.email, phone: supBackup.phone,
                             address: supBackup.address, notes: supBackup.notes)
            context.insert(sup)
            supplierMap[supBackup.name] = sup
        }

        // Restore items
        for itemBackup in backup.items {
            let item = Item(
                name: itemBackup.name,
                itemDescription: itemBackup.itemDescription,
                quantity: itemBackup.quantity,
                minimumQuantity: itemBackup.minimumQuantity,
                maximumQuantity: itemBackup.maximumQuantity,
                price: itemBackup.price,
                barcode: itemBackup.barcode,
                sku: itemBackup.sku,
                location: itemBackup.location,
                notes: itemBackup.notes,
                tags: itemBackup.tags,
                expirationDate: itemBackup.expirationDate.flatMap { isoFormatter.date(from: $0) },
                manufacturingDate: itemBackup.manufacturingDate.flatMap { isoFormatter.date(from: $0) },
                batchNumber: itemBackup.batchNumber,
                category: itemBackup.categoryName.flatMap { categoryMap[$0] },
                branch: itemBackup.branchName.flatMap { branchMap[$0] },
                supplier: itemBackup.supplierName.flatMap { supplierMap[$0] }
            )
            context.insert(item)
        }

        // Restore audit entries
        for auditBackup in backup.auditEntries {
            let auditAction = AuditAction(rawValue: auditBackup.action) ?? .update
            let entry = AuditLogEntry(
                action: auditAction,
                entityType: auditBackup.entityType,
                entityId: UUID(),
                entityName: auditBackup.entityName,
                oldValue: auditBackup.oldValue,
                newValue: auditBackup.newValue,
                userName: auditBackup.userName
            )
            context.insert(entry)
        }

        try context.save()
    }
}
