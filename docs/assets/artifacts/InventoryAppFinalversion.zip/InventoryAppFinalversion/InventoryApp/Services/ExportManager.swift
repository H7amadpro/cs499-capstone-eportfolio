//
//  ExportManager.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//

import Foundation

enum ExportFormat: String, CaseIterable, Identifiable {
    case csv = "CSV"
    case json = "JSON"

    var id: String { rawValue }
    var fileExtension: String { rawValue.lowercased() }
}

struct ExportManager {

    static func exportItems(_ items: [Item], format: ExportFormat) throws -> URL {
        switch format {
        case .csv: return try exportCSV(items)
        case .json: return try exportJSON(items)
        }
    }

    // MARK: - CSV Export

    private static func exportCSV(_ items: [Item]) throws -> URL {
        var csv = "Name,Category,Branch,Supplier,Quantity,Min Quantity,Price,Total Value,Barcode,Location,Status,Created,Updated\n"

        let dateFormatter = DateFormatter()
        dateFormatter.dateStyle = .short
        dateFormatter.timeStyle = .short

        for item in items {
            let fields = [
                escapeCSV(item.name),
                escapeCSV(item.categoryName),
                escapeCSV(item.branchName ?? ""),
                escapeCSV(item.supplierName ?? ""),
                "\(item.quantity)",
                "\(item.minimumQuantity)",
                String(format: "%.2f", item.price),
                String(format: "%.2f", item.totalValue),
                escapeCSV(item.barcode ?? ""),
                escapeCSV(item.location ?? ""),
                item.stockStatus.rawValue,
                dateFormatter.string(from: item.createdAt),
                dateFormatter.string(from: item.updatedAt)
            ]
            csv += fields.joined(separator: ",") + "\n"
        }

        let url = FileManager.default.temporaryDirectory.appendingPathComponent("inventory_export.csv")
        try csv.write(to: url, atomically: true, encoding: .utf8)
        return url
    }

    // MARK: - JSON Export

    private static func exportJSON(_ items: [Item]) throws -> URL {
        let exportData = items.map { item -> [String: Any] in
            [
                "name": item.name,
                "category": item.categoryName,
                "branch": item.branchName ?? "",
                "supplier": item.supplierName ?? "",
                "quantity": item.quantity,
                "minimumQuantity": item.minimumQuantity,
                "price": item.price,
                "totalValue": item.totalValue,
                "barcode": item.barcode ?? "",
                "location": item.location ?? "",
                "status": item.stockStatus.rawValue,
                "createdAt": ISO8601DateFormatter().string(from: item.createdAt),
                "updatedAt": ISO8601DateFormatter().string(from: item.updatedAt)
            ]
        }

        let data = try JSONSerialization.data(withJSONObject: exportData, options: [.prettyPrinted, .sortedKeys])
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("inventory_export.json")
        try data.write(to: url)
        return url
    }

    // MARK: - Helpers

    private static func escapeCSV(_ field: String) -> String {
        if field.contains(",") || field.contains("\"") || field.contains("\n") {
            return "\"\(field.replacingOccurrences(of: "\"", with: "\"\""))\""
        }
        return field
    }
}
