//
//  AuditService.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//

import Foundation
import SwiftData

struct AuditService {

    let modelContext: ModelContext
    var currentUser: User?

    // MARK: - Generic Logging

    func log(
        action: AuditAction,
        entityType: String,
        entityId: UUID,
        entityName: String,
        oldValue: String? = nil,
        newValue: String? = nil,
        notes: String? = nil
    ) {
        let entry = AuditLogEntry(
            action: action,
            entityType: entityType,
            entityId: entityId,
            entityName: entityName,
            oldValue: oldValue,
            newValue: newValue,
            notes: notes,
            userId: currentUser?.id,
            userName: currentUser?.displayName
        )
        modelContext.insert(entry)
        try? modelContext.save()
    }

    // MARK: - Item Logging

    func logItemCreated(_ item: Item) {
        log(action: .create, entityType: "Item", entityId: item.id, entityName: item.name,
            newValue: "Qty: \(item.quantity), Price: \(item.formattedPrice)")
    }

    func logItemUpdated(_ item: Item, changes: String) {
        log(action: .update, entityType: "Item", entityId: item.id, entityName: item.name,
            newValue: changes)
    }

    func logItemDeleted(_ item: Item) {
        log(action: .delete, entityType: "Item", entityId: item.id, entityName: item.name,
            oldValue: "Qty: \(item.quantity), Price: \(item.formattedPrice)")
    }

    func logQuantityChange(_ item: Item, oldQty: Int, newQty: Int) {
        let action: AuditAction = newQty > oldQty ? .quantityIncrease : .quantityDecrease
        log(action: action, entityType: "Item", entityId: item.id, entityName: item.name,
            oldValue: "\(oldQty)", newValue: "\(newQty)")
    }

    // MARK: - Transfer Logging

    func logTransfer(item: Item, fromBranch: Branch, toBranch: Branch, quantity: Int) {
        log(action: .transfer, entityType: "Transfer", entityId: item.id, entityName: item.name,
            oldValue: "\(fromBranch.name) (-\(quantity))",
            newValue: "\(toBranch.name) (+\(quantity))")
    }

    // MARK: - Auth Logging

    func logLogin(user: User) {
        log(action: .login, entityType: "User", entityId: user.id, entityName: user.displayName)
    }

    func logLogout(user: User) {
        log(action: .logout, entityType: "User", entityId: user.id, entityName: user.displayName)
    }

    // MARK: - Backup Logging

    func logBackup() {
        log(action: .backup, entityType: "System", entityId: UUID(), entityName: "Database Backup",
            newValue: "Full backup exported")
    }

    func logRestore() {
        log(action: .restore, entityType: "System", entityId: UUID(), entityName: "Database Restore",
            newValue: "Backup restored")
    }

    // MARK: - Fetch

    func fetchRecentEntries(limit: Int = 50) -> [AuditLogEntry] {
        var descriptor = FetchDescriptor<AuditLogEntry>(
            sortBy: [SortDescriptor(\.timestamp, order: .reverse)]
        )
        descriptor.fetchLimit = limit
        return (try? modelContext.fetch(descriptor)) ?? []
    }
}
