//
//  SecurityUtilities.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//

import Foundation
import CryptoKit

struct SecurityUtilities {
    
    // MARK: - Input Sanitization
    
    static func sanitize(_ input: String) -> String {
        var result = input.trimmingCharacters(in: .whitespacesAndNewlines)
        result = stripHTMLTags(result)
        result = removeControlCharacters(result)
        result = normalizeWhitespace(result)
        if result.count > 1000 { result = String(result.prefix(1000)) }
        return result
    }
    
    static func stripHTMLTags(_ input: String) -> String {
        input.replacingOccurrences(of: "<[^>]+>", with: "", options: .regularExpression)
    }
    
    static func removeControlCharacters(_ input: String) -> String {
        String(input.unicodeScalars.filter { !$0.properties.isDefaultIgnorableCodePoint && ($0.value >= 32 || $0 == "\n" || $0 == "\t") })
    }
    
    static func normalizeWhitespace(_ input: String) -> String {
        input.components(separatedBy: .whitespaces).filter { !$0.isEmpty }.joined(separator: " ")
    }
    
    // MARK: - Suspicious Content Detection
    
    static func containsSuspiciousContent(_ input: String) -> Bool {
        let lower = input.lowercased()
        let patterns = [
            "<script", "</script", "javascript:", "onerror=", "onload=",
            "drop table", "delete from", "insert into", "union select",
            "'; --", "1=1", "or 1=1"
        ]
        return patterns.contains { lower.contains($0) } || input.contains("\0")
    }
    
    static func isInputSafe(_ input: String) -> Bool {
        !containsSuspiciousContent(input) && !input.contains("\0")
    }
    
    // MARK: - Data Integrity
    
    static func generateChecksum(_ data: String) -> String {
        let inputData = Data(data.utf8)
        let hash = SHA256.hash(data: inputData)
        return hash.compactMap { String(format: "%02x", $0) }.joined()
    }
    
    static func verifyChecksum(_ data: String, checksum: String) -> Bool {
        generateChecksum(data) == checksum
    }
    
    // MARK: - Audit Logging
    
    static func logSecurityEvent(type: String, details: String) {
        let timestamp = ISO8601DateFormatter().string(from: Date())
        print("🔒 [\(timestamp)] \(type): \(details)")
    }
}

// MARK: - String Extensions

extension String {
    var sanitized: String { SecurityUtilities.sanitize(self) }
    var isSafe: Bool { SecurityUtilities.isInputSafe(self) }
}
