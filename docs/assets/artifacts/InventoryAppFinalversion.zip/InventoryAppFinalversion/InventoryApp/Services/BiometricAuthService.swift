//
//  BiometricAuthService.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//

import Foundation
import LocalAuthentication

class BiometricAuthService: ObservableObject {
    
    @Published var isAuthenticated = false
    @Published var isLocked = false
    @Published var errorMessage: String?
    
    var biometricType: LABiometryType {
        let context = LAContext()
        _ = context.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: nil)
        return context.biometryType
    }
    
    var biometricName: String {
        switch biometricType {
        case .faceID: return "Face ID"
        case .touchID: return "Touch ID"
        case .opticID: return "Optic ID"
        default: return "Biometrics"
        }
    }
    
    var isBiometricAvailable: Bool {
        let context = LAContext()
        return context.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: nil)
    }
    
    func authenticate() async -> Bool {
        let context = LAContext()
        context.localizedCancelTitle = "Use Passcode"
        
        var error: NSError?
        guard context.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: &error) else {
            await MainActor.run {
                errorMessage = error?.localizedDescription ?? "Biometrics unavailable"
            }
            return false
        }
        
        do {
            let success = try await context.evaluatePolicy(
                .deviceOwnerAuthenticationWithBiometrics,
                localizedReason: "Authenticate to access inventory"
            )
            await MainActor.run {
                isAuthenticated = success
                isLocked = !success
            }
            return success
        } catch {
            await MainActor.run {
                errorMessage = error.localizedDescription
                isAuthenticated = false
            }
            return false
        }
    }
    
    func lock() {
        isAuthenticated = false
        isLocked = true
    }
}
