//
//  NotificationManager.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//

import Foundation
import UserNotifications

class NotificationManager {
    
    static let shared = NotificationManager()
    private init() {}
    
    func requestPermission() async -> Bool {
        do {
            return try await UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .badge, .sound])
        } catch {
            print("⚠️ Notification permission error: \(error)")
            return false
        }
    }
    
    func scheduleLowStockAlert(for item: Item) {
        let content = UNMutableNotificationContent()
        content.title = "Low Stock Alert"
        content.body = "\(item.name) is running low (Qty: \(item.quantity))"
        content.sound = .default
        content.badge = 1
        
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 1, repeats: false)
        let request = UNNotificationRequest(
            identifier: "lowstock-\(item.id.uuidString)",
            content: content,
            trigger: trigger
        )
        
        UNUserNotificationCenter.current().add(request)
    }
    
    func scheduleExpirationAlert(for item: Item) {
        guard let days = item.daysUntilExpiration, days > 0, days <= 7 else { return }
        
        let content = UNMutableNotificationContent()
        content.title = "Expiration Warning"
        content.body = "\(item.name) expires in \(days) day(s)"
        content.sound = .default
        
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 1, repeats: false)
        let request = UNNotificationRequest(
            identifier: "expiration-\(item.id.uuidString)",
            content: content,
            trigger: trigger
        )
        
        UNUserNotificationCenter.current().add(request)
    }
    
    func cancelAll() {
        UNUserNotificationCenter.current().removeAllPendingNotificationRequests()
    }
    
    func updateBadgeCount(_ count: Int) {
        UNUserNotificationCenter.current().setBadgeCount(count)
    }
}
