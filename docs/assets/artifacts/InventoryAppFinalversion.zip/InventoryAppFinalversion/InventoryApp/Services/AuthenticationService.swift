//
//  AuthenticationService.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//

import Foundation
import SwiftData
import CryptoKit

@MainActor
class AuthenticationService: ObservableObject {

    // MARK: - Published Properties

    @Published var currentUser: User?
    @Published var isAuthenticated: Bool = false
    @Published var isInitialSetup: Bool = false
    @Published var errorMessage: String?

    var authEnabled: Bool {
        get { UserDefaults.standard.bool(forKey: "authEnabled") }
        set {
            UserDefaults.standard.set(newValue, forKey: "authEnabled")
            objectWillChange.send()
            if !newValue {
                isAuthenticated = true
                currentUser = nil
            }
        }
    }

    // MARK: - Biometric

    private let biometricService = BiometricAuthService()

    var biometricAvailable: Bool {
        biometricService.isBiometricAvailable
    }

    var biometricName: String {
        biometricService.biometricName
    }

    // MARK: - Password Hashing

    static func hashPassword(_ password: String, salt: String) -> String {
        let combined = password + salt
        let inputData = Data(combined.utf8)
        let hash = SHA256.hash(data: inputData)
        return hash.compactMap { String(format: "%02x", $0) }.joined()
    }

    static func generateSalt() -> String {
        let bytes = (0..<16).map { _ in UInt8.random(in: 0...255) }
        return bytes.map { String(format: "%02x", $0) }.joined()
    }

    // MARK: - State Management

    func checkInitialState(context: ModelContext) {
        if !authEnabled {
            isAuthenticated = true
            return
        }

        let descriptor = FetchDescriptor<User>()
        let users = (try? context.fetch(descriptor)) ?? []
        isInitialSetup = users.isEmpty

        if isInitialSetup {
            isAuthenticated = false
        }
    }

    // MARK: - User Management

    func createUser(
        username: String,
        displayName: String,
        password: String,
        role: UserRole,
        email: String? = nil,
        context: ModelContext
    ) throws -> User {
        let trimmedUsername = username.trimmingCharacters(in: .whitespaces).lowercased()

        guard !trimmedUsername.isEmpty else {
            throw AuthError.emptyUsername
        }

        guard password.count >= 6 else {
            throw AuthError.passwordTooShort
        }

        guard trimmedUsername.count >= 3 else {
            throw AuthError.usernameTooShort
        }

        // Check uniqueness
        let descriptor = FetchDescriptor<User>()
        let existingUsers = (try? context.fetch(descriptor)) ?? []
        if existingUsers.contains(where: { $0.username.lowercased() == trimmedUsername }) {
            throw AuthError.usernameTaken
        }

        let salt = Self.generateSalt()
        let hash = Self.hashPassword(password, salt: salt)

        let sanitizedUsername = trimmedUsername.sanitized
        let sanitizedDisplayName = displayName.trimmingCharacters(in: .whitespaces).sanitized

        let user = User(
            username: sanitizedUsername,
            displayName: sanitizedDisplayName.isEmpty ? sanitizedUsername : sanitizedDisplayName,
            passwordHash: hash,
            passwordSalt: salt,
            role: role,
            email: email
        )

        context.insert(user)
        try context.save()
        return user
    }

    // MARK: - Authentication

    func login(username: String, password: String, context: ModelContext) -> Bool {
        let trimmed = username.trimmingCharacters(in: .whitespaces).lowercased()

        let descriptor = FetchDescriptor<User>()
        let allUsers = (try? context.fetch(descriptor)) ?? []
        guard let user = allUsers.first(where: { $0.username.lowercased() == trimmed }),
              user.isActive else {
            errorMessage = "Invalid username or password"
            return false
        }

        let hash = Self.hashPassword(password, salt: user.passwordSalt)
        guard hash == user.passwordHash else {
            errorMessage = "Invalid username or password"
            return false
        }

        user.lastLoginDate = Date()
        try? context.save()

        currentUser = user
        isAuthenticated = true
        isInitialSetup = false
        errorMessage = nil

        // Save username for biometric login
        UserDefaults.standard.set(user.username, forKey: "lastLoggedInUser")
        
        // If user has biometric enabled, save for quick login
        if user.biometricEnabled {
            UserDefaults.standard.set(user.username, forKey: "biometricEnabledUser")
        }

        return true
    }

    func biometricLogin(context: ModelContext) async -> Bool {
        // First check if there's a user with biometric enabled
        guard let username = UserDefaults.standard.string(forKey: "biometricEnabledUser") ?? 
              UserDefaults.standard.string(forKey: "lastLoggedInUser") else {
            await MainActor.run {
                errorMessage = "No account found for biometric login"
            }
            return false
        }

        // Verify the user exists and has biometric enabled
        let descriptor = FetchDescriptor<User>()
        let allUsers = (try? context.fetch(descriptor)) ?? []
        guard let user = allUsers.first(where: { $0.username == username }),
              user.isActive else {
            await MainActor.run {
                errorMessage = "User account not found or inactive"
            }
            return false
        }
        
        // Check if biometric is enabled for this user
        guard user.biometricEnabled else {
            await MainActor.run {
                errorMessage = "Biometric login is not enabled for this account"
            }
            return false
        }

        // Perform biometric authentication
        let success = await biometricService.authenticate()
        guard success else {
            await MainActor.run {
                errorMessage = biometricService.errorMessage ?? "Biometric authentication failed"
            }
            return false
        }

        // Successfully authenticated - log in the user
        user.lastLoginDate = Date()
        try? context.save()

        await MainActor.run {
            currentUser = user
            isAuthenticated = true
            errorMessage = nil
        }
        return true
    }
    
    /// Enable biometric login for the current user
    func enableBiometric(for user: User, context: ModelContext) {
        user.biometricEnabled = true
        user.updatedAt = Date()
        try? context.save()
        UserDefaults.standard.set(user.username, forKey: "biometricEnabledUser")
    }
    
    /// Disable biometric login for the current user
    func disableBiometric(for user: User, context: ModelContext) {
        user.biometricEnabled = false
        user.updatedAt = Date()
        try? context.save()
        if UserDefaults.standard.string(forKey: "biometricEnabledUser") == user.username {
            UserDefaults.standard.removeObject(forKey: "biometricEnabledUser")
        }
    }

    func logout() {
        currentUser = nil
        isAuthenticated = false
    }

    func changePassword(user: User, currentPassword: String, newPassword: String, context: ModelContext) throws {
        let currentHash = Self.hashPassword(currentPassword, salt: user.passwordSalt)
        guard currentHash == user.passwordHash else {
            throw AuthError.invalidCredentials
        }

        guard newPassword.count >= 6 else {
            throw AuthError.passwordTooShort
        }

        let newSalt = Self.generateSalt()
        let newHash = Self.hashPassword(newPassword, salt: newSalt)
        user.passwordSalt = newSalt
        user.passwordHash = newHash
        user.updatedAt = Date()
        try context.save()
    }

    // MARK: - Permission Helpers

    func hasPermission(_ check: (UserRole) -> Bool) -> Bool {
        guard authEnabled else { return true }
        guard let user = currentUser else { return false }
        return check(user.userRole)
    }
}

// MARK: - Auth Errors

enum AuthError: LocalizedError {
    case emptyUsername
    case usernameTooShort
    case passwordTooShort
    case usernameTaken
    case invalidCredentials

    var errorDescription: String? {
        switch self {
        case .emptyUsername: return "Username cannot be empty."
        case .usernameTooShort: return "Username must be at least 3 characters."
        case .passwordTooShort: return "Password must be at least 6 characters."
        case .usernameTaken: return "Username is already taken."
        case .invalidCredentials: return "Invalid username or password."
        }
    }
}
