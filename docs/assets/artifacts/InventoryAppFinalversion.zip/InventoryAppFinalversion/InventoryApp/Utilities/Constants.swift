//
//  Constants.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//

import Foundation

enum Constants {
    static let maxNameLength = 100
    static let minNameLength = 1
    static let maxQuantity = 999_999
    static let maxPrice: Double = 999_999.99
    static let lowStockThreshold = 5
    static let searchDebounceInterval: TimeInterval = 0.3
    static let currencyCode = "USD"
    
    static let displayDateFormatter: DateFormatter = {
        let f = DateFormatter()
        f.dateStyle = .medium
        f.timeStyle = .short
        return f
    }()
}
