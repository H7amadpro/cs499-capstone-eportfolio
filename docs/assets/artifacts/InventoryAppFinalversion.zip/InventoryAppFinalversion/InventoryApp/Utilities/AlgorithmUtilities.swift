//
//  AlgorithmUtilities.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//
//  Optimized algorithms: Binary Search O(log n), Dictionary O(1),
//  Swift's Timsort O(n log n), and search debouncing.
//

import Foundation

struct AlgorithmUtilities {
    
    // MARK: - Binary Search O(log n)
    
    /// Performs binary search on a sorted array
    /// - Returns: Index of the element, or nil if not found
    static func binarySearch<T: Comparable>(
        for target: T,
        in array: [T],
        by keyPath: KeyPath<T, T>? = nil
    ) -> Int? {
        var low = 0
        var high = array.count - 1
        
        while low <= high {
            let mid = low + (high - low) / 2
            let value = array[mid]
            
            if value == target { return mid }
            else if value < target { low = mid + 1 }
            else { high = mid - 1 }
        }
        return nil
    }
    
    /// Binary search for items by name in a sorted array
    static func binarySearchByName(for name: String, in items: [Item]) -> Item? {
        let sorted = items.sorted { $0.name.lowercased() < $1.name.lowercased() }
        var low = 0
        var high = sorted.count - 1
        let target = name.lowercased()
        
        while low <= high {
            let mid = low + (high - low) / 2
            let midName = sorted[mid].name.lowercased()
            
            if midName == target { return sorted[mid] }
            else if midName < target { low = mid + 1 }
            else { high = mid - 1 }
        }
        return nil
    }
    
    // MARK: - Performance Benchmarking
    
    /// Measures execution time of a closure
    static func benchmark(_ label: String, block: () -> Void) -> TimeInterval {
        let start = CFAbsoluteTimeGetCurrent()
        block()
        let elapsed = CFAbsoluteTimeGetCurrent() - start
        print("⏱ \(label): \(String(format: "%.4f", elapsed))s")
        return elapsed
    }
    
    // MARK: - Sorting Comparison
    
    /// Bubble Sort O(n²) - kept for comparison benchmarking
    static func bubbleSort<T: Comparable>(_ array: inout [T]) {
        let n = array.count
        for i in 0..<n {
            for j in 0..<(n - i - 1) {
                if array[j] > array[j + 1] {
                    array.swapAt(j, j + 1)
                }
            }
        }
    }
    
    /// Optimized sort using Swift's Timsort O(n log n)
    static func optimizedSort<T, V: Comparable>(_ array: [T], by keyPath: KeyPath<T, V>, ascending: Bool = true) -> [T] {
        array.sorted {
            ascending ? $0[keyPath: keyPath] < $1[keyPath: keyPath]
                      : $0[keyPath: keyPath] > $1[keyPath: keyPath]
        }
    }
}
