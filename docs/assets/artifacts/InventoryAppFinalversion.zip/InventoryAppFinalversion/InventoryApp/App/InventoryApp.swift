//
//  InventoryApp.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//
//  FINAL VERSION - Production Ready
//  Main application entry point with SwiftData configuration.
//

import SwiftUI
import SwiftData

@main
struct InventoryApp: App {

    // MARK: - Properties

    let modelContainer: ModelContainer
    @StateObject private var authService = AuthenticationService()
    @StateObject private var branchViewModel = BranchViewModel()

    // MARK: - Initialization

    init() {
        let schema = Schema([
            Item.self,
            CategoryEntity.self,
            AuditLogEntry.self,
            ItemImage.self,
            User.self,
            Branch.self,
            Supplier.self,
            StockTransfer.self
        ])

        let config = ModelConfiguration(
            schema: schema,
            isStoredInMemoryOnly: false
        )

        do {
            let container = try ModelContainer(for: schema, configurations: [config])
            self.modelContainer = container

            // Seed defaults synchronously
            InventoryApp.seedDefaults(context: container.mainContext)

        } catch {
            fatalError("Failed to initialize SwiftData: \(error.localizedDescription)")
        }
    }

    // MARK: - Body

    var body: some Scene {
        WindowGroup {
            Group {
                if authService.authEnabled && !authService.isAuthenticated {
                    LoginView()
                        .environmentObject(authService)
                } else {
                    MainTabView()
                        .environmentObject(authService)
                        .environmentObject(branchViewModel)
                }
            }
            .modelContainer(modelContainer)
            .onAppear {
                authService.checkInitialState(context: modelContainer.mainContext)
            }
        }
    }

    // MARK: - Seeding

    private static func seedDefaults(context: ModelContext) {
        // Seed categories
        let categoryDescriptor = FetchDescriptor<CategoryEntity>()
        guard let existingCategories = try? context.fetch(categoryDescriptor),
              existingCategories.isEmpty else {
            seedDefaultBranch(context: context)
            return
        }

        let defaults: [(String, String, String)] = [
            ("Electronics", "laptopcomputer", "#007AFF"),
            ("Office Supplies", "pencil.and.ruler", "#34C759"),
            ("Furniture", "chair.lounge", "#FF9500"),
            ("Food & Beverage", "cup.and.saucer", "#FF2D55"),
            ("Clothing", "tshirt", "#AF52DE"),
            ("Tools", "wrench.and.screwdriver", "#8E8E93"),
            ("Other", "square.grid.2x2", "#5856D6")
        ]

        for (name, icon, color) in defaults {
            let category = CategoryEntity(name: name, iconName: icon, colorHex: color)
            context.insert(category)
        }

        seedDefaultBranch(context: context)
        try? context.save()
    }

    private static func seedDefaultBranch(context: ModelContext) {
        let branchDescriptor = FetchDescriptor<Branch>()
        guard let existingBranches = try? context.fetch(branchDescriptor),
              existingBranches.isEmpty else { return }

        let defaultBranch = Branch(
            name: "Main Warehouse",
            isDefault: true
        )
        context.insert(defaultBranch)
        try? context.save()
    }
}
