//
//  DashboardView.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//

import SwiftUI
import SwiftData
import Charts

struct DashboardView: View {

    @EnvironmentObject var branchViewModel: BranchViewModel
    @Environment(\.modelContext) private var modelContext
    @Query private var items: [Item]
    @Query private var categories: [CategoryEntity]
    @StateObject private var viewModel = DashboardViewModel()

    private var filteredItems: [Item] {
        branchViewModel.filterItems(items)
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 16) {
                    // Branch Picker
                    BranchPickerView()

                    // Summary Cards
                    summaryCards
                    
                    // Category Chart
                    categoryChart
                    
                    // Stock Distribution
                    stockDistributionChart
                    
                    // Top Value Items
                    topValueSection
                    
                    // Recently Modified
                    recentActivitySection
                }
                .padding()
            }
            .navigationTitle("Dashboard")
            .background(Color(.systemGroupedBackground))
        }
    }
    
    // MARK: - Summary Cards
    
    private var summaryCards: some View {
        LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 12) {
            StatCard(
                title: "Total Items",
                value: "\(viewModel.totalItems(filteredItems))",
                icon: "cube.box.fill",
                color: .blue
            )
            StatCard(
                title: "Total Value",
                value: viewModel.formattedTotalValue(filteredItems),
                icon: "dollarsign.circle.fill",
                color: .green
            )
            StatCard(
                title: "Low Stock",
                value: "\(viewModel.lowStockCount(filteredItems))",
                icon: "exclamationmark.triangle.fill",
                color: .orange
            )
            StatCard(
                title: "Out of Stock",
                value: "\(viewModel.outOfStockCount(filteredItems))",
                icon: "xmark.circle.fill",
                color: .red
            )
        }
    }
    
    // MARK: - Category Chart
    
    private var categoryChart: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Value by Category")
                .font(.headline)
            
            let breakdown = viewModel.categoryBreakdown(filteredItems, categories: categories)
            
            if breakdown.isEmpty {
                Text("No data available")
                    .foregroundStyle(.secondary)
                    .frame(maxWidth: .infinity, alignment: .center)
                    .padding(.vertical, 40)
            } else {
                Chart(breakdown) { item in
                    BarMark(
                        x: .value("Value", item.value),
                        y: .value("Category", item.name)
                    )
                    .foregroundStyle(Color(hex: item.colorHex))
                    .annotation(position: .trailing) {
                        Text(String(format: "$%.0f", item.value))
                            .font(.caption2)
                            .foregroundStyle(.secondary)
                    }
                }
                .frame(height: CGFloat(max(breakdown.count * 44, 100)))
                .chartXAxis(.hidden)
            }
        }
        .padding()
        .background(Color(.systemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 12))
    }
    
    // MARK: - Stock Distribution
    
    private var stockDistributionChart: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Stock Distribution")
                .font(.headline)
            
            let distribution = viewModel.stockDistribution(filteredItems)
            
            if distribution.isEmpty {
                Text("No data available")
                    .foregroundStyle(.secondary)
                    .frame(maxWidth: .infinity, alignment: .center)
                    .padding(.vertical, 40)
            } else {
                Chart(distribution) { item in
                    SectorMark(
                        angle: .value("Count", item.count),
                        innerRadius: .ratio(0.5),
                        angularInset: 2
                    )
                    .foregroundStyle(colorForStatus(item.color))
                    .annotation(position: .overlay) {
                        Text("\(item.count)")
                            .font(.caption2)
                            .fontWeight(.bold)
                            .foregroundStyle(.white)
                    }
                }
                .frame(height: 200)
                
                // Legend
                LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 4) {
                    ForEach(distribution) { item in
                        HStack(spacing: 4) {
                            Circle()
                                .fill(colorForStatus(item.color))
                                .frame(width: 8, height: 8)
                            Text(item.status)
                                .font(.caption)
                                .foregroundStyle(.secondary)
                            Spacer()
                        }
                    }
                }
            }
        }
        .padding()
        .background(Color(.systemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 12))
    }
    
    // MARK: - Top Value Items
    
    private var topValueSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Top Value Items")
                .font(.headline)
            
            let topItems = viewModel.topValueItems(filteredItems)
            
            if topItems.isEmpty {
                Text("No items yet")
                    .foregroundStyle(.secondary)
                    .padding(.vertical, 20)
            } else {
                ForEach(topItems) { item in
                    HStack {
                        Image(systemName: item.categoryIconName)
                            .foregroundStyle(Color(hex: item.category?.colorHex ?? "#8E8E93"))
                            .frame(width: 24)
                        Text(item.name)
                            .font(.subheadline)
                            .lineLimit(1)
                        Spacer()
                        Text(item.formattedTotalValue)
                            .font(.subheadline)
                            .fontWeight(.semibold)
                            .foregroundStyle(.green)
                    }
                    .padding(.vertical, 4)
                    if item.id != topItems.last?.id {
                        Divider()
                    }
                }
            }
        }
        .padding()
        .background(Color(.systemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 12))
    }
    
    // MARK: - Recent Activity
    
    private var recentActivitySection: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Recently Modified")
                .font(.headline)
            
            let recent = viewModel.recentlyModified(filteredItems)
            
            if recent.isEmpty {
                Text("No recent activity")
                    .foregroundStyle(.secondary)
                    .padding(.vertical, 20)
            } else {
                ForEach(recent) { item in
                    HStack {
                        Image(systemName: item.categoryIconName)
                            .foregroundStyle(.secondary)
                            .frame(width: 24)
                        VStack(alignment: .leading) {
                            Text(item.name)
                                .font(.subheadline)
                            Text(item.updatedAt, style: .relative)
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                        Spacer()
                    }
                    .padding(.vertical, 2)
                }
            }
        }
        .padding()
        .background(Color(.systemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 12))
    }
    
    private func colorForStatus(_ name: String) -> Color {
        switch name {
        case "red": return .red
        case "orange": return .orange
        case "yellow": return .yellow
        case "green": return .green
        case "blue": return .blue
        default: return .gray
        }
    }
}

// MARK: - Stat Card

struct StatCard: View {
    let title: String
    let value: String
    let icon: String
    var color: Color = .blue
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Image(systemName: icon)
                    .font(.title3)
                    .foregroundStyle(color)
                Spacer()
            }
            Text(value)
                .font(.title2)
                .fontWeight(.bold)
            Text(title)
                .font(.caption)
                .foregroundStyle(.secondary)
        }
        .padding()
        .background(Color(.systemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 12))
    }
}
