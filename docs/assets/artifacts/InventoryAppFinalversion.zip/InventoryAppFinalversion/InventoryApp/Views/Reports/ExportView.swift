//
//  ExportView.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//

import SwiftUI

struct ExportView: View {
    
    @Environment(\.dismiss) private var dismiss
    let items: [Item]
    @State private var selectedFormat: ExportFormat = .csv
    @State private var isExporting = false
    @State private var exportURL: URL?
    @State private var showingShareSheet = false
    @State private var errorMessage: String?
    @State private var showingError = false
    
    var body: some View {
        NavigationStack {
            Form {
                Section("Export Format") {
                    Picker("Format", selection: $selectedFormat) {
                        ForEach(ExportFormat.allCases) { format in
                            Text(format.rawValue).tag(format)
                        }
                    }
                    .pickerStyle(.segmented)
                }
                
                Section("Summary") {
                    HStack {
                        Text("Items to Export")
                        Spacer()
                        Text("\(items.count)")
                            .foregroundStyle(.secondary)
                    }
                    HStack {
                        Text("Total Value")
                        Spacer()
                        Text(String(format: "$%.2f", items.reduce(0) { $0 + $1.totalValue }))
                            .foregroundStyle(.secondary)
                    }
                    HStack {
                        Text("File Format")
                        Spacer()
                        Text(".\(selectedFormat.fileExtension)")
                            .foregroundStyle(.secondary)
                    }
                }
                
                Section {
                    Button {
                        exportData()
                    } label: {
                        HStack {
                            Spacer()
                            if isExporting {
                                ProgressView()
                                    .padding(.trailing, 8)
                            }
                            Label("Export \(selectedFormat.rawValue)", systemImage: "square.and.arrow.up")
                                .fontWeight(.semibold)
                            Spacer()
                        }
                    }
                    .disabled(isExporting || items.isEmpty)
                }
            }
            .navigationTitle("Export Data")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }
                }
            }
            .sheet(isPresented: $showingShareSheet) {
                if let url = exportURL {
                    ShareSheet(items: [url])
                }
            }
            .alert("Export Error", isPresented: $showingError) {
                Button("OK") {}
            } message: {
                Text(errorMessage ?? "Failed to export data")
            }
        }
    }
    
    private func exportData() {
        isExporting = true
        do {
            let url = try ExportManager.exportItems(items, format: selectedFormat)
            exportURL = url
            showingShareSheet = true
        } catch {
            errorMessage = error.localizedDescription
            showingError = true
        }
        isExporting = false
    }
}


