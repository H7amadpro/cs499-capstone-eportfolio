//
//  CategoriesView.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//

import SwiftUI
import SwiftData

struct CategoriesView: View {

    @EnvironmentObject var authService: AuthenticationService
    @Environment(\.modelContext) private var modelContext
    @Query(sort: \CategoryEntity.name) private var categories: [CategoryEntity]
    @State private var showingAddCategory = false
    @State private var editingCategory: CategoryEntity?
    @State private var categoryToDelete: CategoryEntity?
    @State private var showingDeleteAlert = false

    // Add category form
    @State private var newName = ""
    @State private var newIcon = "square.grid.2x2"
    @State private var newColor = "#007AFF"

    private let iconOptions = [
        "laptopcomputer", "pencil.and.ruler", "chair.lounge", "cup.and.saucer",
        "tshirt", "wrench.and.screwdriver", "square.grid.2x2", "book.fill",
        "car.fill", "heart.fill", "star.fill", "leaf.fill", "flame.fill",
        "drop.fill", "bolt.fill", "camera.fill", "gamecontroller.fill",
        "headphones", "printer.fill", "desktopcomputer"
    ]

    private let colorOptions = [
        "#007AFF", "#34C759", "#FF9500", "#FF2D55", "#AF52DE",
        "#8E8E93", "#5856D6", "#FF3B30", "#00C7BE", "#32ADE6"
    ]

    var body: some View {
        NavigationStack {
            List {
                ForEach(categories) { category in
                    HStack(spacing: 12) {
                        ZStack {
                            Circle()
                                .fill(Color(hex: category.colorHex).opacity(0.15))
                                .frame(width: 44, height: 44)
                            Image(systemName: category.iconName)
                                .foregroundStyle(Color(hex: category.colorHex))
                        }

                        VStack(alignment: .leading, spacing: 2) {
                            Text(category.name)
                                .font(.body)
                                .fontWeight(.medium)
                            Text("\(category.itemCount) items")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }

                        Spacer()

                        if category.totalValue > 0 {
                            Text(String(format: "$%.2f", category.totalValue))
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                        }
                    }
                    .padding(.vertical, 4)
                    .swipeActions(edge: .trailing) {
                        if authService.hasPermission({ $0.canManageCategories }) {
                            Button(role: .destructive) {
                                categoryToDelete = category
                                showingDeleteAlert = true
                            } label: {
                                Label("Delete", systemImage: "trash")
                            }
                        }
                    }
                    .swipeActions(edge: .leading) {
                        if authService.hasPermission({ $0.canManageCategories }) {
                            Button {
                                editingCategory = category
                                newName = category.name
                                newIcon = category.iconName
                                newColor = category.colorHex
                                showingAddCategory = true
                            } label: {
                                Label("Edit", systemImage: "pencil")
                            }
                            .tint(.blue)
                        }
                    }
                }
            }
            .listStyle(.insetGrouped)
            .navigationTitle("Categories")
            .toolbar {
                if authService.hasPermission({ $0.canManageCategories }) {
                    ToolbarItem(placement: .primaryAction) {
                        Button {
                            editingCategory = nil
                            newName = ""
                            newIcon = "square.grid.2x2"
                            newColor = "#007AFF"
                            showingAddCategory = true
                        } label: {
                            Image(systemName: "plus")
                        }
                    }
                }
            }
            .sheet(isPresented: $showingAddCategory) {
                categoryForm
            }
            .alert("Delete Category?", isPresented: $showingDeleteAlert) {
                Button("Delete", role: .destructive) {
                    if let cat = categoryToDelete {
                        modelContext.delete(cat)
                        try? modelContext.save()
                    }
                }
                Button("Cancel", role: .cancel) {}
            } message: {
                Text("Items in this category will become uncategorized.")
            }
        }
    }

    // MARK: - Category Form

    private var categoryForm: some View {
        NavigationStack {
            Form {
                Section("Name") {
                    TextField("Category Name", text: $newName)
                }

                Section("Icon") {
                    LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 5), spacing: 12) {
                        ForEach(iconOptions, id: \.self) { icon in
                            Button {
                                newIcon = icon
                            } label: {
                                Image(systemName: icon)
                                    .font(.title3)
                                    .frame(width: 44, height: 44)
                                    .background(newIcon == icon ? Color.blue.opacity(0.2) : Color(.systemGray6))
                                    .clipShape(RoundedRectangle(cornerRadius: 8))
                                    .foregroundStyle(newIcon == icon ? .blue : .primary)
                            }
                        }
                    }
                }

                Section("Color") {
                    LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 5), spacing: 12) {
                        ForEach(colorOptions, id: \.self) { color in
                            Button {
                                newColor = color
                            } label: {
                                Circle()
                                    .fill(Color(hex: color))
                                    .frame(width: 36, height: 36)
                                    .overlay {
                                        if newColor == color {
                                            Image(systemName: "checkmark")
                                                .foregroundStyle(.white)
                                                .fontWeight(.bold)
                                        }
                                    }
                            }
                        }
                    }
                }

                // Preview
                Section("Preview") {
                    HStack(spacing: 12) {
                        ZStack {
                            Circle()
                                .fill(Color(hex: newColor).opacity(0.15))
                                .frame(width: 44, height: 44)
                            Image(systemName: newIcon)
                                .foregroundStyle(Color(hex: newColor))
                        }
                        Text(newName.isEmpty ? "Category Name" : newName)
                            .foregroundStyle(newName.isEmpty ? .secondary : .primary)
                    }
                }
            }
            .navigationTitle(editingCategory == nil ? "New Category" : "Edit Category")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { showingAddCategory = false }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Save") {
                        saveCategory()
                        showingAddCategory = false
                    }
                    .disabled(newName.trimmingCharacters(in: .whitespaces).isEmpty)
                    .fontWeight(.semibold)
                }
            }
        }
    }

    private func saveCategory() {
        if let existing = editingCategory {
            existing.name = newName.sanitized
            existing.iconName = newIcon
            existing.colorHex = newColor
            existing.updatedAt = Date()
        } else {
            let category = CategoryEntity(name: newName.sanitized, iconName: newIcon, colorHex: newColor)
            modelContext.insert(category)
        }
        try? modelContext.save()
    }
}
