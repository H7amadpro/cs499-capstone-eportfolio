//
//  AuditLogView.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//

import SwiftUI
import SwiftData

struct AuditLogView: View {
    
    @Environment(\.modelContext) private var modelContext
    @Query(sort: \AuditLogEntry.timestamp, order: .reverse) private var entries: [AuditLogEntry]
    @State private var filterAction: AuditAction?
    @State private var searchText = ""
    
    private var filteredEntries: [AuditLogEntry] {
        var result = entries
        if let action = filterAction {
            result = result.filter { $0.action == action.rawValue }
        }
        if !searchText.isEmpty {
            let query = searchText.lowercased()
            result = result.filter {
                $0.entityName.lowercased().contains(query) ||
                $0.action.lowercased().contains(query)
            }
        }
        return result
    }
    
    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                // Filter bar
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 8) {
                        FilterChip(title: "All", isSelected: filterAction == nil) {
                            filterAction = nil
                        }
                        ForEach(AuditAction.allCases) { action in
                            FilterChip(title: action.rawValue, isSelected: filterAction == action) {
                                filterAction = action
                            }
                        }
                    }
                    .padding(.horizontal)
                    .padding(.vertical, 8)
                }
                .background(Color(.systemGroupedBackground))
                
                if filteredEntries.isEmpty {
                    VStack(spacing: 12) {
                        Spacer()
                        Image(systemName: "clock")
                            .font(.system(size: 50))
                            .foregroundStyle(.secondary)
                        Text("No Activity")
                            .font(.title3)
                            .fontWeight(.semibold)
                        Text("Actions will appear here as you manage inventory")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                            .multilineTextAlignment(.center)
                        Spacer()
                    }
                    .padding()
                } else {
                    List(filteredEntries) { entry in
                        HStack(spacing: 12) {
                            Image(systemName: entry.auditAction.iconName)
                                .foregroundStyle(iconColor(for: entry.auditAction))
                                .font(.title3)
                                .frame(width: 32)
                            
                            VStack(alignment: .leading, spacing: 4) {
                                HStack {
                                    Text(entry.auditAction.rawValue)
                                        .font(.subheadline)
                                        .fontWeight(.medium)
                                    Text("•")
                                        .foregroundStyle(.secondary)
                                    Text(entry.entityType)
                                        .font(.caption)
                                        .foregroundStyle(.secondary)
                                }
                                
                                Text(entry.entityName)
                                    .font(.body)
                                
                                if let newVal = entry.newValue, !newVal.isEmpty {
                                    Text(newVal)
                                        .font(.caption)
                                        .foregroundStyle(.secondary)
                                }
                                
                                Text(entry.timestamp, style: .relative)
                                    .font(.caption2)
                                    .foregroundStyle(.tertiary)
                            }
                        }
                        .padding(.vertical, 4)
                    }
                    .listStyle(.plain)
                }
            }
            .navigationTitle("Activity")
            .searchable(text: $searchText, prompt: "Search activity...")
        }
    }
    
    private func iconColor(for action: AuditAction) -> Color {
        switch action {
        case .create: return .green
        case .update: return .blue
        case .delete: return .red
        case .quantityIncrease: return .green
        case .quantityDecrease: return .orange
        case .export: return .purple
        case .login: return .teal
        case .logout: return .gray
        case .transfer: return .indigo
        case .backup: return .cyan
        case .restore: return .mint
        }
    }
}
