//
//  BranchListView.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//

import SwiftUI
import SwiftData

struct BranchListView: View {

    @Environment(\.modelContext) private var modelContext
    @Query(sort: \Branch.name) private var branches: [Branch]
    @State private var showingAddBranch = false
    @State private var editingBranch: Branch?
    @State private var branchToDelete: Branch?
    @State private var showingDeleteConfirmation = false

    var body: some View {
        List {
            ForEach(branches) { branch in
                NavigationLink(destination: BranchDetailView(branch: branch)) {
                    branchRow(branch)
                }
                .swipeActions(edge: .trailing) {
                    if !branch.isDefault {
                        Button(role: .destructive) {
                            branchToDelete = branch
                            showingDeleteConfirmation = true
                        } label: {
                            Label("Delete", systemImage: "trash")
                        }
                    }
                }
                .swipeActions(edge: .leading) {
                    Button {
                        editingBranch = branch
                    } label: {
                        Label("Edit", systemImage: "pencil")
                    }
                    .tint(.blue)
                }
            }
        }
        .listStyle(.insetGrouped)
        .navigationTitle("Branches")
        .toolbar {
            ToolbarItem(placement: .primaryAction) {
                Button { showingAddBranch = true } label: {
                    Image(systemName: "plus")
                }
            }
        }
        .sheet(isPresented: $showingAddBranch) {
            AddBranchSheet()
        }
        .sheet(item: $editingBranch) { branch in
            AddBranchSheet(editing: branch)
        }
        .alert("Delete Branch?", isPresented: $showingDeleteConfirmation) {
            Button("Delete", role: .destructive) {
                if let branch = branchToDelete {
                    modelContext.delete(branch)
                    try? modelContext.save()
                }
            }
            Button("Cancel", role: .cancel) {}
        } message: {
            Text("Items in this branch will become unassigned. This cannot be undone.")
        }
    }

    private func branchRow(_ branch: Branch) -> some View {
        HStack(spacing: 12) {
            ZStack {
                Circle()
                    .fill(Color.blue.opacity(0.15))
                    .frame(width: 44, height: 44)
                Image(systemName: "building.2.fill")
                    .foregroundStyle(.blue)
            }

            VStack(alignment: .leading, spacing: 4) {
                HStack {
                    Text(branch.name)
                        .font(.body)
                        .fontWeight(.medium)
                    if branch.isDefault {
                        Text("Default")
                            .font(.caption2)
                            .padding(.horizontal, 6)
                            .padding(.vertical, 2)
                            .background(Color.blue.opacity(0.15))
                            .clipShape(Capsule())
                    }
                    if !branch.isActive {
                        Text("Inactive")
                            .font(.caption2)
                            .padding(.horizontal, 6)
                            .padding(.vertical, 2)
                            .background(Color.red.opacity(0.15))
                            .clipShape(Capsule())
                    }
                }
                if let address = branch.address, !address.isEmpty {
                    Text(address)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                }
                HStack(spacing: 12) {
                    Label("\(branch.itemCount) items", systemImage: "cube.box")
                    Label(branch.formattedTotalValue, systemImage: "dollarsign.circle")
                }
                .font(.caption)
                .foregroundStyle(.secondary)
            }
        }
        .padding(.vertical, 4)
    }
}

// MARK: - Add/Edit Branch Sheet

struct AddBranchSheet: View {

    @Environment(\.modelContext) private var modelContext
    @Environment(\.dismiss) private var dismiss

    let editingBranch: Branch?

    @State private var name = ""
    @State private var address = ""
    @State private var phone = ""
    @State private var email = ""
    @State private var isDefault = false

    init(editing branch: Branch? = nil) {
        self.editingBranch = branch
        if let branch = branch {
            _name = State(initialValue: branch.name)
            _address = State(initialValue: branch.address ?? "")
            _phone = State(initialValue: branch.phone ?? "")
            _email = State(initialValue: branch.email ?? "")
            _isDefault = State(initialValue: branch.isDefault)
        }
    }

    var body: some View {
        NavigationStack {
            Form {
                Section("Branch Info") {
                    TextField("Branch Name *", text: $name)
                    TextField("Address", text: $address)
                    TextField("Phone", text: $phone)
                        .keyboardType(.phonePad)
                    TextField("Email", text: $email)
                        .keyboardType(.emailAddress)
                        .textInputAutocapitalization(.never)
                }

                Section {
                    Toggle("Default Branch", isOn: $isDefault)
                } footer: {
                    Text("New items will be assigned to the default branch automatically")
                }
            }
            .navigationTitle(editingBranch != nil ? "Edit Branch" : "Add Branch")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button(editingBranch != nil ? "Save" : "Add") {
                        saveBranch()
                    }
                    .fontWeight(.semibold)
                    .disabled(name.trimmingCharacters(in: .whitespaces).isEmpty)
                }
            }
        }
    }

    private func saveBranch() {
        if let existing = editingBranch {
            existing.name = name.sanitized
            existing.address = address.isEmpty ? nil : address
            existing.phone = phone.isEmpty ? nil : phone
            existing.email = email.isEmpty ? nil : email
            existing.isDefault = isDefault
            existing.updatedAt = Date()
        } else {
            let branch = Branch(
                name: name.sanitized,
                address: address.isEmpty ? nil : address,
                phone: phone.isEmpty ? nil : phone,
                email: email.isEmpty ? nil : email,
                isDefault: isDefault
            )
            modelContext.insert(branch)
        }

        // If this is default, unset other defaults
        if isDefault {
            let descriptor = FetchDescriptor<Branch>()
            if let allBranches = try? modelContext.fetch(descriptor) {
                for br in allBranches where br.name != name.sanitized {
                    br.isDefault = false
                }
            }
        }

        try? modelContext.save()
        dismiss()
    }
}
