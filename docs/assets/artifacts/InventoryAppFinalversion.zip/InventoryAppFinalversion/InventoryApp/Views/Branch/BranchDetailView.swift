//
//  BranchDetailView.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//

import SwiftUI
import SwiftData

struct BranchDetailView: View {

    let branch: Branch
    @Query(sort: \Item.name) private var allItems: [Item]

    private var branchItems: [Item] {
        allItems.filter { $0.branch?.id == branch.id }
    }

    var body: some View {
        List {
            // Branch Info
            Section("Branch Info") {
                HStack {
                    Label("Name", systemImage: "building.2")
                    Spacer()
                    Text(branch.name)
                        .foregroundStyle(.secondary)
                }
                if let address = branch.address, !address.isEmpty {
                    HStack {
                        Label("Address", systemImage: "mappin.circle")
                        Spacer()
                        Text(address)
                            .foregroundStyle(.secondary)
                    }
                }
                if let phone = branch.phone, !phone.isEmpty {
                    HStack {
                        Label("Phone", systemImage: "phone")
                        Spacer()
                        Text(phone)
                            .foregroundStyle(.secondary)
                    }
                }
                if let email = branch.email, !email.isEmpty {
                    HStack {
                        Label("Email", systemImage: "envelope")
                        Spacer()
                        Text(email)
                            .foregroundStyle(.secondary)
                    }
                }
            }

            // Statistics
            Section("Statistics") {
                HStack {
                    Label("Total Items", systemImage: "cube.box")
                    Spacer()
                    Text("\(branchItems.count)")
                        .fontWeight(.semibold)
                }
                HStack {
                    Label("Total Value", systemImage: "dollarsign.circle")
                    Spacer()
                    Text(String(format: "$%.2f", branchItems.reduce(0) { $0 + $1.totalValue }))
                        .fontWeight(.semibold)
                        .foregroundStyle(.green)
                }
                HStack {
                    Label("Low Stock", systemImage: "exclamationmark.triangle")
                    Spacer()
                    Text("\(branchItems.filter(\.isLowStock).count)")
                        .foregroundStyle(.orange)
                }
            }

            // Items
            Section("Items (\(branchItems.count))") {
                if branchItems.isEmpty {
                    Text("No items in this branch")
                        .foregroundStyle(.secondary)
                } else {
                    ForEach(branchItems) { item in
                        NavigationLink(destination: ItemDetailView(item: item)) {
                            HStack {
                                Image(systemName: item.categoryIconName)
                                    .foregroundStyle(Color(hex: item.category?.colorHex ?? "#8E8E93"))
                                    .frame(width: 24)
                                VStack(alignment: .leading) {
                                    Text(item.name)
                                        .font(.subheadline)
                                    Text("Qty: \(item.quantity)")
                                        .font(.caption)
                                        .foregroundStyle(.secondary)
                                }
                                Spacer()
                                Text(item.formattedTotalValue)
                                    .font(.subheadline)
                                    .foregroundStyle(.secondary)
                            }
                        }
                    }
                }
            }
        }
        .listStyle(.insetGrouped)
        .navigationTitle(branch.name)
        .navigationBarTitleDisplayMode(.inline)
    }
}
