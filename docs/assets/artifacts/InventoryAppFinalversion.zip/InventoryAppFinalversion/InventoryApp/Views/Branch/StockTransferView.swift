//
//  StockTransferView.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//

import SwiftUI
import SwiftData

struct StockTransferView: View {

    @EnvironmentObject var authService: AuthenticationService
    @Environment(\.modelContext) private var modelContext
    @Environment(\.dismiss) private var dismiss
    @Query(sort: \Branch.name) private var branches: [Branch]
    @Query(sort: \Item.name) private var items: [Item]

    @State private var selectedFromBranch: Branch?
    @State private var selectedToBranch: Branch?
    @State private var selectedItem: Item?
    @State private var quantityString = ""
    @State private var notes = ""
    @State private var errorMessage: String?
    @State private var showingError = false
    @State private var showingSuccess = false

    private var activeBranches: [Branch] {
        branches.filter(\.isActive)
    }

    private var availableItems: [Item] {
        guard let fromBranch = selectedFromBranch else { return [] }
        return items.filter { $0.branch?.id == fromBranch.id && $0.quantity > 0 }
    }

    private var transferQuantity: Int {
        Int(quantityString) ?? 0
    }

    private var canTransfer: Bool {
        selectedFromBranch != nil &&
        selectedToBranch != nil &&
        selectedItem != nil &&
        selectedFromBranch?.id != selectedToBranch?.id &&
        transferQuantity > 0 &&
        transferQuantity <= (selectedItem?.quantity ?? 0)
    }

    var body: some View {
        NavigationStack {
            Form {
                // Source
                Section("From") {
                    Picker("Source Branch", selection: $selectedFromBranch) {
                        Text("Select Branch").tag(nil as Branch?)
                        ForEach(activeBranches) { branch in
                            Text(branch.name).tag(branch as Branch?)
                        }
                    }
                    .onChange(of: selectedFromBranch) { _ in
                        selectedItem = nil
                    }
                }

                // Item Selection
                Section("Item") {
                    if selectedFromBranch == nil {
                        Text("Select a source branch first")
                            .foregroundStyle(.secondary)
                    } else if availableItems.isEmpty {
                        Text("No items available in this branch")
                            .foregroundStyle(.secondary)
                    } else {
                        Picker("Item", selection: $selectedItem) {
                            Text("Select Item").tag(nil as Item?)
                            ForEach(availableItems) { item in
                                HStack {
                                    Text(item.name)
                                    Text("(Qty: \(item.quantity))")
                                        .foregroundStyle(.secondary)
                                }
                                .tag(item as Item?)
                            }
                        }
                    }
                }

                // Destination
                Section("To") {
                    Picker("Destination Branch", selection: $selectedToBranch) {
                        Text("Select Branch").tag(nil as Branch?)
                        ForEach(activeBranches.filter { $0.id != selectedFromBranch?.id }) { branch in
                            Text(branch.name).tag(branch as Branch?)
                        }
                    }
                }

                // Quantity
                Section("Transfer Details") {
                    HStack {
                        Text("Quantity")
                        Spacer()
                        TextField("0", text: $quantityString)
                            .keyboardType(.numberPad)
                            .multilineTextAlignment(.trailing)
                            .frame(width: 100)
                    }
                    if let item = selectedItem {
                        Text("Available: \(item.quantity)")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    TextField("Notes (optional)", text: $notes, axis: .vertical)
                        .lineLimit(2...4)
                }

                // Summary
                if canTransfer {
                    Section("Summary") {
                        HStack {
                            Image(systemName: "arrow.right.circle.fill")
                                .foregroundStyle(.blue)
                            Text("Transfer \(transferQuantity) x \(selectedItem?.name ?? "") from \(selectedFromBranch?.name ?? "") to \(selectedToBranch?.name ?? "")")
                                .font(.subheadline)
                        }
                    }
                }
            }
            .navigationTitle("Stock Transfer")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Transfer") {
                        executeTransfer()
                    }
                    .fontWeight(.semibold)
                    .disabled(!canTransfer)
                }
            }
            .alert("Error", isPresented: $showingError) {
                Button("OK") {}
            } message: {
                Text(errorMessage ?? "Transfer failed")
            }
            .alert("Transfer Complete", isPresented: $showingSuccess) {
                Button("Done") { dismiss() }
            } message: {
                Text("Stock has been transferred successfully.")
            }
        }
    }

    private func executeTransfer() {
        guard let item = selectedItem,
              let fromBranch = selectedFromBranch,
              let toBranch = selectedToBranch else { return }

        guard transferQuantity <= item.quantity else {
            errorMessage = "Cannot transfer more than available quantity"
            showingError = true
            return
        }

        // Create transfer record
        let transfer = StockTransfer(
            item: item,
            fromBranch: fromBranch,
            toBranch: toBranch,
            quantity: transferQuantity,
            initiatedBy: authService.currentUser,
            notes: notes.isEmpty ? nil : notes
        )
        transfer.complete()
        modelContext.insert(transfer)

        // Adjust quantity - reduce from source
        let oldQty = item.quantity
        item.quantity -= transferQuantity
        item.updatedAt = Date()

        // Create a duplicate item in the destination branch or find existing
        let existingInDest = items.first {
            $0.name == item.name && $0.branch?.id == toBranch.id && $0.id != item.id
        }

        if let existing = existingInDest {
            existing.quantity += transferQuantity
            existing.updatedAt = Date()
        } else {
            let newItem = Item(
                name: item.name,
                itemDescription: item.itemDescription,
                quantity: transferQuantity,
                minimumQuantity: item.minimumQuantity,
                maximumQuantity: item.maximumQuantity,
                price: item.price,
                barcode: item.barcode,
                location: item.location,
                notes: item.notes,
                tags: item.tags,
                expirationDate: item.expirationDate,
                category: item.category,
                branch: toBranch,
                supplier: item.supplier
            )
            modelContext.insert(newItem)
        }

        // Audit log
        let audit = AuditService(modelContext: modelContext, currentUser: authService.currentUser)
        audit.logTransfer(item: item, fromBranch: fromBranch, toBranch: toBranch, quantity: transferQuantity)

        try? modelContext.save()
        showingSuccess = true
    }
}
