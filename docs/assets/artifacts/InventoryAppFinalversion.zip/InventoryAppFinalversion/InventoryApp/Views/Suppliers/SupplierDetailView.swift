//
//  SupplierDetailView.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//

import SwiftUI
import SwiftData

struct SupplierDetailView: View {

    let supplier: Supplier
    @Query(sort: \Item.name) private var allItems: [Item]

    private var supplierItems: [Item] {
        allItems.filter { $0.supplier?.id == supplier.id }
    }

    var body: some View {
        List {
            // Contact Info
            Section("Contact Information") {
                if let contact = supplier.contactPerson, !contact.isEmpty {
                    HStack {
                        Label("Contact", systemImage: "person")
                        Spacer()
                        Text(contact)
                            .foregroundStyle(.secondary)
                    }
                }
                if let email = supplier.email, !email.isEmpty {
                    HStack {
                        Label("Email", systemImage: "envelope")
                        Spacer()
                        Text(email)
                            .foregroundStyle(.secondary)
                    }
                }
                if let phone = supplier.phone, !phone.isEmpty {
                    HStack {
                        Label("Phone", systemImage: "phone")
                        Spacer()
                        Text(phone)
                            .foregroundStyle(.secondary)
                    }
                }
                if let address = supplier.address, !address.isEmpty {
                    VStack(alignment: .leading, spacing: 4) {
                        Label("Address", systemImage: "mappin.circle")
                        Text(address)
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                    }
                }
            }

            // Statistics
            Section("Statistics") {
                HStack {
                    Label("Items Supplied", systemImage: "cube.box")
                    Spacer()
                    Text("\(supplierItems.count)")
                        .fontWeight(.semibold)
                }
                HStack {
                    Label("Total Value", systemImage: "dollarsign.circle")
                    Spacer()
                    Text(String(format: "$%.2f", supplierItems.reduce(0) { $0 + $1.totalValue }))
                        .fontWeight(.semibold)
                        .foregroundStyle(.green)
                }
            }

            // Notes
            if let notes = supplier.notes, !notes.isEmpty {
                Section("Notes") {
                    Text(notes)
                        .font(.subheadline)
                }
            }

            // Items
            Section("Items (\(supplierItems.count))") {
                if supplierItems.isEmpty {
                    Text("No items from this supplier")
                        .foregroundStyle(.secondary)
                } else {
                    ForEach(supplierItems) { item in
                        NavigationLink(destination: ItemDetailView(item: item)) {
                            HStack {
                                Image(systemName: item.categoryIconName)
                                    .foregroundStyle(Color(hex: item.category?.colorHex ?? "#8E8E93"))
                                    .frame(width: 24)
                                VStack(alignment: .leading) {
                                    Text(item.name)
                                        .font(.subheadline)
                                    Text("Qty: \(item.quantity) | \(item.branchName)")
                                        .font(.caption)
                                        .foregroundStyle(.secondary)
                                }
                                Spacer()
                                Text(item.formattedTotalValue)
                                    .font(.subheadline)
                                    .foregroundStyle(.secondary)
                            }
                        }
                    }
                }
            }

            // Timestamps
            Section("History") {
                HStack {
                    Label("Added", systemImage: "calendar.badge.plus")
                    Spacer()
                    Text(supplier.createdAt, style: .date)
                        .foregroundStyle(.secondary)
                }
                HStack {
                    Label("Modified", systemImage: "calendar.badge.clock")
                    Spacer()
                    Text(supplier.updatedAt, style: .date)
                        .foregroundStyle(.secondary)
                }
            }
        }
        .listStyle(.insetGrouped)
        .navigationTitle(supplier.name)
        .navigationBarTitleDisplayMode(.inline)
    }
}
