//
//  SupplierListView.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//

import SwiftUI
import SwiftData

struct SupplierListView: View {

    @EnvironmentObject var authService: AuthenticationService
    @Environment(\.modelContext) private var modelContext
    @Query(sort: \Supplier.name) private var suppliers: [Supplier]
    @StateObject private var viewModel = SupplierViewModel()

    private var filteredSuppliers: [Supplier] {
        viewModel.filtered(suppliers)
    }

    var body: some View {
        NavigationStack {
            Group {
                if filteredSuppliers.isEmpty {
                    emptyState
                } else {
                    supplierList
                }
            }
            .navigationTitle("Suppliers")
            .searchable(text: $viewModel.searchText, prompt: "Search suppliers...")
            .toolbar {
                if authService.hasPermission(\.canManageSuppliers) {
                    ToolbarItem(placement: .primaryAction) {
                        Button { viewModel.showingAddSupplier = true } label: {
                            Image(systemName: "plus")
                        }
                    }
                }
            }
            .sheet(isPresented: $viewModel.showingAddSupplier) {
                AddSupplierView()
            }
            .alert("Delete Supplier?", isPresented: $viewModel.showingDeleteConfirmation) {
                Button("Delete", role: .destructive) {
                    if let supplier = viewModel.supplierToDelete {
                        viewModel.deleteSupplier(supplier, context: modelContext)
                    }
                }
                Button("Cancel", role: .cancel) {}
            } message: {
                Text("Items linked to this supplier will become unlinked. This cannot be undone.")
            }
        }
    }

    private var supplierList: some View {
        List {
            Section {
                Text("\(filteredSuppliers.count) suppliers")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }

            Section {
                ForEach(filteredSuppliers) { supplier in
                    NavigationLink(destination: SupplierDetailView(supplier: supplier)) {
                        supplierRow(supplier)
                    }
                    .swipeActions(edge: .trailing) {
                        if authService.hasPermission(\.canManageSuppliers) {
                            Button(role: .destructive) {
                                viewModel.supplierToDelete = supplier
                                viewModel.showingDeleteConfirmation = true
                            } label: {
                                Label("Delete", systemImage: "trash")
                            }
                        }
                    }
                }
            }
        }
        .listStyle(.insetGrouped)
    }

    private func supplierRow(_ supplier: Supplier) -> some View {
        HStack(spacing: 12) {
            ZStack {
                Circle()
                    .fill(Color.purple.opacity(0.15))
                    .frame(width: 44, height: 44)
                Image(systemName: "building.2.fill")
                    .foregroundStyle(.purple)
            }

            VStack(alignment: .leading, spacing: 4) {
                Text(supplier.name)
                    .font(.body)
                    .fontWeight(.medium)
                if let contact = supplier.contactPerson, !contact.isEmpty {
                    Text(contact)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                HStack(spacing: 12) {
                    Label("\(supplier.itemCount) items", systemImage: "cube.box")
                    if let email = supplier.email, !email.isEmpty {
                        Label(email, systemImage: "envelope")
                            .lineLimit(1)
                    }
                }
                .font(.caption)
                .foregroundStyle(.secondary)
            }
        }
        .padding(.vertical, 4)
    }

    private var emptyState: some View {
        VStack(spacing: 16) {
            Spacer()
            Image(systemName: "building.2")
                .font(.system(size: 60))
                .foregroundStyle(.secondary)
            Text("No Suppliers")
                .font(.title2)
                .fontWeight(.semibold)
            Text("Add suppliers to track where your inventory comes from")
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
            if authService.hasPermission(\.canManageSuppliers) {
                Button {
                    viewModel.showingAddSupplier = true
                } label: {
                    Label("Add Supplier", systemImage: "plus")
                        .padding(.horizontal, 20)
                        .padding(.vertical, 10)
                }
                .buttonStyle(.borderedProminent)
            }
            Spacer()
        }
        .padding()
    }
}
