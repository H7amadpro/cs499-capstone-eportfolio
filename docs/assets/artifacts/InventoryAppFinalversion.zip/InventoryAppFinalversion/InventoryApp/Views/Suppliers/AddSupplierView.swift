//
//  AddSupplierView.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//

import SwiftUI
import SwiftData

struct AddSupplierView: View {

    @Environment(\.modelContext) private var modelContext
    @Environment(\.dismiss) private var dismiss

    let editingSupplier: Supplier?

    @State private var name = ""
    @State private var contactPerson = ""
    @State private var email = ""
    @State private var phone = ""
    @State private var address = ""
    @State private var notes = ""

    init(editing supplier: Supplier? = nil) {
        self.editingSupplier = supplier
        if let supplier = supplier {
            _name = State(initialValue: supplier.name)
            _contactPerson = State(initialValue: supplier.contactPerson ?? "")
            _email = State(initialValue: supplier.email ?? "")
            _phone = State(initialValue: supplier.phone ?? "")
            _address = State(initialValue: supplier.address ?? "")
            _notes = State(initialValue: supplier.notes ?? "")
        }
    }

    var body: some View {
        NavigationStack {
            Form {
                Section("Supplier Info") {
                    TextField("Supplier Name *", text: $name)
                    TextField("Contact Person", text: $contactPerson)
                }

                Section("Contact Details") {
                    TextField("Email", text: $email)
                        .keyboardType(.emailAddress)
                        .textInputAutocapitalization(.never)
                    TextField("Phone", text: $phone)
                        .keyboardType(.phonePad)
                    TextField("Address", text: $address, axis: .vertical)
                        .lineLimit(2...4)
                }

                Section("Notes") {
                    TextField("Additional notes...", text: $notes, axis: .vertical)
                        .lineLimit(3...6)
                }
            }
            .navigationTitle(editingSupplier != nil ? "Edit Supplier" : "Add Supplier")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button(editingSupplier != nil ? "Save" : "Add") {
                        saveSupplier()
                    }
                    .fontWeight(.semibold)
                    .disabled(name.trimmingCharacters(in: .whitespaces).isEmpty)
                }
            }
        }
    }

    private func saveSupplier() {
        let sanitizedName = name.sanitized

        if let existing = editingSupplier {
            existing.name = sanitizedName
            existing.contactPerson = contactPerson.isEmpty ? nil : contactPerson
            existing.email = email.isEmpty ? nil : email
            existing.phone = phone.isEmpty ? nil : phone
            existing.address = address.isEmpty ? nil : address
            existing.notes = notes.isEmpty ? nil : notes
            existing.updatedAt = Date()
        } else {
            let supplier = Supplier(
                name: sanitizedName,
                contactPerson: contactPerson.isEmpty ? nil : contactPerson,
                email: email.isEmpty ? nil : email,
                phone: phone.isEmpty ? nil : phone,
                address: address.isEmpty ? nil : address,
                notes: notes.isEmpty ? nil : notes
            )
            modelContext.insert(supplier)

            let audit = AuditService(modelContext: modelContext)
            audit.log(action: .create, entityType: "Supplier", entityId: supplier.id,
                      entityName: supplier.name)
        }

        try? modelContext.save()
        dismiss()
    }
}
