//
//  BackupRestoreView.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//

import SwiftUI
import SwiftData

struct BackupRestoreView: View {

    @EnvironmentObject var authService: AuthenticationService
    @Environment(\.modelContext) private var modelContext
    @State private var isExporting = false
    @State private var isImporting = false
    @State private var exportURL: URL?
    @State private var showingShareSheet = false
    @State private var showingImportPicker = false
    @State private var showingRestoreConfirmation = false
    @State private var importURL: URL?
    @State private var errorMessage: String?
    @State private var showingError = false
    @State private var showingSuccess = false
    @State private var successMessage = ""

    private var lastBackupDate: Date? {
        let timestamp = UserDefaults.standard.double(forKey: "lastBackupDate")
        return timestamp > 0 ? Date(timeIntervalSince1970: timestamp) : nil
    }

    var body: some View {
        Form {
            // Backup Section
            Section {
                Button {
                    createBackup()
                } label: {
                    HStack {
                        Label("Create Backup", systemImage: "square.and.arrow.up")
                        Spacer()
                        if isExporting {
                            ProgressView()
                        }
                    }
                }
                .disabled(isExporting)

                if let date = lastBackupDate {
                    HStack {
                        Text("Last Backup")
                        Spacer()
                        Text(date, style: .relative)
                            .foregroundStyle(.secondary)
                    }
                }
            } header: {
                Text("Backup")
            } footer: {
                Text("Creates a JSON file containing all inventory data that can be shared or saved")
            }

            // Restore Section
            Section {
                Button {
                    showingImportPicker = true
                } label: {
                    HStack {
                        Label("Restore from Backup", systemImage: "arrow.counterclockwise")
                        Spacer()
                        if isImporting {
                            ProgressView()
                        }
                    }
                }
                .disabled(isImporting)
            } header: {
                Text("Restore")
            } footer: {
                Text("WARNING: Restoring a backup will replace all current inventory data. User accounts will be preserved.")
            }

            // Info
            Section("About Backups") {
                HStack {
                    Image(systemName: "doc.text")
                        .foregroundStyle(.blue)
                        .frame(width: 24)
                    VStack(alignment: .leading, spacing: 2) {
                        Text("What's included")
                            .font(.subheadline)
                        Text("Items, categories, suppliers, branches, and activity log")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                }
                HStack {
                    Image(systemName: "lock.shield")
                        .foregroundStyle(.green)
                        .frame(width: 24)
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Security")
                            .font(.subheadline)
                        Text("User passwords are excluded from backups")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                }
            }
        }
        .navigationTitle("Backup & Restore")
        .navigationBarTitleDisplayMode(.inline)
        .sheet(isPresented: $showingShareSheet) {
            if let url = exportURL {
                ShareSheet(items: [url])
            }
        }
        .fileImporter(
            isPresented: $showingImportPicker,
            allowedContentTypes: [.json],
            allowsMultipleSelection: false
        ) { result in
            handleImportResult(result)
        }
        .alert("Restore Backup?", isPresented: $showingRestoreConfirmation) {
            Button("Restore", role: .destructive) {
                performRestore()
            }
            Button("Cancel", role: .cancel) {}
        } message: {
            Text("This will replace ALL current inventory data with the backup data. This cannot be undone.")
        }
        .alert("Error", isPresented: $showingError) {
            Button("OK") {}
        } message: {
            Text(errorMessage ?? "An error occurred")
        }
        .alert("Success", isPresented: $showingSuccess) {
            Button("OK") {}
        } message: {
            Text(successMessage)
        }
    }

    // MARK: - Backup

    private func createBackup() {
        isExporting = true
        do {
            let url = try BackupService.exportBackup(context: modelContext)
            exportURL = url

            let audit = AuditService(modelContext: modelContext, currentUser: authService.currentUser)
            audit.logBackup()

            showingShareSheet = true
        } catch {
            errorMessage = "Failed to create backup: \(error.localizedDescription)"
            showingError = true
        }
        isExporting = false
    }

    // MARK: - Restore

    private func handleImportResult(_ result: Result<[URL], Error>) {
        switch result {
        case .success(let urls):
            if let url = urls.first {
                importURL = url
                showingRestoreConfirmation = true
            }
        case .failure(let error):
            errorMessage = "Failed to select file: \(error.localizedDescription)"
            showingError = true
        }
    }

    private func performRestore() {
        guard let url = importURL else { return }
        isImporting = true

        do {
            guard url.startAccessingSecurityScopedResource() else {
                throw NSError(domain: "", code: -1, userInfo: [NSLocalizedDescriptionKey: "Cannot access file"])
            }
            defer { url.stopAccessingSecurityScopedResource() }

            try BackupService.importBackup(from: url, context: modelContext)

            let audit = AuditService(modelContext: modelContext, currentUser: authService.currentUser)
            audit.logRestore()

            successMessage = "Backup restored successfully"
            showingSuccess = true
        } catch {
            errorMessage = "Failed to restore: \(error.localizedDescription)"
            showingError = true
        }

        isImporting = false
    }
}

