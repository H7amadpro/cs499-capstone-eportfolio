//
//  CategoryManagementView.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//
//  Category management with full CRUD and large icon selection
//

import SwiftUI
import SwiftData

struct CategoryManagementView: View {
    
    @EnvironmentObject var authService: AuthenticationService
    @Environment(\.modelContext) private var modelContext
    @Query(sort: \CategoryEntity.name) private var categories: [CategoryEntity]
    
    @State private var showingAddCategory = false
    @State private var editingCategory: CategoryEntity?
    @State private var categoryToDelete: CategoryEntity?
    @State private var showingDeleteAlert = false
    @State private var deleteError: String?
    @State private var showingDeleteError = false
    
    // Form state
    @State private var newName = ""
    @State private var newIcon = "square.grid.2x2"
    @State private var newColor = "#007AFF"
    @State private var showingIconPicker = false
    
    // Extended icon options organized by category
    private let iconCategories: [(String, [String])] = [
        ("General", [
            "square.grid.2x2", "folder", "doc", "archivebox", "tray.full",
            "cube.box", "shippingbox", "gift", "tag", "bookmark"
        ]),
        ("Electronics", [
            "laptopcomputer", "desktopcomputer", "display", "keyboard",
            "computermouse", "printer", "tv", "applewatch", "airpods",
            "homepod", "hifispeaker", "headphones", "gamecontroller"
        ]),
        ("Office", [
            "pencil.and.ruler", "pencil", "highlighter", "paperclip",
            "scissors", "doc.text", "clipboard", "calendar", "clock",
            "building.2", "briefcase", "envelope"
        ]),
        ("Furniture", [
            "chair.lounge", "chair", "bed.double", "lamp.desk", "lamp.floor",
            "sofa", "cabinet", "table.furniture"
        ]),
        ("Food & Beverage", [
            "cup.and.saucer", "mug", "fork.knife", "wineglass", "takeoutbag.and.cup.and.straw",
            "cart", "basket", "refrigerator"
        ]),
        ("Clothing & Accessories", [
            "tshirt", "bag", "handbag", "backpack", "suitcase", "eyeglasses",
            "crown"
        ]),
        ("Tools & Hardware", [
            "wrench.and.screwdriver", "hammer", "screwdriver", "wrench",
            "paintbrush", "level", "ruler", "flashlight.on.fill"
        ]),
        ("Health & Safety", [
            "heart", "cross.case", "pills", "bandage", "syringe",
            "stethoscope", "medical.thermometer", "shield.checkered"
        ]),
        ("Nature & Outdoors", [
            "leaf", "tree", "drop", "flame", "sun.max", "moon",
            "cloud", "snowflake", "bolt", "mountain.2"
        ]),
        ("Sports & Recreation", [
            "sportscourt", "figure.run", "bicycle", "football",
            "basketball", "tennisball", "baseball", "volleyball"
        ]),
        ("Transportation", [
            "car", "bus", "tram", "airplane", "ferry", "bicycle",
            "scooter", "truck.box"
        ]),
        ("Symbols", [
            "star", "heart.fill", "flag", "bell", "gear",
            "lightbulb", "questionmark.circle", "exclamationmark.triangle",
            "checkmark.seal", "xmark.seal"
        ])
    ]
    
    private let colorOptions = [
        "#007AFF", "#34C759", "#FF9500", "#FF2D55", "#AF52DE",
        "#8E8E93", "#5856D6", "#FF3B30", "#00C7BE", "#32ADE6",
        "#FFD60A", "#BF5AF2", "#64D2FF", "#30D158", "#FF453A"
    ]
    
    var body: some View {
        List {
            // Categories list
            Section {
                ForEach(categories) { category in
                    categoryRow(category)
                }
            } header: {
                Text("Categories (\(categories.count))")
            } footer: {
                Text("Swipe left to delete, swipe right to edit")
            }
            
            // Add new category
            Section {
                Button {
                    prepareNewCategory()
                    showingAddCategory = true
                } label: {
                    Label("Add New Category", systemImage: "plus.circle.fill")
                }
            }
        }
        .listStyle(.insetGrouped)
        .navigationTitle("Category Management")
        .sheet(isPresented: $showingAddCategory) {
            categoryFormSheet
        }
        .alert("Cannot Delete", isPresented: $showingDeleteError) {
            Button("OK") {}
        } message: {
            Text(deleteError ?? "This category cannot be deleted")
        }
        .alert("Delete Category?", isPresented: $showingDeleteAlert) {
            Button("Delete", role: .destructive) {
                if let cat = categoryToDelete {
                    deleteCategory(cat)
                }
            }
            Button("Cancel", role: .cancel) {}
        } message: {
            if let cat = categoryToDelete {
                Text("Delete \"\(cat.name)\"? Items in this category will become uncategorized.")
            }
        }
    }
    
    // MARK: - Category Row
    
    private func categoryRow(_ category: CategoryEntity) -> some View {
        HStack(spacing: 12) {
            ZStack {
                Circle()
                    .fill(Color(hex: category.colorHex).opacity(0.15))
                    .frame(width: 44, height: 44)
                Image(systemName: category.iconName)
                    .foregroundStyle(Color(hex: category.colorHex))
            }
            
            VStack(alignment: .leading, spacing: 2) {
                Text(category.name)
                    .font(.body)
                    .fontWeight(.medium)
                Text("\(category.itemCount) items")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            
            Spacer()
            
            if category.totalValue > 0 {
                Text(String(format: "$%.2f", category.totalValue))
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }
        }
        .padding(.vertical, 4)
        .swipeActions(edge: .trailing) {
            Button(role: .destructive) {
                categoryToDelete = category
                showingDeleteAlert = true
            } label: {
                Label("Delete", systemImage: "trash")
            }
        }
        .swipeActions(edge: .leading) {
            Button {
                prepareEditCategory(category)
                showingAddCategory = true
            } label: {
                Label("Edit", systemImage: "pencil")
            }
            .tint(.blue)
        }
    }
    
    // MARK: - Category Form Sheet
    
    private var categoryFormSheet: some View {
        NavigationStack {
            Form {
                // Name
                Section("Category Name") {
                    TextField("Enter name", text: $newName)
                        .textInputAutocapitalization(.words)
                }
                
                // Icon selection
                Section {
                    Button {
                        showingIconPicker = true
                    } label: {
                        HStack {
                            Text("Icon")
                                .foregroundStyle(.primary)
                            Spacer()
                            ZStack {
                                Circle()
                                    .fill(Color(hex: newColor).opacity(0.15))
                                    .frame(width: 36, height: 36)
                                Image(systemName: newIcon)
                                    .foregroundStyle(Color(hex: newColor))
                            }
                            Image(systemName: "chevron.right")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                    }
                } header: {
                    Text("Appearance")
                }
                
                // Color selection
                Section("Color") {
                    LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 5), spacing: 12) {
                        ForEach(colorOptions, id: \.self) { color in
                            Button {
                                newColor = color
                            } label: {
                                Circle()
                                    .fill(Color(hex: color))
                                    .frame(width: 40, height: 40)
                                    .overlay {
                                        if newColor == color {
                                            Image(systemName: "checkmark")
                                                .foregroundStyle(.white)
                                                .fontWeight(.bold)
                                        }
                                    }
                            }
                        }
                    }
                    .padding(.vertical, 4)
                }
                
                // Preview
                Section("Preview") {
                    HStack(spacing: 12) {
                        ZStack {
                            Circle()
                                .fill(Color(hex: newColor).opacity(0.15))
                                .frame(width: 44, height: 44)
                            Image(systemName: newIcon)
                                .foregroundStyle(Color(hex: newColor))
                        }
                        Text(newName.isEmpty ? "Category Name" : newName)
                            .foregroundStyle(newName.isEmpty ? .secondary : .primary)
                    }
                }
            }
            .navigationTitle(editingCategory == nil ? "New Category" : "Edit Category")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") {
                        showingAddCategory = false
                    }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Save") {
                        saveCategory()
                        showingAddCategory = false
                    }
                    .disabled(newName.trimmingCharacters(in: .whitespaces).isEmpty)
                    .fontWeight(.semibold)
                }
            }
            .sheet(isPresented: $showingIconPicker) {
                iconPickerSheet
            }
        }
    }
    
    // MARK: - Icon Picker Sheet
    
    private var iconPickerSheet: some View {
        NavigationStack {
            ScrollView {
                LazyVStack(alignment: .leading, spacing: 20) {
                    ForEach(iconCategories, id: \.0) { category, icons in
                        VStack(alignment: .leading, spacing: 12) {
                            Text(category)
                                .font(.headline)
                                .foregroundStyle(.secondary)
                                .padding(.horizontal)
                            
                            LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 5), spacing: 12) {
                                ForEach(icons, id: \.self) { icon in
                                    Button {
                                        newIcon = icon
                                        showingIconPicker = false
                                    } label: {
                                        Image(systemName: icon)
                                            .font(.title2)
                                            .frame(width: 50, height: 50)
                                            .background(newIcon == icon ? Color(hex: newColor).opacity(0.2) : Color(.systemGray6))
                                            .clipShape(RoundedRectangle(cornerRadius: 10))
                                            .foregroundStyle(newIcon == icon ? Color(hex: newColor) : .primary)
                                    }
                                }
                            }
                            .padding(.horizontal)
                        }
                    }
                }
                .padding(.vertical)
            }
            .navigationTitle("Select Icon")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") {
                        showingIconPicker = false
                    }
                }
            }
        }
    }
    
    // MARK: - Actions
    
    private func prepareNewCategory() {
        editingCategory = nil
        newName = ""
        newIcon = "square.grid.2x2"
        newColor = "#007AFF"
    }
    
    private func prepareEditCategory(_ category: CategoryEntity) {
        editingCategory = category
        newName = category.name
        newIcon = category.iconName
        newColor = category.colorHex
    }
    
    private func saveCategory() {
        let trimmedName = newName.trimmingCharacters(in: .whitespaces)
        guard !trimmedName.isEmpty else { return }
        
        if let existing = editingCategory {
            // Update existing
            existing.name = trimmedName
            existing.iconName = newIcon
            existing.colorHex = newColor
            existing.updatedAt = Date()
        } else {
            // Create new
            let category = CategoryEntity(name: trimmedName, iconName: newIcon, colorHex: newColor)
            modelContext.insert(category)
        }
        
        try? modelContext.save()
    }
    
    private func deleteCategory(_ category: CategoryEntity) {
        // Check if it's safe to delete (no items or user confirms)
        if category.itemCount > 0 {
            // Items will become uncategorized, but allow deletion
        }
        
        modelContext.delete(category)
        try? modelContext.save()
    }
}
