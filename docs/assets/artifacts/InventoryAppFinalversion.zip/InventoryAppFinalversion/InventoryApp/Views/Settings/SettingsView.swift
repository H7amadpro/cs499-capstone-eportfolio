//
//  SettingsView.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//

import SwiftUI
import SwiftData

struct SettingsView: View {

    @EnvironmentObject var authService: AuthenticationService
    @Environment(\.modelContext) private var modelContext
    @StateObject private var viewModel = SettingsViewModel()
    @StateObject private var biometricService = BiometricAuthService()
    @State private var showingAbout = false
    @State private var showingEnableAuth = false
    @State private var showingDisableAuth = false
    @State private var showingChangePassword = false
    @State private var currentPassword = ""
    @State private var newPassword = ""
    @State private var confirmPassword = ""
    @State private var passwordError: String?
    @State private var showingPasswordError = false
    @State private var showingPasswordSuccess = false

    var body: some View {
        NavigationStack {
            Form {
                // Account Section
                if authService.authEnabled {
                    Section("Account") {
                        if let user = authService.currentUser {
                            HStack(spacing: 12) {
                                ZStack {
                                    Circle()
                                        .fill(roleColor(user.userRole).opacity(0.15))
                                        .frame(width: 44, height: 44)
                                    Image(systemName: user.userRole.iconName)
                                        .foregroundStyle(roleColor(user.userRole))
                                }
                                VStack(alignment: .leading, spacing: 2) {
                                    Text(user.displayName)
                                        .font(.body)
                                        .fontWeight(.medium)
                                    Text("@\(user.username) \u{2022} \(user.userRole.displayName)")
                                        .font(.caption)
                                        .foregroundStyle(.secondary)
                                }
                            }

                            Button {
                                showingChangePassword = true
                            } label: {
                                Label("Change Password", systemImage: "lock.rotation")
                            }

                            Button(role: .destructive) {
                                authService.logout()
                            } label: {
                                Label("Sign Out", systemImage: "rectangle.portrait.and.arrow.right")
                            }
                        }
                    }
                }

                // Authentication Toggle
                Section("Authentication") {
                    Toggle("Require Sign In", isOn: Binding(
                        get: { authService.authEnabled },
                        set: { newValue in
                            if newValue {
                                showingEnableAuth = true
                            } else {
                                showingDisableAuth = true
                            }
                        }
                    ))
                    Text(authService.authEnabled
                         ? "Users must sign in to access the app"
                         : "App is accessible without signing in")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                // Administration (admin only)
                if authService.hasPermission({ $0.canManageUsers }) {
                    Section("Administration") {
                        NavigationLink {
                            UserManagementView()
                        } label: {
                            Label("User Management", systemImage: "person.2")
                        }
                        NavigationLink {
                            BranchListView()
                        } label: {
                            Label("Branch Management", systemImage: "building.2")
                        }
                        NavigationLink {
                            StockTransferView()
                        } label: {
                            Label("Stock Transfer", systemImage: "arrow.left.arrow.right")
                        }
                    }
                }
                
                // Category Management (Admin and Manager)
                if authService.hasPermission({ $0.canManageCategories }) {
                    Section("Inventory Management") {
                        NavigationLink {
                            CategoryManagementView()
                        } label: {
                            Label("Category Management", systemImage: "folder.badge.gearshape")
                        }
                    }
                }

                // General
                Section("General") {
                    Picker("Default Sort", selection: $viewModel.defaultSortOption) {
                        ForEach(SortOption.allCases) { option in
                            Text(option.rawValue).tag(option)
                        }
                    }

                    HStack {
                        Text("Low Stock Threshold")
                        Spacer()
                        Stepper("\(viewModel.lowStockThreshold)", value: $viewModel.lowStockThreshold, in: 1...100)
                    }
                }

                // Notifications
                Section("Notifications") {
                    Toggle("Low Stock Alerts", isOn: $viewModel.notificationsEnabled)

                    if viewModel.notificationsEnabled {
                        Text("You'll receive notifications when items fall below the low stock threshold")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                }

                // Security
                Section("Security") {
                    if biometricService.isBiometricAvailable {
                        if let user = authService.currentUser {
                            Toggle("\(biometricService.biometricName) Login", isOn: Binding(
                                get: { user.biometricEnabled },
                                set: { newValue in
                                    if newValue {
                                        authService.enableBiometric(for: user, context: modelContext)
                                    } else {
                                        authService.disableBiometric(for: user, context: modelContext)
                                    }
                                }
                            ))
                            Text("Use \(biometricService.biometricName) to sign in quickly")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        } else {
                            Toggle("\(biometricService.biometricName) Lock", isOn: $viewModel.biometricEnabled)
                            Text("Require \(biometricService.biometricName) to access the app")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                    } else {
                        Text("Biometric authentication is not available on this device")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                    }
                }

                // Data
                Section("Data Management") {
                    NavigationLink {
                        BackupRestoreView()
                    } label: {
                        Label("Backup & Restore", systemImage: "externaldrive")
                    }
                }

                // About
                Section("About") {
                    HStack {
                        Text("Version")
                        Spacer()
                        Text("\(viewModel.appVersion) (\(viewModel.buildNumber))")
                            .foregroundStyle(.secondary)
                    }
                    HStack {
                        Text("Developer")
                        Spacer()
                        Text("Hamad Alghaithi")
                            .foregroundStyle(.secondary)
                    }
                    HStack {
                        Text("Course")
                        Spacer()
                        Text("CS 499 Capstone")
                            .foregroundStyle(.secondary)
                    }
                    HStack {
                        Text("Institution")
                        Spacer()
                        Text("SNHU")
                            .foregroundStyle(.secondary)
                    }
                }

                // Technical Info
                Section("Technical") {
                    HStack {
                        Text("Architecture")
                        Spacer()
                        Text("MVVM")
                            .foregroundStyle(.secondary)
                    }
                    HStack {
                        Text("Database")
                        Spacer()
                        Text("SwiftData")
                            .foregroundStyle(.secondary)
                    }
                    HStack {
                        Text("UI Framework")
                        Spacer()
                        Text("SwiftUI")
                            .foregroundStyle(.secondary)
                    }
                    HStack {
                        Text("Min iOS")
                        Spacer()
                        Text("17.0")
                            .foregroundStyle(.secondary)
                    }
                }
            }
            .navigationTitle("Settings")
            .alert("Enable Authentication?", isPresented: $showingEnableAuth) {
                Button("Enable") {
                    authService.authEnabled = true
                }
                Button("Cancel", role: .cancel) {}
            } message: {
                Text("This will require all users to sign in. The first user to sign up will become the admin.")
            }
            .alert("Disable Authentication?", isPresented: $showingDisableAuth) {
                Button("Disable", role: .destructive) {
                    authService.authEnabled = false
                }
                Button("Cancel", role: .cancel) {}
            } message: {
                Text("Anyone will be able to access the app without signing in. User accounts will be preserved.")
            }
            .sheet(isPresented: $showingChangePassword) {
                changePasswordSheet
            }
            .alert("Error", isPresented: $showingPasswordError) {
                Button("OK") {}
            } message: {
                Text(passwordError ?? "An error occurred")
            }
            .alert("Success", isPresented: $showingPasswordSuccess) {
                Button("OK") {}
            } message: {
                Text("Password changed successfully")
            }
        }
    }

    // MARK: - Change Password Sheet

    private var changePasswordSheet: some View {
        NavigationStack {
            Form {
                Section("Current Password") {
                    SecureField("Enter current password", text: $currentPassword)
                }
                Section("New Password") {
                    SecureField("New password (min 6 characters)", text: $newPassword)
                    SecureField("Confirm new password", text: $confirmPassword)
                }
            }
            .navigationTitle("Change Password")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") {
                        resetPasswordFields()
                        showingChangePassword = false
                    }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Save") {
                        changePassword()
                    }
                    .fontWeight(.semibold)
                    .disabled(currentPassword.isEmpty || newPassword.count < 6 || newPassword != confirmPassword)
                }
            }
        }
    }

    private func changePassword() {
        guard let user = authService.currentUser else { return }

        let currentHash = AuthenticationService.hashPassword(currentPassword, salt: user.passwordSalt)
        guard currentHash == user.passwordHash else {
            passwordError = "Current password is incorrect"
            showingPasswordError = true
            return
        }

        guard newPassword == confirmPassword else {
            passwordError = "New passwords do not match"
            showingPasswordError = true
            return
        }

        let newSalt = AuthenticationService.generateSalt()
        user.passwordSalt = newSalt
        user.passwordHash = AuthenticationService.hashPassword(newPassword, salt: newSalt)
        user.updatedAt = Date()
        try? modelContext.save()

        resetPasswordFields()
        showingChangePassword = false
        showingPasswordSuccess = true
    }

    private func resetPasswordFields() {
        currentPassword = ""
        newPassword = ""
        confirmPassword = ""
        passwordError = nil
    }

    private func roleColor(_ role: UserRole) -> Color {
        switch role {
        case .admin: return .red
        case .manager: return .orange
        case .staff: return .blue
        case .viewer: return .gray
        }
    }
}
