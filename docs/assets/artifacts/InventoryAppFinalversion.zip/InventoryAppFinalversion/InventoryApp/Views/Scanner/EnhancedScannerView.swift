//
//  EnhancedScannerView.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//

import SwiftUI
import AVFoundation

struct EnhancedScannerView: View {

    @Binding var scannedCode: String?
    @Binding var isPresented: Bool
    var onCodeScanned: ((String) -> Void)?

    @State private var detectedCode: String?
    @State private var isFlashlightOn = false

    var body: some View {
        ZStack {
            // Camera preview
            BarcodeScannerView(scannedCode: $detectedCode, isPresented: $isPresented)
                .ignoresSafeArea()

            // Dark overlay with viewfinder cutout
            scannerOverlay

            // UI Controls
            VStack {
                topBar

                Spacer()

                // Detected code display
                if let code = detectedCode {
                    detectedCodeBanner(code)
                }

                bottomInstructions
            }
        }
        .onChange(of: detectedCode) { _, newCode in
            if let code = newCode {
                scannedCode = code
                onCodeScanned?(code)
            }
        }
        .statusBarHidden()
    }

    // MARK: - Scanner Overlay

    private var scannerOverlay: some View {
        GeometryReader { geo in
            let size = min(geo.size.width * 0.7, 280.0)
            let centerX = geo.size.width / 2
            let centerY = geo.size.height / 2

            ZStack {
                // Semi-transparent background
                Color.black.opacity(0.5)
                    .ignoresSafeArea()

                // Clear cutout
                RoundedRectangle(cornerRadius: 16)
                    .frame(width: size, height: size)
                    .blendMode(.destinationOut)
            }
            .compositingGroup()

            // Viewfinder border
            RoundedRectangle(cornerRadius: 16)
                .stroke(Color.white, lineWidth: 3)
                .frame(width: size, height: size)
                .position(x: centerX, y: centerY)

            // Corner accents
            let cornerLength: CGFloat = 30
            let cornerWeight: CGFloat = 5
            let halfSize = size / 2
            let offset: CGFloat = 1.5

            // Top-left
            Path { path in
                path.move(to: CGPoint(x: centerX - halfSize + offset, y: centerY - halfSize + cornerLength))
                path.addLine(to: CGPoint(x: centerX - halfSize + offset, y: centerY - halfSize + offset))
                path.addLine(to: CGPoint(x: centerX - halfSize + cornerLength, y: centerY - halfSize + offset))
            }
            .stroke(Color.blue, lineWidth: cornerWeight)

            // Top-right
            Path { path in
                path.move(to: CGPoint(x: centerX + halfSize - cornerLength, y: centerY - halfSize + offset))
                path.addLine(to: CGPoint(x: centerX + halfSize - offset, y: centerY - halfSize + offset))
                path.addLine(to: CGPoint(x: centerX + halfSize - offset, y: centerY - halfSize + cornerLength))
            }
            .stroke(Color.blue, lineWidth: cornerWeight)

            // Bottom-left
            Path { path in
                path.move(to: CGPoint(x: centerX - halfSize + offset, y: centerY + halfSize - cornerLength))
                path.addLine(to: CGPoint(x: centerX - halfSize + offset, y: centerY + halfSize - offset))
                path.addLine(to: CGPoint(x: centerX - halfSize + cornerLength, y: centerY + halfSize - offset))
            }
            .stroke(Color.blue, lineWidth: cornerWeight)

            // Bottom-right
            Path { path in
                path.move(to: CGPoint(x: centerX + halfSize - cornerLength, y: centerY + halfSize - offset))
                path.addLine(to: CGPoint(x: centerX + halfSize - offset, y: centerY + halfSize - offset))
                path.addLine(to: CGPoint(x: centerX + halfSize - offset, y: centerY + halfSize - cornerLength))
            }
            .stroke(Color.blue, lineWidth: cornerWeight)
        }
    }

    // MARK: - Top Bar

    private var topBar: some View {
        HStack {
            Button {
                isPresented = false
            } label: {
                Image(systemName: "xmark.circle.fill")
                    .font(.title2)
                    .foregroundStyle(.white)
                    .padding(8)
            }

            Spacer()

            Text("Scan Code")
                .font(.headline)
                .foregroundStyle(.white)

            Spacer()

            Button {
                toggleFlashlight()
            } label: {
                Image(systemName: isFlashlightOn ? "flashlight.on.fill" : "flashlight.off.fill")
                    .font(.title2)
                    .foregroundStyle(isFlashlightOn ? .yellow : .white)
                    .padding(8)
            }
        }
        .padding(.horizontal)
        .padding(.top, 60)
    }

    // MARK: - Detected Code Banner

    private func detectedCodeBanner(_ code: String) -> some View {
        HStack {
            Image(systemName: "barcode")
                .foregroundStyle(.blue)
            Text(code)
                .font(.headline)
                .lineLimit(1)
        }
        .padding()
        .frame(maxWidth: .infinity)
        .background(.ultraThinMaterial)
        .clipShape(RoundedRectangle(cornerRadius: 12))
        .padding(.horizontal, 24)
    }

    // MARK: - Bottom Instructions

    private var bottomInstructions: some View {
        VStack(spacing: 4) {
            Text("Point camera at a barcode or QR code")
                .font(.subheadline)
                .foregroundStyle(.white)
            Text("Supports EAN, UPC, Code 128, Code 39, QR")
                .font(.caption)
                .foregroundStyle(.white.opacity(0.7))
        }
        .padding(.bottom, 50)
    }

    // MARK: - Flashlight

    private func toggleFlashlight() {
        guard let device = AVCaptureDevice.default(for: .video),
              device.hasTorch else { return }
        do {
            try device.lockForConfiguration()
            device.torchMode = isFlashlightOn ? .off : .on
            device.unlockForConfiguration()
            isFlashlightOn.toggle()
        } catch {
            // Flashlight toggle failed silently
        }
    }
}
