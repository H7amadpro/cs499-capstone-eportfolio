//
//  QuickLookupView.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//

import SwiftUI
import SwiftData

struct QuickLookupView: View {

    @Environment(\.modelContext) private var modelContext
    @Environment(\.dismiss) private var dismiss
    @Query private var items: [Item]

    @State private var isScanning = true
    @State private var scannedCode: String?
    @State private var foundItem: Item?
    @State private var showNotFound = false
    @State private var showingAddItem = false

    var body: some View {
        NavigationStack {
            Group {
                if isScanning {
                    EnhancedScannerView(
                        scannedCode: $scannedCode,
                        isPresented: $isScanning
                    ) { code in
                        lookupItem(code)
                    }
                } else if let item = foundItem {
                    ItemDetailView(item: item)
                } else if showNotFound {
                    notFoundView
                }
            }
            .toolbar {
                if !isScanning {
                    ToolbarItem(placement: .primaryAction) {
                        Button("Scan Again") {
                            resetScanner()
                        }
                    }
                }
            }
        }
    }

    // MARK: - Not Found View

    private var notFoundView: some View {
        VStack(spacing: 20) {
            Spacer()

            Image(systemName: "magnifyingglass.circle")
                .font(.system(size: 60))
                .foregroundStyle(.orange)

            Text("Item Not Found")
                .font(.title2)
                .fontWeight(.bold)

            if let code = scannedCode {
                VStack(spacing: 4) {
                    Text("Scanned code:")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                    Text(code)
                        .font(.headline)
                        .padding(.horizontal, 16)
                        .padding(.vertical, 8)
                        .background(Color(.systemGray6))
                        .clipShape(RoundedRectangle(cornerRadius: 8))
                }
            }

            Text("No item with this barcode exists in your inventory")
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)

            VStack(spacing: 12) {
                Button {
                    showingAddItem = true
                } label: {
                    Label("Add New Item", systemImage: "plus.circle.fill")
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.blue)
                        .foregroundStyle(.white)
                        .clipShape(RoundedRectangle(cornerRadius: 12))
                }

                Button {
                    resetScanner()
                } label: {
                    Label("Scan Again", systemImage: "barcode.viewfinder")
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color(.systemGray5))
                        .clipShape(RoundedRectangle(cornerRadius: 12))
                }

                Button {
                    dismiss()
                } label: {
                    Text("Cancel")
                        .foregroundStyle(.secondary)
                }
            }
            .padding(.horizontal, 24)

            Spacer()
        }
        .padding()
        .sheet(isPresented: $showingAddItem) {
            AddItemView()
        }
    }

    // MARK: - Lookup

    private func lookupItem(_ code: String) {
        if let item = items.first(where: { $0.barcode == code }) {
            foundItem = item
            isScanning = false
        } else {
            showNotFound = true
            isScanning = false
        }
    }

    private func resetScanner() {
        scannedCode = nil
        foundItem = nil
        showNotFound = false
        isScanning = true
    }
}
