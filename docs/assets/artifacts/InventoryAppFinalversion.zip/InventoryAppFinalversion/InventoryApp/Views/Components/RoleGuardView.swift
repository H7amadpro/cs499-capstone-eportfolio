//
//  RoleGuardView.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//

import SwiftUI

struct RoleGuardView<Content: View>: View {

    @EnvironmentObject var authService: AuthenticationService

    let permission: KeyPath<UserRole, Bool>
    @ViewBuilder let content: () -> Content

    var body: some View {
        if authService.hasPermission({ $0[keyPath: permission] }) {
            content()
        }
    }
}
