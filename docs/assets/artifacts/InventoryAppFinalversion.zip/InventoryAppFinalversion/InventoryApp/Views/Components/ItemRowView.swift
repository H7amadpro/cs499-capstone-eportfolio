//
//  ItemRowView.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//

import SwiftUI

struct ItemRowView: View {

    let item: Item
    var isSelectionMode: Bool = false
    var isSelected: Bool = false
    var showBranch: Bool = false

    var body: some View {
        HStack(spacing: 12) {
            // Selection checkbox
            if isSelectionMode {
                Image(systemName: isSelected ? "checkmark.circle.fill" : "circle")
                    .foregroundStyle(isSelected ? .blue : .secondary)
                    .font(.title3)
            }

            // Category icon
            ZStack {
                Circle()
                    .fill(Color(hex: item.category?.colorHex ?? "#8E8E93").opacity(0.15))
                    .frame(width: 44, height: 44)
                Image(systemName: item.categoryIconName)
                    .foregroundStyle(Color(hex: item.category?.colorHex ?? "#8E8E93"))
                    .font(.system(size: 18))
            }

            // Item info
            VStack(alignment: .leading, spacing: 4) {
                Text(item.name)
                    .font(.body)
                    .fontWeight(.medium)
                    .lineLimit(1)

                HStack(spacing: 8) {
                    Text(item.categoryName)
                        .font(.caption)
                        .foregroundStyle(.secondary)

                    if showBranch, !item.branchName.isEmpty {
                        Text("\u{2022} \(item.branchName)")
                            .font(.caption)
                            .foregroundStyle(.blue)
                    }

                    if let location = item.location, !location.isEmpty {
                        Text("\u{2022} \(location)")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                }
            }

            Spacer()

            // Right side info
            VStack(alignment: .trailing, spacing: 4) {
                Text(item.formattedPrice)
                    .font(.subheadline)
                    .fontWeight(.semibold)

                HStack(spacing: 4) {
                    StockBadge(item: item)
                }
            }
        }
        .padding(.vertical, 4)
    }
}

// MARK: - Stock Badge

struct StockBadge: View {
    let item: Item

    var body: some View {
        HStack(spacing: 3) {
            Circle()
                .fill(statusColor)
                .frame(width: 6, height: 6)
            Text("Qty: \(item.quantity)")
                .font(.caption2)
                .foregroundStyle(statusColor)
        }
        .padding(.horizontal, 6)
        .padding(.vertical, 2)
        .background(statusColor.opacity(0.1))
        .clipShape(Capsule())
    }

    private var statusColor: Color {
        switch item.stockStatus {
        case .outOfStock: return .red
        case .critical: return .orange
        case .low: return .yellow
        case .adequate, .optimal: return .green
        case .overstock: return .blue
        }
    }
}
