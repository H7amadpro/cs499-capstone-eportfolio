//
//  BranchPickerView.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//

import SwiftUI
import SwiftData

struct BranchPickerView: View {

    @EnvironmentObject var branchViewModel: BranchViewModel
    @Query(sort: \Branch.name) private var branches: [Branch]

    var body: some View {
        if !branches.isEmpty {
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 8) {
                    FilterChip(
                        title: "All Branches",
                        isSelected: branchViewModel.selectedBranchId == nil
                    ) {
                        branchViewModel.selectAllBranches()
                    }

                    ForEach(branches.filter(\.isActive)) { branch in
                        FilterChip(
                            title: branch.name,
                            isSelected: branchViewModel.selectedBranchId == branch.id
                        ) {
                            branchViewModel.selectBranch(branch)
                        }
                    }
                }
                .padding(.horizontal)
                .padding(.vertical, 8)
            }
            .background(Color(.systemGroupedBackground))
        }
    }
}
