//
//  UserManagementView.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//

import SwiftUI
import SwiftData

struct UserManagementView: View {

    @EnvironmentObject var authService: AuthenticationService
    @Environment(\.modelContext) private var modelContext
    @Query(sort: \User.username) private var users: [User]
    @State private var showingAddUser = false
    @State private var searchText = ""

    private var filteredUsers: [User] {
        guard !searchText.isEmpty else { return users }
        let query = searchText.lowercased()
        return users.filter {
            $0.username.lowercased().contains(query) ||
            $0.displayName.lowercased().contains(query) ||
            $0.role.lowercased().contains(query)
        }
    }

    var body: some View {
        List {
            Section {
                ForEach(filteredUsers) { user in
                    userRow(user)
                }
            } header: {
                Text("\(filteredUsers.count) users")
            }
        }
        .listStyle(.insetGrouped)
        .navigationTitle("User Management")
        .searchable(text: $searchText, prompt: "Search users...")
        .toolbar {
            ToolbarItem(placement: .primaryAction) {
                Button { showingAddUser = true } label: {
                    Image(systemName: "plus")
                }
            }
        }
        .sheet(isPresented: $showingAddUser) {
            AddUserSheet()
                .environmentObject(authService)
        }
    }

    // MARK: - User Row

    private func userRow(_ user: User) -> some View {
        HStack(spacing: 12) {
            ZStack {
                Circle()
                    .fill(roleColor(user.userRole).opacity(0.15))
                    .frame(width: 44, height: 44)
                Image(systemName: user.userRole.iconName)
                    .foregroundStyle(roleColor(user.userRole))
            }

            VStack(alignment: .leading, spacing: 4) {
                HStack {
                    Text(user.displayName)
                        .font(.body)
                        .fontWeight(.medium)
                    if user.id == authService.currentUser?.id {
                        Text("(You)")
                            .font(.caption)
                            .foregroundStyle(.blue)
                    }
                }
                Text("@\(user.username)")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                HStack(spacing: 4) {
                    Text(user.userRole.displayName)
                        .font(.caption2)
                        .padding(.horizontal, 6)
                        .padding(.vertical, 2)
                        .background(roleColor(user.userRole).opacity(0.15))
                        .clipShape(Capsule())
                    if !user.isActive {
                        Text("Inactive")
                            .font(.caption2)
                            .padding(.horizontal, 6)
                            .padding(.vertical, 2)
                            .background(Color.red.opacity(0.15))
                            .clipShape(Capsule())
                    }
                }
            }

            Spacer()

            if user.id != authService.currentUser?.id {
                Menu {
                    Menu("Change Role") {
                        ForEach(UserRole.allCases) { role in
                            Button {
                                changeRole(user, to: role)
                            } label: {
                                Label(role.displayName, systemImage: role.iconName)
                            }
                            .disabled(user.userRole == role)
                        }
                    }
                    Button(user.isActive ? "Deactivate" : "Activate") {
                        toggleActive(user)
                    }
                } label: {
                    Image(systemName: "ellipsis.circle")
                        .font(.title3)
                        .foregroundStyle(.secondary)
                }
            }
        }
        .padding(.vertical, 4)
    }

    // MARK: - Actions

    private func changeRole(_ user: User, to role: UserRole) {
        user.role = role.rawValue
        user.updatedAt = Date()
        try? modelContext.save()
    }

    private func toggleActive(_ user: User) {
        user.isActive.toggle()
        user.updatedAt = Date()
        try? modelContext.save()
    }

    private func roleColor(_ role: UserRole) -> Color {
        switch role {
        case .admin: return .red
        case .manager: return .orange
        case .staff: return .blue
        case .viewer: return .gray
        }
    }
}

// MARK: - Add User Sheet

struct AddUserSheet: View {

    @EnvironmentObject var authService: AuthenticationService
    @Environment(\.modelContext) private var modelContext
    @Environment(\.dismiss) private var dismiss

    @State private var username = ""
    @State private var displayName = ""
    @State private var password = ""
    @State private var selectedRole: UserRole = .staff
    @State private var errorMessage: String?
    @State private var showingError = false

    var body: some View {
        NavigationStack {
            Form {
                Section("Account Details") {
                    TextField("Username", text: $username)
                        .autocorrectionDisabled()
                        .textInputAutocapitalization(.never)
                    TextField("Display Name", text: $displayName)
                    SecureField("Password (min 6 characters)", text: $password)
                }

                Section("Role") {
                    Picker("Role", selection: $selectedRole) {
                        ForEach(UserRole.allCases) { role in
                            HStack {
                                Image(systemName: role.iconName)
                                Text(role.displayName)
                            }
                            .tag(role)
                        }
                    }
                    .pickerStyle(.inline)

                    Text(selectedRole.description)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
            .navigationTitle("Add User")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Create") {
                        createUser()
                    }
                    .fontWeight(.semibold)
                    .disabled(username.isEmpty || password.isEmpty)
                }
            }
            .alert("Error", isPresented: $showingError) {
                Button("OK") {}
            } message: {
                Text(errorMessage ?? "An error occurred")
            }
        }
    }

    private func createUser() {
        do {
            let _ = try authService.createUser(
                username: username,
                displayName: displayName,
                password: password,
                role: selectedRole,
                context: modelContext
            )
            dismiss()
        } catch {
            errorMessage = error.localizedDescription
            showingError = true
        }
    }
}
