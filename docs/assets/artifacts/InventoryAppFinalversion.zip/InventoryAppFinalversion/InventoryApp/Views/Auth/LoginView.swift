//
//  LoginView.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//

import SwiftUI
import SwiftData

struct LoginView: View {

    @EnvironmentObject var authService: AuthenticationService
    @Environment(\.modelContext) private var modelContext
    @StateObject private var viewModel = AuthViewModel()

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 32) {
                    // App Header
                    appHeader

                    // Form
                    if viewModel.isSignUp || authService.isInitialSetup {
                        signUpForm
                    } else {
                        loginForm
                    }

                    // Biometric Login
                    if !viewModel.isSignUp && !authService.isInitialSetup && canUseBiometricLogin {
                        biometricButton
                    }

                    // Toggle Login/Signup
                    if !authService.isInitialSetup {
                        toggleButton
                    }
                }
                .padding(.horizontal, 24)
                .padding(.vertical, 40)
            }
            .background(Color(.systemGroupedBackground))
            .alert("Error", isPresented: $viewModel.showingError) {
                Button("OK") {}
            } message: {
                Text(viewModel.errorMessage ?? "An error occurred")
            }
        }
    }

    // MARK: - App Header

    private var appHeader: some View {
        VStack(spacing: 12) {
            ZStack {
                Circle()
                    .fill(Color.blue.opacity(0.15))
                    .frame(width: 100, height: 100)
                Image(systemName: "cube.box.fill")
                    .font(.system(size: 44))
                    .foregroundStyle(.blue)
            }

            Text("Inventory Manager")
                .font(.title)
                .fontWeight(.bold)

            if authService.isInitialSetup {
                Text("Create your admin account to get started")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
            } else {
                Text("Sign in to manage your inventory")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }
        }
    }

    // MARK: - Login Form

    private var loginForm: some View {
        VStack(spacing: 16) {
            VStack(spacing: 12) {
                HStack {
                    Image(systemName: "person.fill")
                        .foregroundStyle(.secondary)
                        .frame(width: 20)
                    TextField("Username", text: $viewModel.username)
                        .textContentType(.username)
                        .autocorrectionDisabled()
                        .textInputAutocapitalization(.never)
                }
                .padding()
                .background(Color(.systemBackground))
                .clipShape(RoundedRectangle(cornerRadius: 12))

                HStack {
                    Image(systemName: "lock.fill")
                        .foregroundStyle(.secondary)
                        .frame(width: 20)
                    SecureField("Password", text: $viewModel.password)
                        .textContentType(.password)
                }
                .padding()
                .background(Color(.systemBackground))
                .clipShape(RoundedRectangle(cornerRadius: 12))
            }

            Button {
                viewModel.login(authService: authService, context: modelContext)
            } label: {
                HStack {
                    if viewModel.isLoading {
                        ProgressView()
                            .tint(.white)
                    }
                    Text("Sign In")
                        .fontWeight(.semibold)
                }
                .frame(maxWidth: .infinity)
                .padding()
                .background(Color.blue)
                .foregroundStyle(.white)
                .clipShape(RoundedRectangle(cornerRadius: 12))
            }
            .disabled(viewModel.username.isEmpty || viewModel.password.isEmpty || viewModel.isLoading)
        }
    }

    // MARK: - Sign Up Form

    private var signUpForm: some View {
        VStack(spacing: 16) {
            VStack(spacing: 12) {
                HStack {
                    Image(systemName: "person.fill")
                        .foregroundStyle(.secondary)
                        .frame(width: 20)
                    TextField("Username", text: $viewModel.username)
                        .textContentType(.username)
                        .autocorrectionDisabled()
                        .textInputAutocapitalization(.never)
                }
                .padding()
                .background(Color(.systemBackground))
                .clipShape(RoundedRectangle(cornerRadius: 12))

                HStack {
                    Image(systemName: "person.text.rectangle")
                        .foregroundStyle(.secondary)
                        .frame(width: 20)
                    TextField("Display Name", text: $viewModel.displayName)
                        .textContentType(.name)
                }
                .padding()
                .background(Color(.systemBackground))
                .clipShape(RoundedRectangle(cornerRadius: 12))

                HStack {
                    Image(systemName: "lock.fill")
                        .foregroundStyle(.secondary)
                        .frame(width: 20)
                    SecureField("Password (min 6 characters)", text: $viewModel.password)
                        .textContentType(.newPassword)
                }
                .padding()
                .background(Color(.systemBackground))
                .clipShape(RoundedRectangle(cornerRadius: 12))

                HStack {
                    Image(systemName: "lock.shield")
                        .foregroundStyle(.secondary)
                        .frame(width: 20)
                    SecureField("Confirm Password", text: $viewModel.confirmPassword)
                        .textContentType(.newPassword)
                }
                .padding()
                .background(Color(.systemBackground))
                .clipShape(RoundedRectangle(cornerRadius: 12))
            }

            if authService.isInitialSetup {
                HStack {
                    Image(systemName: "shield.checkered")
                        .foregroundStyle(.blue)
                    Text("This account will have Admin privileges")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }

            Button {
                viewModel.signUp(authService: authService, context: modelContext)
            } label: {
                HStack {
                    if viewModel.isLoading {
                        ProgressView()
                            .tint(.white)
                    }
                    Text(authService.isInitialSetup ? "Create Admin Account" : "Create Account")
                        .fontWeight(.semibold)
                }
                .frame(maxWidth: .infinity)
                .padding()
                .background(Color.blue)
                .foregroundStyle(.white)
                .clipShape(RoundedRectangle(cornerRadius: 12))
            }
            .disabled(viewModel.username.isEmpty || viewModel.password.isEmpty ||
                     viewModel.confirmPassword.isEmpty || viewModel.isLoading)
        }
    }

    // MARK: - Biometric Button

    private var biometricButton: some View {
        VStack(spacing: 8) {
            Divider()
            Text("or")
                .font(.caption)
                .foregroundStyle(.secondary)

            Button {
                Task {
                    let success = await authService.biometricLogin(context: modelContext)
                    if !success {
                        viewModel.errorMessage = authService.errorMessage ?? "Biometric login failed"
                        viewModel.showingError = true
                    }
                }
            } label: {
                HStack {
                    Image(systemName: authService.biometricName == "Face ID" ? "faceid" : "touchid")
                    Text("Sign in with \(authService.biometricName)")
                }
                .frame(maxWidth: .infinity)
                .padding()
                .background(Color(.systemBackground))
                .clipShape(RoundedRectangle(cornerRadius: 12))
            }
        }
    }
    
    /// Check if biometric login is available (device has biometric AND a user has it enabled)
    private var canUseBiometricLogin: Bool {
        guard authService.biometricAvailable else { return false }
        // Check if there's a saved biometric user
        return UserDefaults.standard.string(forKey: "biometricEnabledUser") != nil ||
               UserDefaults.standard.string(forKey: "lastLoggedInUser") != nil
    }

    // MARK: - Toggle Button

    private var toggleButton: some View {
        Button {
            viewModel.isSignUp.toggle()
            viewModel.resetFields()
        } label: {
            if viewModel.isSignUp {
                Text("Already have an account? **Sign In**")
            } else {
                Text("Don't have an account? **Sign Up**")
            }
        }
        .font(.subheadline)
    }
}
