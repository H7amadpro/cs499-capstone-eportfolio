//
//  ScanSearchView.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//
//  Barcode/QR scan search for inventory items
//

import SwiftUI
import SwiftData

struct ScanSearchView: View {
    
    @Environment(\.dismiss) private var dismiss
    @Environment(\.modelContext) private var modelContext
    @Query private var items: [Item]
    
    @Binding var searchText: String
    
    @State private var isScanning = true
    @State private var scannedCode: String?
    @State private var foundItems: [Item] = []
    @State private var showNotFound = false
    
    var body: some View {
        NavigationStack {
            Group {
                if isScanning {
                    EnhancedScannerView(
                        scannedCode: $scannedCode,
                        isPresented: $isScanning
                    ) { code in
                        searchByBarcode(code)
                    }
                } else if !foundItems.isEmpty {
                    // Show found items
                    foundItemsView
                } else if showNotFound {
                    // No items found
                    notFoundView
                }
            }
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") {
                        dismiss()
                    }
                }
                if !isScanning {
                    ToolbarItem(placement: .primaryAction) {
                        Button("Scan Again") {
                            resetScanner()
                        }
                    }
                }
            }
        }
    }
    
    // MARK: - Found Items View
    
    private var foundItemsView: some View {
        VStack(spacing: 0) {
            // Header
            VStack(spacing: 8) {
                Image(systemName: "checkmark.circle.fill")
                    .font(.system(size: 50))
                    .foregroundStyle(.green)
                
                Text("\(foundItems.count) Item\(foundItems.count == 1 ? "" : "s") Found")
                    .font(.title2)
                    .fontWeight(.bold)
                
                if let code = scannedCode {
                    Text("Barcode: \(code)")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .padding(.horizontal, 12)
                        .padding(.vertical, 4)
                        .background(Color(.systemGray6))
                        .clipShape(Capsule())
                }
            }
            .padding(.vertical, 20)
            
            // Items list
            List(foundItems) { item in
                NavigationLink(destination: ItemDetailView(item: item)) {
                    ItemRowView(item: item)
                }
            }
            .listStyle(.insetGrouped)
            
            // Action buttons
            VStack(spacing: 12) {
                Button {
                    // Apply scanned code to search and dismiss
                    if let code = scannedCode {
                        searchText = code
                    }
                    dismiss()
                } label: {
                    Label("Search in Inventory", systemImage: "magnifyingglass")
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.blue)
                        .foregroundStyle(.white)
                        .clipShape(RoundedRectangle(cornerRadius: 12))
                }
                
                Button {
                    resetScanner()
                } label: {
                    Label("Scan Another", systemImage: "barcode.viewfinder")
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color(.systemGray5))
                        .clipShape(RoundedRectangle(cornerRadius: 12))
                }
            }
            .padding()
        }
    }
    
    // MARK: - Not Found View
    
    private var notFoundView: some View {
        VStack(spacing: 20) {
            Spacer()
            
            Image(systemName: "magnifyingglass.circle")
                .font(.system(size: 60))
                .foregroundStyle(.orange)
            
            Text("No Items Found")
                .font(.title2)
                .fontWeight(.bold)
            
            if let code = scannedCode {
                VStack(spacing: 4) {
                    Text("Scanned code:")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                    Text(code)
                        .font(.headline)
                        .padding(.horizontal, 16)
                        .padding(.vertical, 8)
                        .background(Color(.systemGray6))
                        .clipShape(RoundedRectangle(cornerRadius: 8))
                }
            }
            
            Text("No items match this barcode in your inventory")
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
                .padding(.horizontal)
            
            VStack(spacing: 12) {
                Button {
                    // Apply scanned code to search text anyway
                    if let code = scannedCode {
                        searchText = code
                    }
                    dismiss()
                } label: {
                    Label("Use as Search Term", systemImage: "magnifyingglass")
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.blue)
                        .foregroundStyle(.white)
                        .clipShape(RoundedRectangle(cornerRadius: 12))
                }
                
                Button {
                    resetScanner()
                } label: {
                    Label("Scan Again", systemImage: "barcode.viewfinder")
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color(.systemGray5))
                        .clipShape(RoundedRectangle(cornerRadius: 12))
                }
            }
            .padding(.horizontal, 24)
            
            Spacer()
        }
        .padding()
    }
    
    // MARK: - Search Logic
    
    private func searchByBarcode(_ code: String) {
        // Search for items with matching barcode
        let matches = items.filter { item in
            item.barcode?.lowercased() == code.lowercased() ||
            item.sku?.lowercased() == code.lowercased()
        }
        
        if matches.isEmpty {
            // Also try partial match in name/tags
            let partialMatches = items.filter { item in
                item.name.lowercased().contains(code.lowercased()) ||
                item.tags.contains { $0.lowercased().contains(code.lowercased()) }
            }
            
            if partialMatches.isEmpty {
                showNotFound = true
            } else {
                foundItems = partialMatches
            }
        } else {
            foundItems = matches
        }
        
        isScanning = false
    }
    
    private func resetScanner() {
        scannedCode = nil
        foundItems = []
        showNotFound = false
        isScanning = true
    }
}
