//
//  AddItemView.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//

import SwiftUI
import SwiftData

struct AddItemView: View {

    @EnvironmentObject var authService: AuthenticationService
    @Environment(\.modelContext) private var modelContext
    @Environment(\.dismiss) private var dismiss
    @Query private var categories: [CategoryEntity]
    @Query(sort: \Branch.name) private var branches: [Branch]
    @Query(sort: \Supplier.name) private var suppliers: [Supplier]
    @StateObject private var viewModel: AddItemViewModel
    @State private var showingScanner = false
    @State private var showingImagePicker = false
    @State private var showingCamera = false
    @State private var imageSourceType: UIImagePickerController.SourceType = .photoLibrary
    @State private var selectedImages: [UIImage] = []
    @State private var showingImageOptions = false

    init(editing item: Item? = nil) {
        _viewModel = StateObject(wrappedValue: AddItemViewModel(editing: item))
    }
    
    /// Check if current user can view cost field
    private var canViewCost: Bool {
        authService.hasPermission(\.canViewCost)
    }

    var body: some View {
        NavigationStack {
            Form {
                // Basic Info
                Section("Basic Information") {
                    TextField("Item Name *", text: $viewModel.name)
                        .textContentType(.name)

                    TextField("Description", text: $viewModel.itemDescription, axis: .vertical)
                        .lineLimit(3...6)

                    Picker("Category", selection: $viewModel.selectedCategory) {
                        Text("None").tag(nil as CategoryEntity?)
                        ForEach(categories) { cat in
                            Label(cat.name, systemImage: cat.iconName)
                                .tag(cat as CategoryEntity?)
                        }
                    }

                    if !branches.isEmpty {
                        Picker("Branch", selection: $viewModel.selectedBranch) {
                            Text("None").tag(nil as Branch?)
                            ForEach(branches.filter(\.isActive)) { branch in
                                Text(branch.name).tag(branch as Branch?)
                            }
                        }
                    }

                    if !suppliers.isEmpty {
                        Picker("Supplier", selection: $viewModel.selectedSupplier) {
                            Text("None").tag(nil as Supplier?)
                            ForEach(suppliers.filter(\.isActive)) { supplier in
                                Text(supplier.name).tag(supplier as Supplier?)
                            }
                        }
                    }
                }
                
                // Images Section
                Section {
                    // Image thumbnails
                    if !selectedImages.isEmpty || !(viewModel.editingItem?.images?.isEmpty ?? true) {
                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack(spacing: 12) {
                                // Existing images from editing item
                                if let existingImages = viewModel.editingItem?.images {
                                    ForEach(existingImages) { itemImage in
                                        if let uiImage = itemImage.uiImage {
                                            ZStack(alignment: .topTrailing) {
                                                Image(uiImage: uiImage)
                                                    .resizable()
                                                    .scaledToFill()
                                                    .frame(width: 80, height: 80)
                                                    .clipShape(RoundedRectangle(cornerRadius: 8))
                                                
                                                Button {
                                                    viewModel.imagesToDelete.append(itemImage.id)
                                                } label: {
                                                    Image(systemName: "xmark.circle.fill")
                                                        .foregroundStyle(.white, .red)
                                                        .font(.title3)
                                                }
                                                .offset(x: 6, y: -6)
                                            }
                                        }
                                    }
                                }
                                
                                // Newly selected images
                                ForEach(selectedImages.indices, id: \.self) { index in
                                    ZStack(alignment: .topTrailing) {
                                        Image(uiImage: selectedImages[index])
                                            .resizable()
                                            .scaledToFill()
                                            .frame(width: 80, height: 80)
                                            .clipShape(RoundedRectangle(cornerRadius: 8))
                                        
                                        Button {
                                            selectedImages.remove(at: index)
                                        } label: {
                                            Image(systemName: "xmark.circle.fill")
                                                .foregroundStyle(.white, .red)
                                                .font(.title3)
                                        }
                                        .offset(x: 6, y: -6)
                                    }
                                }
                            }
                            .padding(.vertical, 8)
                        }
                    }
                    
                    // Add image button
                    Button {
                        showingImageOptions = true
                    } label: {
                        Label("Add Image", systemImage: "photo.badge.plus")
                    }
                } header: {
                    Text("Images")
                } footer: {
                    Text("Add photos from your library or camera")
                }

                // Quantity & Price
                Section("Quantity & Price") {
                    HStack {
                        Text("Quantity *")
                        Spacer()
                        TextField("0", text: $viewModel.quantityString)
                            .keyboardType(.numberPad)
                            .multilineTextAlignment(.trailing)
                            .frame(width: 100)
                    }
                    HStack {
                        Text("Min Quantity")
                        Spacer()
                        TextField("5", text: $viewModel.minimumQuantityString)
                            .keyboardType(.numberPad)
                            .multilineTextAlignment(.trailing)
                            .frame(width: 100)
                    }
                    HStack {
                        Text("Max Quantity")
                        Spacer()
                        TextField("Optional", text: $viewModel.maximumQuantityString)
                            .keyboardType(.numberPad)
                            .multilineTextAlignment(.trailing)
                            .frame(width: 100)
                    }
                    HStack {
                        Text("Price *")
                        Spacer()
                        HStack(spacing: 2) {
                            Text("$")
                            TextField("0.00", text: $viewModel.priceString)
                                .keyboardType(.decimalPad)
                                .multilineTextAlignment(.trailing)
                                .frame(width: 90)
                        }
                    }
                    
                    // Cost field - only visible to Admin/Manager
                    if canViewCost {
                        HStack {
                            Text("Cost")
                            Spacer()
                            HStack(spacing: 2) {
                                Text("$")
                                TextField("0.00", text: $viewModel.costString)
                                    .keyboardType(.decimalPad)
                                    .multilineTextAlignment(.trailing)
                                    .frame(width: 90)
                            }
                        }
                        
                        // Show profit margin if both price and cost are set
                        if let margin = viewModel.profitMargin {
                            HStack {
                                Text("Profit Margin")
                                    .foregroundStyle(.secondary)
                                Spacer()
                                Text(String(format: "%.1f%%", margin))
                                    .foregroundStyle(margin >= 0 ? .green : .red)
                            }
                        }
                    }
                }

                // Identification
                Section("Identification") {
                    HStack {
                        TextField("Barcode", text: Binding(
                            get: { viewModel.barcode ?? "" },
                            set: { viewModel.barcode = $0.isEmpty ? nil : $0 }
                        ))
                        Button {
                            showingScanner = true
                        } label: {
                            Image(systemName: "barcode.viewfinder")
                                .foregroundStyle(.blue)
                        }
                    }
                    TextField("Location", text: $viewModel.location)
                    TextField("Tags (comma separated)", text: $viewModel.tagsString)
                }

                // Expiration
                Section("Expiration") {
                    Toggle("Has Expiration Date", isOn: $viewModel.hasExpiration)
                    if viewModel.hasExpiration {
                        DatePicker(
                            "Expiration Date",
                            selection: Binding(
                                get: { viewModel.expirationDate ?? Date() },
                                set: { viewModel.expirationDate = $0 }
                            ),
                            displayedComponents: .date
                        )
                    }
                }

                // Notes
                Section("Notes") {
                    TextField("Additional notes...", text: $viewModel.notes, axis: .vertical)
                        .lineLimit(3...6)
                }
            }
            .navigationTitle(viewModel.isEditing ? "Edit Item" : "Add Item")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button(viewModel.isEditing ? "Save" : "Add") {
                        viewModel.save(
                            context: modelContext, 
                            currentUser: authService.currentUser,
                            newImages: selectedImages,
                            canViewCost: canViewCost
                        )
                    }
                    .disabled(!viewModel.canSave || viewModel.isSaving)
                    .fontWeight(.semibold)
                }
            }
            .alert("Error", isPresented: $viewModel.showingError) {
                Button("OK") {}
            } message: {
                Text(viewModel.errorMessage ?? "An error occurred")
            }
            .onChange(of: viewModel.didSave) { _, saved in
                if saved { dismiss() }
            }
            .sheet(isPresented: $showingScanner) {
                EnhancedScannerView(
                    scannedCode: Binding(
                        get: { viewModel.barcode },
                        set: { viewModel.barcode = $0 }
                    ),
                    isPresented: $showingScanner
                )
            }
            .sheet(isPresented: $showingImagePicker) {
                ImagePicker(selectedImages: $selectedImages, sourceType: imageSourceType)
            }
            .confirmationDialog("Add Image", isPresented: $showingImageOptions) {
                Button("Photo Library") {
                    imageSourceType = .photoLibrary
                    showingImagePicker = true
                }
                if UIImagePickerController.isSourceTypeAvailable(.camera) {
                    Button("Take Photo") {
                        imageSourceType = .camera
                        showingImagePicker = true
                    }
                }
                Button("Cancel", role: .cancel) {}
            }
            .onAppear {
                // Load existing images when editing
                if let item = viewModel.editingItem, let images = item.images {
                    // Images are loaded via the model relationship
                    viewModel.loadExistingImages(images)
                }
            }
        }
    }
}
