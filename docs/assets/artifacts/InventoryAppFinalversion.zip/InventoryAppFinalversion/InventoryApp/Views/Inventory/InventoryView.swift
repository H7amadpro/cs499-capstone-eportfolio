//
//  InventoryView.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//

import SwiftUI
import SwiftData

struct InventoryView: View {

    @EnvironmentObject var authService: AuthenticationService
    @EnvironmentObject var branchViewModel: BranchViewModel
    @Environment(\.modelContext) private var modelContext
    @Query(sort: \Item.name) private var items: [Item]
    @Query private var categories: [CategoryEntity]
    @StateObject private var viewModel = InventoryViewModel()
    @State private var showingAddItem = false
    @State private var showingExport = false
    @State private var showingSortPicker = false
    @State private var showingQuickLookup = false
    @State private var showingScanSearch = false  // For scan search
    @State private var exportURL: URL?

    private var filteredItems: [Item] {
        let branchFiltered = branchViewModel.filterItems(items)
        return viewModel.filteredAndSorted(branchFiltered)
    }

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                // Branch picker
                BranchPickerView()

                // Filter bar
                filterBar

                // Item list
                if filteredItems.isEmpty {
                    emptyState
                } else {
                    itemList
                }
            }
            .navigationTitle("Inventory")
            .searchable(text: $viewModel.searchText, prompt: "Search items...")
            .toolbar { toolbarContent }
            .sheet(isPresented: $showingAddItem) {
                AddItemView()
            }
            .sheet(isPresented: $showingExport) {
                ExportView(items: filteredItems)
            }
            .sheet(isPresented: $showingQuickLookup) {
                QuickLookupView()
            }
            .sheet(isPresented: $showingScanSearch) {
                ScanSearchView(searchText: $viewModel.searchText)
            }
            .confirmationDialog("Sort By", isPresented: $showingSortPicker) {
                ForEach(SortOption.allCases) { option in
                    Button(option.rawValue) {
                        viewModel.selectedSort = option
                    }
                }
            }
            .alert("Delete Item?", isPresented: $viewModel.showingDeleteConfirmation) {
                Button("Delete", role: .destructive) {
                    if let item = viewModel.itemToDelete {
                        viewModel.deleteItem(item, context: modelContext)
                    }
                }
                Button("Cancel", role: .cancel) {}
            } message: {
                Text("This action cannot be undone.")
            }
        }
    }

    // MARK: - Filter Bar

    private var filterBar: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                // Stock filter
                ForEach(StockLevelFilter.allCases) { filter in
                    FilterChip(
                        title: filter.rawValue,
                        isSelected: viewModel.stockFilter == filter
                    ) {
                        viewModel.stockFilter = filter
                    }
                }

                Divider().frame(height: 24)

                // Category filter
                FilterChip(
                    title: "All Categories",
                    isSelected: viewModel.selectedCategoryId == nil
                ) {
                    viewModel.selectedCategoryId = nil
                }

                ForEach(categories) { cat in
                    FilterChip(
                        title: cat.name,
                        isSelected: viewModel.selectedCategoryId == cat.id
                    ) {
                        viewModel.selectedCategoryId = cat.id
                    }
                }
            }
            .padding(.horizontal)
            .padding(.vertical, 8)
        }
        .background(Color(.systemGroupedBackground))
    }

    // MARK: - Item List

    private var itemList: some View {
        List {
            // Summary header
            Section {
                HStack {
                    VStack(alignment: .leading) {
                        Text("\(filteredItems.count) items")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                        Text(String(format: "Total: $%.2f", viewModel.totalValue(filteredItems)))
                            .font(.headline)
                    }
                    Spacer()
                    if viewModel.lowStockCount(filteredItems) > 0 {
                        Label("\(viewModel.lowStockCount(filteredItems)) low", systemImage: "exclamationmark.triangle.fill")
                            .font(.caption)
                            .foregroundStyle(.orange)
                    }
                }
            }

            // Items
            Section {
                ForEach(filteredItems) { item in
                    NavigationLink(destination: ItemDetailView(item: item)) {
                        ItemRowView(item: item, isSelectionMode: viewModel.isSelectionMode,
                                    isSelected: viewModel.selectedItems.contains(item.id),
                                    showBranch: branchViewModel.isAllBranches)
                    }
                    .swipeActions(edge: .trailing) {
                        if authService.hasPermission(\.canDeleteItems) {
                            Button(role: .destructive) {
                                viewModel.itemToDelete = item
                                viewModel.showingDeleteConfirmation = true
                            } label: {
                                Label("Delete", systemImage: "trash")
                            }
                        }
                    }
                    .swipeActions(edge: .leading) {
                        if authService.hasPermission(\.canEditItems) {
                            NavigationLink(destination: AddItemView(editing: item)) {
                                Label("Edit", systemImage: "pencil")
                            }
                            .tint(.blue)
                        }
                    }
                    .onTapGesture {
                        if viewModel.isSelectionMode {
                            viewModel.toggleSelection(item)
                        }
                    }
                }
            }
        }
        .listStyle(.insetGrouped)
        .refreshable {
            // Pull to refresh
        }
    }

    // MARK: - Empty State

    private var emptyState: some View {
        VStack(spacing: 16) {
            Spacer()
            Image(systemName: "cube.box")
                .font(.system(size: 60))
                .foregroundStyle(.secondary)
            Text("No Items Found")
                .font(.title2)
                .fontWeight(.semibold)
            Text(viewModel.searchText.isEmpty ? "Tap + to add your first item" : "Try a different search term")
                .font(.subheadline)
                .foregroundStyle(.secondary)
            if viewModel.searchText.isEmpty && authService.hasPermission(\.canCreateItems) {
                Button {
                    showingAddItem = true
                } label: {
                    Label("Add Item", systemImage: "plus")
                        .padding(.horizontal, 20)
                        .padding(.vertical, 10)
                }
                .buttonStyle(.borderedProminent)
            }
            Spacer()
        }
    }

    // MARK: - Toolbar

    @ToolbarContentBuilder
    private var toolbarContent: some ToolbarContent {
        // Scan search button on the right of search bar area
        ToolbarItem(placement: .primaryAction) {
            HStack(spacing: 12) {
                // Scan search button
                Button {
                    showingScanSearch = true
                } label: {
                    Image(systemName: "barcode.viewfinder")
                }
                .accessibilityLabel("Scan to search")
                
                // Add item button
                if authService.hasPermission(\.canCreateItems) {
                    Button { showingAddItem = true } label: {
                        Image(systemName: "plus")
                    }
                }
            }
        }
        
        // Three-dot menu - Fixed styling
        ToolbarItem(placement: .secondaryAction) {
            Menu {
                Button {
                    showingQuickLookup = true
                } label: {
                    Label("Quick Lookup", systemImage: "barcode.viewfinder")
                }
                
                Button {
                    showingSortPicker = true
                } label: {
                    Label("Sort", systemImage: "arrow.up.arrow.down")
                }
                
                Button {
                    viewModel.isSelectionMode.toggle()
                } label: {
                    Label(viewModel.isSelectionMode ? "Cancel Selection" : "Select Items", systemImage: "checkmark.circle")
                }
                
                if authService.hasPermission(\.canExportData) {
                    Divider()
                    Button {
                        showingExport = true
                    } label: {
                        Label("Export", systemImage: "square.and.arrow.up")
                    }
                }
            } label: {
                Image(systemName: "ellipsis.circle")
                    .symbolRenderingMode(.hierarchical)
            }
        }
        
        if viewModel.isSelectionMode {
            ToolbarItem(placement: .bottomBar) {
                HStack {
                    Button("Select All") { viewModel.selectAll(filteredItems) }
                    Spacer()
                    Text("\(viewModel.selectedItems.count) selected")
                        .font(.caption)
                    Spacer()
                    if authService.hasPermission(\.canDeleteItems) {
                        Button("Delete", role: .destructive) {
                            viewModel.deleteSelectedItems(from: items, context: modelContext)
                        }
                        .disabled(viewModel.selectedItems.isEmpty)
                    }
                }
            }
        }
    }
}

// MARK: - Filter Chip

struct FilterChip: View {
    let title: String
    let isSelected: Bool
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Text(title)
                .font(.caption)
                .fontWeight(isSelected ? .semibold : .regular)
                .padding(.horizontal, 12)
                .padding(.vertical, 6)
                .background(isSelected ? Color.blue : Color(.systemGray5))
                .foregroundStyle(isSelected ? .white : .primary)
                .clipShape(Capsule())
        }
    }
}
