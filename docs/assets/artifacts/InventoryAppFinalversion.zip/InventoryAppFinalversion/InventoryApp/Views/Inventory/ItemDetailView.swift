//
//  ItemDetailView.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//

import SwiftUI
import SwiftData

struct ItemDetailView: View {

    @EnvironmentObject var authService: AuthenticationService
    @Environment(\.modelContext) private var modelContext
    @Environment(\.dismiss) private var dismiss
    let item: Item
    @State private var showingEdit = false
    @State private var showingDelete = false
    @State private var adjustQuantity = 0
    @State private var showingQuantityAdjust = false
    @State private var selectedImageIndex: Int?
    
    /// Check if current user can view cost field
    private var canViewCost: Bool {
        authService.hasPermission(\.canViewCost)
    }

    var body: some View {
        List {
            // Header with Image Gallery
            Section {
                VStack(alignment: .center, spacing: 12) {
                    // Image gallery or category icon
                    if let images = item.images, !images.isEmpty {
                        // Show image gallery
                        TabView(selection: $selectedImageIndex) {
                            ForEach(images.indices, id: \.self) { index in
                                if let uiImage = images[index].uiImage {
                                    Image(uiImage: uiImage)
                                        .resizable()
                                        .scaledToFit()
                                        .frame(maxHeight: 200)
                                        .clipShape(RoundedRectangle(cornerRadius: 12))
                                        .tag(index as Int?)
                                }
                            }
                        }
                        .tabViewStyle(.page(indexDisplayMode: .automatic))
                        .frame(height: 220)
                    } else {
                        // Show category icon
                        ZStack {
                            Circle()
                                .fill(Color(hex: item.category?.colorHex ?? "#8E8E93").opacity(0.15))
                                .frame(width: 80, height: 80)
                            Image(systemName: item.categoryIconName)
                                .font(.system(size: 36))
                                .foregroundStyle(Color(hex: item.category?.colorHex ?? "#8E8E93"))
                        }
                    }
                    
                    Text(item.name)
                        .font(.title2)
                        .fontWeight(.bold)
                    Text(item.categoryName)
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
                .frame(maxWidth: .infinity)
                .padding(.vertical, 8)
            }

            // Stock Status
            Section("Stock Status") {
                HStack {
                    Label("Quantity", systemImage: "number")
                    Spacer()
                    Text("\(item.quantity)")
                        .fontWeight(.semibold)
                }
                HStack {
                    Label("Status", systemImage: "circle.fill")
                    Spacer()
                    Text(item.stockStatus.rawValue)
                        .foregroundStyle(stockStatusColor)
                        .fontWeight(.medium)
                }
                HStack {
                    Label("Min Quantity", systemImage: "arrow.down.circle")
                    Spacer()
                    Text("\(item.minimumQuantity)")
                }
                if let max = item.maximumQuantity {
                    HStack {
                        Label("Max Quantity", systemImage: "arrow.up.circle")
                        Spacer()
                        Text("\(max)")
                    }
                }

                // Stock level bar
                VStack(alignment: .leading, spacing: 4) {
                    ProgressView(value: item.stockPercentage)
                        .tint(stockStatusColor)
                    Text("\(Int(item.stockPercentage * 100))% stocked")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                if authService.hasPermission({ $0.canAdjustQuantity }) {
                    Button {
                        showingQuantityAdjust = true
                    } label: {
                        Label("Adjust Quantity", systemImage: "plus.forwardslash.minus")
                    }
                }
            }

            // Pricing (with Cost for Admin/Manager)
            Section("Pricing") {
                HStack {
                    Label("Unit Price", systemImage: "dollarsign.circle")
                    Spacer()
                    Text(item.formattedPrice)
                        .fontWeight(.semibold)
                }
                
                // Cost - only visible to Admin/Manager
                if canViewCost, let formattedCost = item.formattedCost {
                    HStack {
                        Label("Unit Cost", systemImage: "creditcard")
                        Spacer()
                        Text(formattedCost)
                            .fontWeight(.medium)
                            .foregroundStyle(.orange)
                    }
                    
                    // Profit margin
                    if let margin = item.profitMargin {
                        HStack {
                            Label("Profit Margin", systemImage: "percent")
                            Spacer()
                            Text(String(format: "%.1f%%", margin))
                                .fontWeight(.medium)
                                .foregroundStyle(margin >= 0 ? .green : .red)
                        }
                    }
                }
                
                HStack {
                    Label("Total Value", systemImage: "banknote")
                    Spacer()
                    Text(item.formattedTotalValue)
                        .fontWeight(.semibold)
                        .foregroundStyle(.green)
                }
            }

            // Branch & Supplier
            if item.branch != nil || item.supplier != nil {
                Section("Source") {
                    if let branch = item.branch {
                        HStack {
                            Label("Branch", systemImage: "building.2")
                            Spacer()
                            Text(branch.name)
                                .foregroundStyle(.secondary)
                        }
                    }
                    if let supplier = item.supplier {
                        HStack {
                            Label("Supplier", systemImage: "shippingbox")
                            Spacer()
                            Text(supplier.name)
                                .foregroundStyle(.secondary)
                        }
                        if let contact = supplier.contactPerson, !contact.isEmpty {
                            HStack {
                                Label("Contact", systemImage: "person")
                                Spacer()
                                Text(contact)
                                    .foregroundStyle(.secondary)
                            }
                        }
                    }
                }
            }

            // Details
            Section("Details") {
                if let barcode = item.barcode, !barcode.isEmpty {
                    HStack {
                        Label("Barcode", systemImage: "barcode")
                        Spacer()
                        Text(barcode)
                            .foregroundStyle(.secondary)
                    }
                }
                if let location = item.location, !location.isEmpty {
                    HStack {
                        Label("Location", systemImage: "mappin.circle")
                        Spacer()
                        Text(location)
                            .foregroundStyle(.secondary)
                    }
                }
                if !item.itemDescription.isEmpty {
                    VStack(alignment: .leading, spacing: 4) {
                        Label("Description", systemImage: "text.alignleft")
                        Text(item.itemDescription)
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                    }
                }
                if !item.tags.isEmpty {
                    VStack(alignment: .leading, spacing: 4) {
                        Label("Tags", systemImage: "tag")
                        FlowLayout(spacing: 4) {
                            ForEach(item.tags, id: \.self) { tag in
                                Text(tag)
                                    .font(.caption)
                                    .padding(.horizontal, 8)
                                    .padding(.vertical, 4)
                                    .background(Color.blue.opacity(0.1))
                                    .clipShape(Capsule())
                            }
                        }
                    }
                }
            }

            // Expiration
            if let expDate = item.expirationDate {
                Section("Expiration") {
                    HStack {
                        Label("Expires", systemImage: "calendar.badge.clock")
                        Spacer()
                        Text(expDate, style: .date)
                            .foregroundStyle(expirationColor)
                    }
                    if let days = item.daysUntilExpiration {
                        HStack {
                            Label("Days Remaining", systemImage: "hourglass")
                            Spacer()
                            Text(days < 0 ? "Expired \(abs(days)) days ago" : "\(days) days")
                                .foregroundStyle(expirationColor)
                        }
                    }
                }
            }

            // Timestamps
            Section("History") {
                HStack {
                    Label("Created", systemImage: "calendar.badge.plus")
                    Spacer()
                    Text(item.createdAt, style: .date)
                        .foregroundStyle(.secondary)
                }
                HStack {
                    Label("Modified", systemImage: "calendar.badge.clock")
                    Spacer()
                    Text(item.updatedAt, style: .date)
                        .foregroundStyle(.secondary)
                }
            }

            // Notes
            if let notes = item.notes, !notes.isEmpty {
                Section("Notes") {
                    Text(notes)
                        .font(.subheadline)
                }
            }

            // Actions
            Section {
                if authService.hasPermission({ $0.canEditItems }) {
                    Button {
                        showingEdit = true
                    } label: {
                        Label("Edit Item", systemImage: "pencil")
                    }
                }

                if authService.hasPermission({ $0.canDeleteItems }) {
                    Button(role: .destructive) {
                        showingDelete = true
                    } label: {
                        Label("Delete Item", systemImage: "trash")
                    }
                }
            }
        }
        .listStyle(.insetGrouped)
        .navigationBarTitleDisplayMode(.inline)
        .sheet(isPresented: $showingEdit) {
            AddItemView(editing: item)
        }
        .alert("Adjust Quantity", isPresented: $showingQuantityAdjust) {
            TextField("Amount (+/-)", value: $adjustQuantity, format: .number)
                .keyboardType(.numberPad)
            Button("Apply") {
                let audit = AuditService(modelContext: modelContext, currentUser: authService.currentUser)
                let oldQty = item.quantity
                item.quantity = max(0, item.quantity + adjustQuantity)
                item.updatedAt = Date()
                audit.logQuantityChange(item, oldQty: oldQty, newQty: item.quantity)
                try? modelContext.save()
                adjustQuantity = 0
            }
            Button("Cancel", role: .cancel) { adjustQuantity = 0 }
        } message: {
            Text("Current: \(item.quantity). Enter positive to add, negative to subtract.")
        }
        .alert("Delete Item?", isPresented: $showingDelete) {
            Button("Delete", role: .destructive) {
                let audit = AuditService(modelContext: modelContext, currentUser: authService.currentUser)
                audit.logItemDeleted(item)
                modelContext.delete(item)
                try? modelContext.save()
                dismiss()
            }
            Button("Cancel", role: .cancel) {}
        } message: {
            Text("Are you sure you want to delete \"\(item.name)\"? This cannot be undone.")
        }
    }

    private var stockStatusColor: Color {
        switch item.stockStatus {
        case .outOfStock: return .red
        case .critical: return .orange
        case .low: return .yellow
        case .adequate, .optimal: return .green
        case .overstock: return .blue
        }
    }

    private var expirationColor: Color {
        switch item.expirationStatus {
        case .expired: return .red
        case .critical: return .orange
        case .warning: return .yellow
        default: return .secondary
        }
    }
}

// MARK: - Flow Layout

struct FlowLayout: Layout {
    var spacing: CGFloat = 4

    func sizeThatFits(proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) -> CGSize {
        let result = arrange(proposal: proposal, subviews: subviews)
        return result.size
    }

    func placeSubviews(in bounds: CGRect, proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) {
        let result = arrange(proposal: proposal, subviews: subviews)
        for (index, position) in result.positions.enumerated() {
            subviews[index].place(at: CGPoint(x: bounds.minX + position.x, y: bounds.minY + position.y), proposal: .unspecified)
        }
    }

    private func arrange(proposal: ProposedViewSize, subviews: Subviews) -> (size: CGSize, positions: [CGPoint]) {
        let maxWidth = proposal.width ?? .infinity
        var positions: [CGPoint] = []
        var x: CGFloat = 0
        var y: CGFloat = 0
        var rowHeight: CGFloat = 0

        for subview in subviews {
            let size = subview.sizeThatFits(.unspecified)
            if x + size.width > maxWidth, x > 0 {
                x = 0
                y += rowHeight + spacing
                rowHeight = 0
            }
            positions.append(CGPoint(x: x, y: y))
            rowHeight = max(rowHeight, size.height)
            x += size.width + spacing
        }

        return (CGSize(width: maxWidth, height: y + rowHeight), positions)
    }
}
