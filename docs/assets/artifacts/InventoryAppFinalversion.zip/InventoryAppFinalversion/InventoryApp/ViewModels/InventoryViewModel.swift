//
//  InventoryViewModel.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//

import Foundation
import SwiftData
import Combine

@MainActor
class InventoryViewModel: ObservableObject {
    
    // MARK: - Published Properties
    
    @Published var searchText: String = ""
    @Published var selectedSort: SortOption = .nameAsc
    @Published var stockFilter: StockLevelFilter = .all
    @Published var selectedCategoryId: UUID? = nil
    @Published var isSelectionMode: Bool = false
    @Published var selectedItems: Set<UUID> = []
    @Published var showingDeleteConfirmation = false
    @Published var itemToDelete: Item?
    
    // MARK: - Private
    
    private var cancellables = Set<AnyCancellable>()
    @Published var debouncedSearchText: String = ""
    
    // MARK: - Initialization
    
    init() {
        // Debounce search for performance
        $searchText
            .debounce(for: .milliseconds(300), scheduler: RunLoop.main)
            .removeDuplicates()
            .assign(to: &$debouncedSearchText)
    }
    
    // MARK: - Filtering & Sorting
    
    func filteredAndSorted(_ items: [Item]) -> [Item] {
        var result = items
        
        // Apply search filter
        if !debouncedSearchText.isEmpty {
            let query = debouncedSearchText.lowercased()
            result = result.filter {
                $0.name.lowercased().contains(query) ||
                $0.categoryName.lowercased().contains(query) ||
                ($0.barcode?.lowercased().contains(query) ?? false) ||
                ($0.location?.lowercased().contains(query) ?? false) ||
                $0.tags.contains { $0.lowercased().contains(query) }
            }
        }
        
        // Apply stock filter
        switch stockFilter {
        case .all: break
        case .inStock: result = result.filter { $0.quantity > $0.minimumQuantity }
        case .lowStock: result = result.filter { $0.isLowStock && !$0.isOutOfStock }
        case .outOfStock: result = result.filter { $0.isOutOfStock }
        }
        
        // Apply category filter
        if let catId = selectedCategoryId {
            result = result.filter { $0.category?.id == catId }
        }
        
        // Apply sorting using Timsort O(n log n)
        switch selectedSort {
        case .nameAsc: result.sort { $0.name.lowercased() < $1.name.lowercased() }
        case .nameDesc: result.sort { $0.name.lowercased() > $1.name.lowercased() }
        case .quantityAsc: result.sort { $0.quantity < $1.quantity }
        case .quantityDesc: result.sort { $0.quantity > $1.quantity }
        case .priceAsc: result.sort { $0.price < $1.price }
        case .priceDesc: result.sort { $0.price > $1.price }
        case .dateAddedDesc: result.sort { $0.createdAt > $1.createdAt }
        case .dateAddedAsc: result.sort { $0.createdAt < $1.createdAt }
        case .lastModified: result.sort { $0.updatedAt > $1.updatedAt }
        }
        
        return result
    }
    
    // MARK: - CRUD Operations
    
    func deleteItem(_ item: Item, context: ModelContext) {
        let audit = AuditService(modelContext: context)
        audit.logItemDeleted(item)
        context.delete(item)
        try? context.save()
    }
    
    func deleteSelectedItems(from items: [Item], context: ModelContext) {
        let audit = AuditService(modelContext: context)
        for item in items where selectedItems.contains(item.id) {
            audit.logItemDeleted(item)
            context.delete(item)
        }
        try? context.save()
        selectedItems.removeAll()
        isSelectionMode = false
    }
    
    func batchUpdateCategory(_ category: CategoryEntity?, items: [Item], context: ModelContext) {
        for item in items where selectedItems.contains(item.id) {
            item.category = category
            item.updatedAt = Date()
        }
        try? context.save()
        selectedItems.removeAll()
        isSelectionMode = false
    }
    
    func batchAdjustQuantity(by amount: Int, items: [Item], context: ModelContext) {
        let audit = AuditService(modelContext: context)
        for item in items where selectedItems.contains(item.id) {
            let oldQty = item.quantity
            item.quantity = max(0, item.quantity + amount)
            item.updatedAt = Date()
            audit.logQuantityChange(item, oldQty: oldQty, newQty: item.quantity)
        }
        try? context.save()
        selectedItems.removeAll()
        isSelectionMode = false
    }
    
    // MARK: - Selection
    
    func toggleSelection(_ item: Item) {
        if selectedItems.contains(item.id) {
            selectedItems.remove(item.id)
        } else {
            selectedItems.insert(item.id)
        }
    }
    
    func selectAll(_ items: [Item]) {
        selectedItems = Set(items.map(\.id))
    }
    
    func deselectAll() {
        selectedItems.removeAll()
    }
    
    // MARK: - Analytics
    
    func totalValue(_ items: [Item]) -> Double {
        items.reduce(0) { $0 + $1.totalValue }
    }
    
    func lowStockCount(_ items: [Item]) -> Int {
        items.filter(\.isLowStock).count
    }
    
    func outOfStockCount(_ items: [Item]) -> Int {
        items.filter(\.isOutOfStock).count
    }
}
