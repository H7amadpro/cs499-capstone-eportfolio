//
//  AddItemViewModel.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//

import Foundation
import SwiftData
import UIKit  // Required for UIImage

@MainActor
class AddItemViewModel: ObservableObject {

    // MARK: - Form Fields

    @Published var name = ""
    @Published var itemDescription = ""
    @Published var quantityString = ""
    @Published var minimumQuantityString = "5"
    @Published var maximumQuantityString = ""
    @Published var priceString = ""
    @Published var costString = ""  // Cost field
    @Published var barcode: String?
    @Published var location = ""
    @Published var notes = ""
    @Published var tagsString = ""
    @Published var expirationDate: Date?
    @Published var hasExpiration = false
    @Published var selectedCategory: CategoryEntity?
    @Published var selectedBranch: Branch?
    @Published var selectedSupplier: Supplier?
    
    // Image management
    @Published var imagesToDelete: [UUID] = []

    // MARK: - State

    @Published var errorMessage: String?
    @Published var showingError = false
    @Published var isSaving = false
    @Published var didSave = false

    // MARK: - Edit Mode

    let editingItem: Item?
    var isEditing: Bool { editingItem != nil }

    // MARK: - Parsed Values

    var quantity: Int { Int(quantityString) ?? 0 }
    var minimumQuantity: Int { Int(minimumQuantityString) ?? 5 }
    var maximumQuantity: Int? { Int(maximumQuantityString) }
    var price: Double { Double(priceString) ?? 0.0 }
    var cost: Double? { 
        guard !costString.isEmpty else { return nil }
        return Double(costString) 
    }
    var tags: [String] { tagsString.split(separator: ",").map { $0.trimmingCharacters(in: .whitespaces) }.filter { !$0.isEmpty } }
    
    /// Calculate profit margin if both price and cost are set
    var profitMargin: Double? {
        guard let cost = cost, cost > 0, price > 0 else { return nil }
        return ((price - cost) / cost) * 100
    }

    var canSave: Bool {
        !name.trimmingCharacters(in: .whitespaces).isEmpty &&
        !quantityString.isEmpty &&
        !priceString.isEmpty
    }

    // MARK: - Initialization

    init(editing item: Item? = nil) {
        self.editingItem = item
        if let item = item {
            name = item.name
            itemDescription = item.itemDescription
            quantityString = "\(item.quantity)"
            minimumQuantityString = "\(item.minimumQuantity)"
            if let max = item.maximumQuantity { maximumQuantityString = "\(max)" }
            priceString = String(format: "%.2f", item.price)
            if let cost = item.cost { costString = String(format: "%.2f", cost) }
            barcode = item.barcode
            location = item.location ?? ""
            notes = item.notes ?? ""
            tagsString = item.tags.joined(separator: ", ")
            expirationDate = item.expirationDate
            hasExpiration = item.expirationDate != nil
            selectedCategory = item.category
            selectedBranch = item.branch
            selectedSupplier = item.supplier
        }
    }
    
    /// Load existing images for editing
    func loadExistingImages(_ images: [ItemImage]) {
        // Images are already loaded via SwiftData relationship
        // This is a placeholder for any additional processing needed
    }

    // MARK: - Save

    func save(context: ModelContext, currentUser: User? = nil, newImages: [UIImage] = [], canViewCost: Bool = false) {
        isSaving = true
        errorMessage = nil

        // Sanitize inputs
        let sanitizedName = name.sanitized

        // Validate
        do {
            try ValidationService.validateItem(
                name: sanitizedName,
                quantity: quantity,
                price: price,
                category: selectedCategory
            )
        } catch let error as ValidationError {
            showError(error.errorDescription ?? "Validation failed")
            isSaving = false
            return
        } catch {
            showError("Unexpected error occurred")
            isSaving = false
            return
        }

        let audit = AuditService(modelContext: context, currentUser: currentUser)

        if let existing = editingItem {
            // Update existing item
            let oldQty = existing.quantity
            existing.name = sanitizedName
            existing.itemDescription = itemDescription
            existing.quantity = quantity
            existing.minimumQuantity = minimumQuantity
            existing.maximumQuantity = maximumQuantity
            existing.price = price
            
            // Only update cost if user has permission
            if canViewCost {
                existing.cost = cost
            }
            
            existing.barcode = barcode
            existing.location = location.isEmpty ? nil : location
            existing.notes = notes.isEmpty ? nil : notes
            existing.tags = tags
            existing.expirationDate = hasExpiration ? expirationDate : nil
            existing.category = selectedCategory
            existing.branch = selectedBranch
            existing.supplier = selectedSupplier
            existing.updatedAt = Date()
            
            // Handle image deletions
            if let images = existing.images {
                for imageId in imagesToDelete {
                    if let imageToDelete = images.first(where: { $0.id == imageId }) {
                        context.delete(imageToDelete)
                    }
                }
            }
            
            // Add new images
            for (index, uiImage) in newImages.enumerated() {
                if let imageData = uiImage.jpegData(compressionQuality: 0.8) {
                    let thumbnailData = createThumbnail(from: uiImage)?.jpegData(compressionQuality: 0.6)
                    let itemImage = ItemImage(
                        imageData: imageData,
                        thumbnailData: thumbnailData,
                        order: (existing.images?.count ?? 0) + index
                    )
                    itemImage.item = existing
                    context.insert(itemImage)
                }
            }

            audit.logItemUpdated(existing, changes: "Updated item details")
            if oldQty != quantity {
                audit.logQuantityChange(existing, oldQty: oldQty, newQty: quantity)
            }

            if existing.isLowStock {
                NotificationManager.shared.scheduleLowStockAlert(for: existing)
            }
        } else {
            // Create new item
            let newItem = Item(
                name: sanitizedName,
                itemDescription: itemDescription,
                quantity: quantity,
                minimumQuantity: minimumQuantity,
                maximumQuantity: maximumQuantity,
                price: price,
                cost: canViewCost ? cost : nil,
                barcode: barcode,
                location: location.isEmpty ? nil : location,
                notes: notes.isEmpty ? nil : notes,
                tags: tags,
                expirationDate: hasExpiration ? expirationDate : nil,
                category: selectedCategory,
                branch: selectedBranch,
                supplier: selectedSupplier
            )
            context.insert(newItem)
            
            // Add images
            for (index, uiImage) in newImages.enumerated() {
                if let imageData = uiImage.jpegData(compressionQuality: 0.8) {
                    let thumbnailData = createThumbnail(from: uiImage)?.jpegData(compressionQuality: 0.6)
                    let itemImage = ItemImage(
                        imageData: imageData,
                        thumbnailData: thumbnailData,
                        order: index
                    )
                    itemImage.item = newItem
                    context.insert(itemImage)
                }
            }
            
            audit.logItemCreated(newItem)

            if newItem.isLowStock {
                NotificationManager.shared.scheduleLowStockAlert(for: newItem)
            }
        }

        do {
            try context.save()
            didSave = true
        } catch {
            showError("Failed to save: \(error.localizedDescription)")
        }

        isSaving = false
    }
    
    /// Create thumbnail from UIImage
    private func createThumbnail(from image: UIImage) -> UIImage? {
        let thumbnailSize = CGSize(width: 150, height: 150)
        
        UIGraphicsBeginImageContextWithOptions(thumbnailSize, false, 1.0)
        image.draw(in: CGRect(origin: .zero, size: thumbnailSize))
        let thumbnail = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        return thumbnail
    }

    private func showError(_ message: String) {
        errorMessage = message
        showingError = true
    }
}
