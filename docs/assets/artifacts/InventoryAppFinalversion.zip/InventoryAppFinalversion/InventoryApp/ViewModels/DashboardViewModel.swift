//
//  DashboardViewModel.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//

import Foundation
import SwiftData

@MainActor
class DashboardViewModel: ObservableObject {
    
    struct CategoryBreakdown: Identifiable {
        let id = UUID()
        let name: String
        let count: Int
        let value: Double
        let colorHex: String
    }
    
    struct StockDistribution: Identifiable {
        let id = UUID()
        let status: String
        let count: Int
        let color: String
    }
    
    func totalItems(_ items: [Item]) -> Int { items.count }
    
    func totalValue(_ items: [Item]) -> Double {
        items.reduce(0) { $0 + $1.totalValue }
    }
    
    func formattedTotalValue(_ items: [Item]) -> String {
        String(format: "$%.2f", totalValue(items))
    }
    
    func lowStockCount(_ items: [Item]) -> Int {
        items.filter { $0.isLowStock && !$0.isOutOfStock }.count
    }
    
    func outOfStockCount(_ items: [Item]) -> Int {
        items.filter(\.isOutOfStock).count
    }
    
    func expiringCount(_ items: [Item]) -> Int {
        items.filter { $0.expirationStatus == .warning || $0.expirationStatus == .critical }.count
    }
    
    func categoryBreakdown(_ items: [Item], categories: [CategoryEntity]) -> [CategoryBreakdown] {
        categories.compactMap { cat in
            let catItems = items.filter { $0.category?.id == cat.id }
            guard !catItems.isEmpty else { return nil }
            return CategoryBreakdown(
                name: cat.name,
                count: catItems.count,
                value: catItems.reduce(0) { $0 + $1.totalValue },
                colorHex: cat.colorHex
            )
        }.sorted { $0.value > $1.value }
    }
    
    func stockDistribution(_ items: [Item]) -> [StockDistribution] {
        let groups = Dictionary(grouping: items) { $0.stockStatus }
        return groups.map { status, items in
            StockDistribution(status: status.rawValue, count: items.count, color: status.color)
        }.sorted { $0.count > $1.count }
    }
    
    func topValueItems(_ items: [Item], limit: Int = 5) -> [Item] {
        Array(items.sorted { $0.totalValue > $1.totalValue }.prefix(limit))
    }
    
    func recentlyModified(_ items: [Item], limit: Int = 5) -> [Item] {
        Array(items.sorted { $0.updatedAt > $1.updatedAt }.prefix(limit))
    }
}
