//
//  AuthViewModel.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//

import Foundation
import SwiftData

@MainActor
class AuthViewModel: ObservableObject {

    // MARK: - Form Fields

    @Published var username = ""
    @Published var password = ""
    @Published var confirmPassword = ""
    @Published var displayName = ""
    @Published var isSignUp = false

    // MARK: - State

    @Published var errorMessage: String?
    @Published var showingError = false
    @Published var isLoading = false

    // MARK: - Login

    func login(authService: AuthenticationService, context: ModelContext) {
        isLoading = true
        errorMessage = nil

        let success = authService.login(username: username, password: password, context: context)
        if !success {
            errorMessage = authService.errorMessage
            showingError = true
        } else {
            let audit = AuditService(modelContext: context, currentUser: authService.currentUser)
            if let user = authService.currentUser {
                audit.logLogin(user: user)
            }
        }

        isLoading = false
    }

    // MARK: - Sign Up

    func signUp(authService: AuthenticationService, context: ModelContext) {
        isLoading = true
        errorMessage = nil

        guard password == confirmPassword else {
            errorMessage = "Passwords do not match."
            showingError = true
            isLoading = false
            return
        }

        do {
            let isFirst = authService.isInitialSetup
            let _ = try authService.createUser(
                username: username,
                displayName: displayName,
                password: password,
                role: isFirst ? .admin : .staff,
                context: context
            )
            // Auto-login after signup
            let _ = authService.login(username: username, password: password, context: context)
        } catch {
            errorMessage = error.localizedDescription
            showingError = true
        }

        isLoading = false
    }

    // MARK: - Reset

    func resetFields() {
        username = ""
        password = ""
        confirmPassword = ""
        displayName = ""
        errorMessage = nil
        showingError = false
    }
}
