//
//  SettingsViewModel.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//

import Foundation

@MainActor
class SettingsViewModel: ObservableObject {
    
    @Published var lowStockThreshold: Int {
        didSet { UserDefaults.standard.set(lowStockThreshold, forKey: "lowStockThreshold") }
    }
    @Published var notificationsEnabled: Bool {
        didSet { UserDefaults.standard.set(notificationsEnabled, forKey: "notificationsEnabled") }
    }
    @Published var biometricEnabled: Bool {
        didSet { UserDefaults.standard.set(biometricEnabled, forKey: "biometricEnabled") }
    }
    @Published var defaultSortOption: SortOption {
        didSet { UserDefaults.standard.set(defaultSortOption.rawValue, forKey: "defaultSortOption") }
    }
    @Published var darkModeOverride: Bool {
        didSet { UserDefaults.standard.set(darkModeOverride, forKey: "darkModeOverride") }
    }
    
    init() {
        self.lowStockThreshold = UserDefaults.standard.object(forKey: "lowStockThreshold") as? Int ?? 5
        self.notificationsEnabled = UserDefaults.standard.bool(forKey: "notificationsEnabled")
        self.biometricEnabled = UserDefaults.standard.bool(forKey: "biometricEnabled")
        let sortRaw = UserDefaults.standard.string(forKey: "defaultSortOption") ?? SortOption.nameAsc.rawValue
        self.defaultSortOption = SortOption(rawValue: sortRaw) ?? .nameAsc
        self.darkModeOverride = UserDefaults.standard.bool(forKey: "darkModeOverride")
    }
    
    var appVersion: String {
        Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "4.0"
    }
    
    var buildNumber: String {
        Bundle.main.infoDictionary?["CFBundleVersion"] as? String ?? "1"
    }
}
