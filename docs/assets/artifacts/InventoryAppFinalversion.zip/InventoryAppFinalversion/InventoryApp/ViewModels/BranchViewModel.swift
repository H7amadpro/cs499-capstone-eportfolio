//
//  BranchViewModel.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//

import Foundation
import SwiftData

@MainActor
class BranchViewModel: ObservableObject {

    // MARK: - Published Properties

    @Published var selectedBranchId: UUID?

    // MARK: - Filtering

    func filterItems(_ items: [Item]) -> [Item] {
        guard let branchId = selectedBranchId else { return items }
        return items.filter { $0.branch?.id == branchId }
    }

    // MARK: - Selection

    var isAllBranches: Bool {
        selectedBranchId == nil
    }

    func selectAllBranches() {
        selectedBranchId = nil
    }

    func selectBranch(_ branch: Branch) {
        selectedBranchId = branch.id
    }
}
