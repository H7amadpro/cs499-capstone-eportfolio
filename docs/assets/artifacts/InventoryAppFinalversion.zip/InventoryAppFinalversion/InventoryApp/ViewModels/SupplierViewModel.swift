//
//  SupplierViewModel.swift
//  InventoryApp
//
//  Created by Hamad Alghaithi
//  CS 499 - Computer Science Capstone
//  Southern New Hampshire University
//

import Foundation
import SwiftData

@MainActor
class SupplierViewModel: ObservableObject {

    // MARK: - Published Properties

    @Published var searchText = ""
    @Published var showingAddSupplier = false
    @Published var supplierToDelete: Supplier?
    @Published var showingDeleteConfirmation = false

    // MARK: - Filtering

    func filtered(_ suppliers: [Supplier]) -> [Supplier] {
        guard !searchText.isEmpty else {
            return suppliers.filter(\.isActive)
        }
        let query = searchText.lowercased()
        return suppliers.filter(\.isActive).filter {
            $0.name.lowercased().contains(query) ||
            ($0.contactPerson?.lowercased().contains(query) ?? false) ||
            ($0.email?.lowercased().contains(query) ?? false) ||
            ($0.phone?.lowercased().contains(query) ?? false)
        }
    }

    // MARK: - CRUD

    func deleteSupplier(_ supplier: Supplier, context: ModelContext) {
        let audit = AuditService(modelContext: context)
        audit.log(action: .delete, entityType: "Supplier", entityId: supplier.id,
                  entityName: supplier.name)
        context.delete(supplier)
        try? context.save()
    }
}
